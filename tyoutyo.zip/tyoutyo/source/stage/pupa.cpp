#include"pupa.h"
#include"player.h"
#include"../global/global.h"
#include"stage.h"
/**
*	@file	pupa.cpp
*	@brief	���Ȃ��̏���
*	@author	D.K
*	@data	2020/02/17
*/
struct OBJECT* g_stage1_pupa[STAGE1_PUPA_MAX]={ NULL };
struct OBJECT* g_stage2_pupa[STAGE2_PUPA_MAX]={ NULL };
/*
*	@fn �e�X�e�[�W��匂Ɏg���I�u�W�F�N�g�̃|�C���^�̐擪�A�h���X��Ԃ��܂�
*/
OBJECT** GetStagePupa()
{
	switch(g_game.stage)
	{
	case ONE:
		return g_stage1_pupa;
		break;
	case TWO:
	case THREE:
		return g_stage2_pupa;
		break;
	}
	return NULL;
}
/*
*	@fn �e�X�e�[�W��匂̑�����Ԃ��܂�
*/
int GetStagePupaCount()
{
	switch(g_game.stage)
	{
	case ONE:
		return STAGE1_PUPA_MAX;
		break;
	case TWO:
	case THREE:
		return STAGE2_PUPA_MAX;
		break;
	}
	return NULL;
}
/*
*	@fn 匂̏�����
*/
void InitPupa()
{
	OBJECT** obj=GetStagePupa();
	if(g_game.stage==ONE)
	{
		CreateStage("Assets/stage/kagari1_pupa.source",obj);
	}
	else if(g_game.stage==TWO)
	{
		CreateStage("Assets/stage/kagari2_pupa.source",obj);
	}
	else if(g_game.stage==THREE)
	{
		//�X�e�[�W�R�̃\�[�X��ǂݍ���
		CreateStage("Assets/stage/lui_pupa.source",obj);
	}
}
/*
*	@fn 匂̏���
*/
void ProcessPupa()
{
	bool pupa_hit=false;
	int pupa_count=GetStagePupaCount();
	OBJECT** pupa=GetStagePupa();
	for(int i=0; i<pupa_count; i++)
	{
		if(strcmp(pupa[i]->name,"culture_tank")==0)continue;
		if(!pupa[i]->draw_use)continue;
		D3DXVECTOR3 vector;
		D3DXVECTOR3 temp=g_player[0]->obj->pos;
		pupa_hit=IsHitCirclePos(g_player[0]->obj->pos,pupa[i]->pos,30.0f,&vector);
		if(pupa_hit)
		{
			for(int p=0; p<2; p++)
			{
				g_player[p]->obj->pos=pupa[i]->pos+(vector*30.0f);
				if(g_game.mode==CUBE_UP)
				{
					g_player[p]->obj->pos.y=temp.y;
				}
				else if(g_game.mode==CUBE_BACK)
				{
					g_player[p]->obj->pos.z=temp.z;
				}
				else if(g_game.mode==CUBE_RIGHT)
				{
					g_player[p]->obj->pos.x=temp.x;
				}
			}
			g_hit_player.pupa_no=i;
			break;
		}
	}
	if(!pupa_hit)
	{
		g_hit_player.pupa_no=-1;
	}
}
