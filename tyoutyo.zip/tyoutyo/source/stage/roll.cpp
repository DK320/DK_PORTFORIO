/**
*	@file	roll.cpp
*	@brief	��]�L���[�u�̏���
*	@author	D.K
*	@data	2020/01/14
*/
#include"../fbx/FbxMeshAmg.h"
#include"../Directx9/Directx9MyLib.h"
#include"../game/game.h"
#include"../global/global.h"
#include"roll.h"
#include"../camera/camera.h"
#include"stage.h"
#include"player.h"
struct ROLL g_roll1[STAGE1_ROLL_MAX];
struct ROLL g_roll2[STAGE2_ROLL_MAX];
/*
*	@fn�@��]�L���[�u�̃|�C���^��Ԃ��܂�
*/
ROLL* GetStageRoll()
{
	switch(g_game.stage)
	{
	case ONE:
		return &g_roll1[0];
		break;
	case TWO:
	case THREE:
		return &g_roll2[0];
		break;
	}
	return NULL;
}
/*
*	@fn�@�e�X�e�[�W�̉�]�L���[�u�̑�����Ԃ��܂�
*/
int GetStageRollCount()
{
	switch(g_game.stage)
	{
	case ONE:
		return STAGE1_ROLL_MAX;
		break;
	case TWO:
	case THREE:
		return STAGE2_ROLL_MAX;
		break;
	}
	return NULL;
}
/*
*	@fn�@��]�L���[�u�̏�����
*/
void InitRoll()
{
	ROLL* roll=GetStageRoll();
	OBJECT* obj[10]={ NULL };
	for(int i=0; i< GetStageRollCount(); i++)
	{
		if(i==0)
		{
			if(g_game.stage==ONE)
			{
				CreateStage("Assets/stage/kagari1_roll.source",obj);
			}
			else if(g_game.stage==TWO)
			{
				CreateStage("Assets/stage/kagari2_roll.source",obj);
			}
			else if(g_game.stage==THREE)
			{
				//�X�e�[�W�R�̃\�[�X��ǂݍ���
				CreateStage("Assets/stage/lui_roll.source",obj);
			}
		}
		roll[i].obj=obj[i];
		roll[i].process_flg=false;
		roll[i].limit_x=0.0f;
		roll[i].limit_y=0.0f;
		roll[i].limit_z=0.0f;
		roll[i].player_old_position={ 0.0f,0.0f,0.0f };
		roll[i].player_old_rotation={ 0.0f,0.0f,0.0f };
		roll[i].obj->size.x=ROLL_WIDTH_HALF;
		roll[i].obj->size.y=ROLL_HEIGHT_HALF;
		roll[i].obj->size.z=ROLL_DEPTH_HALF;
		roll[i].is_rotation_process_flg=false;

		if(g_game.stage==ONE)
		{
			int direction_1[]=
			{
				X_PLUS,X_MINUS
			};
			int mode1[]=
			{
				CUBE_UP,
				CUBE_BACK
			};
			roll[i].change_mode=mode1[i];
			roll[i].rotation_direction=direction_1[i];
		}
		else if(g_game.stage==TWO || g_game.stage==THREE)
		{
			int direction2[]=
			{
				Z_MINUS,
				Z_PLUS,
				Z_MINUS,
				Z_PLUS
			};
			int mode2[]=
			{
				CUBE_RIGHT,
				CUBE_UP,
				CUBE_RIGHT,
				CUBE_UP
			};
			roll[i].rotation_direction=direction2[i];
			roll[i].change_mode=mode2[i];
		}
	}
}
/*
*	@fn�@��]�L���[�u�̏���
*	@param�@���Ԗڂ�
*	@param	���[���̐擪�|�C���^
*	@param	��]����
*/
void ProcessRoll(int no, ROLL* roll ,int direction_no)
{
	if(roll[no].process_flg)
	{
		if(
			(-1*(ANGLE*90))>=roll[no].limit_x|| roll[no].limit_x>=(ANGLE*90) ||
			(-1*(ANGLE*90))>=roll[no].limit_y|| roll[no].limit_y>=(ANGLE*90) ||
			(-1*(ANGLE*90))>=roll[no].limit_z|| roll[no].limit_z>=(ANGLE*90)
			)
		{
			roll[no].process_flg=false;
		}
		else
		{
			float direction[][3]={
				{ANGLE*1.0f,0.0f,0.0f},/*�s�b�`�@�{����*/
			{0.0f,ANGLE*1.0f,0.0f},/*���[�@�{����*/
			{0.0f,0.0f,ANGLE*1.0f},/*���[���@�{����*/
			{-ANGLE * 1.0f,0.0f,0.0f},/*�s�b�`�@�[����*/
			{0.0f,-ANGLE * 1.0f,0.0f},/*���[�@�[����*/
			{0.0f,0.0f,-ANGLE * 1.0f}	/*���[���@�[����*/
			};
			D3DXMATRIX before_roll=SetMatrix(D3DXVECTOR3(0,0,0),
											 roll[no].obj->rotation,
											 D3DXVECTOR3(1,1,1));

			D3DXVECTOR3 rotation={ direction[direction_no][0] ,
				direction[direction_no][1] ,direction[direction_no][2] };

			D3DXMATRIX after_roll=SetMatrix(D3DXVECTOR3(0,0,0),
											rotation,
											D3DXVECTOR3(1,1,1));
			D3DXMATRIX mat=before_roll*after_roll;
			D3DXVECTOR3 result=GetRotation(mat);
			D3DXVECTOR3 result2=GetRotation(after_roll);
			//��]������
			roll[no].obj->rotation.x=result.x;
			roll[no].obj->rotation.y=result.y;
			roll[no].obj->rotation.z=result.z;
			roll[no].limit_x+=result2.x;
			roll[no].limit_y+=result2.y;
			roll[no].limit_z+=result2.z;
		}
	}
}