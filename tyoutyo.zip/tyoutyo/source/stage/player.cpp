 /**
*	@file	player.cpp
*	@brief	�v���C���[�̏���
*	@author	D.K
*	@data	2019/11/27
*/
#include"../fbx/FbxMeshAmg.h"
#include"../Directx9/Directx9MyLib.h"
#include"../game/game.h"
#include"../global/global.h"
#include"player.h"
#include"../camera/camera.h"
#include"stage.h"
#include"roll.h"
#include"lift.h"
#include"../sound/dslib.h"
#include"../game/goal.h"
#include"../game/adventure.h"
#include"pupa.h"
struct PLAYER* g_player[2]={ NULL };//�v���C���[
struct HITPLAYER g_hit_player={-1};	 //�v���C���[�̃q�b�g���
struct WARP g_warp_no={0,0};		 //���[�v�̏��
/*
* @fn �A�j���[�V�����̕ύX
*/
void SetAnimetion(ANIME*anime,const char*motion_name)
{
	if(anime->motion_name)
	{
		free(anime->motion_name);
	}
	anime->motion_name=(char*)malloc(strlen(motion_name)+1);
	strcpy(anime->motion_name,(char*)motion_name);
	anime->frame=0.0f;
}
/*
*	@fn �v���C���[�����]���̊p�x��Ԃ��܂�
*	@param PlayerDirection �v���C���[�̕���
*	@param StickValue �X�e�B�b�N�̓���
*	@return �����]����̊p�x
*/
float RotationPlayer(D3DXVECTOR3 PlayerDirection,D3DXVECTOR3 StickValue)
{
	float rotation=0.0f;
	if(g_game.mode==CUBE_UP)
	{
		rotation=atan2(PlayerDirection.x,PlayerDirection.z);
	}
	else if(g_game.mode==CUBE_BACK)
	{
		rotation=atan2(PlayerDirection.x,PlayerDirection.y);
	}
	else if(g_game.mode==CUBE_RIGHT)
	{
		rotation=atan2(-PlayerDirection.y,PlayerDirection.z);
	}
	return rotation;
}
/*
* @fn �v���C���[�̏�����
*/
void InitPlayer()
{
	g_hit_player={ -1,-1,-1,-1 };

	for(int i=0; i<2; i++)
	{
		if(!g_player[i])
		{
			g_player[i]=(PLAYER*)malloc(sizeof(PLAYER));
			g_player[i]->obj=NULL;
			g_player[i]->animetion=NULL;
		}

		if(!g_player[i]->obj)
		{
			g_player[i]->obj=(OBJECT*)malloc(sizeof(OBJECT));
		}
		if(!g_player[i]->animetion)
		{
			g_player[i]->animetion=(ANIME*)malloc(sizeof(ANIME));
		}

		ZeroMemory(g_player[i]->animetion,sizeof(ANIME));
		ZeroMemory(g_player[i]->obj,sizeof(OBJECT));

		g_player[i]->obj->draw_use=true;
		g_player[i]->obj->scale.x=1.0f;
		g_player[i]->obj->scale.y=1.0f;
		g_player[i]->obj->scale.z=1.0f;
		g_player[i]->obj->pos.x=0.0f;
		g_player[i]->obj->pos.y=50.0f;
		g_player[i]->obj->pos.z=0.0f;
		g_player[i]->obj->rotation.y=3.14f;
		g_player[i]->state=PLAYER_STATE_IDLE;
		g_player[i]->animetion->frame=0.0f;
		g_player[i]->animetion->delete_time=g_layer_wait_time;
		g_player[i]->radius=30.0f;
		g_player[i]->pupa_count=0;

		D3DXMatrixIdentity(&g_player[i]->transform);
		SetAnimetion(g_player[i]->animetion,(const char*)PLAYER_WAIT);

		char* filename[2]={
			{"player"},
			{"kago"},
		};
		int type[2]={
			{FBXTYPE_PLAYER_RITU},
			{FBXTYPE_KAGO},
		};

		if(!g_player[i]->obj->name)
			g_player[i]->obj->name=(char*)malloc(sizeof(filename[i]));
		strcpy(g_player[i]->obj->name,filename[i]);
		g_player[i]->transform=g_fbx_list[type[i]].transform;
		g_fbx_list[type[i]].Play(
			(std::string)g_player[i]->animetion->motion_name);
	}
}
/*
*	@fn ���͈̔͊g��
*/
bool CangeLine(float* line,float center,float value)
{
	bool result=false;
	if(*line==center+value)
	{
		*line=center+(-1*value);
		result=true;
	}
	return result;
}
/*
*	@fn �v���C���[�̑ҋ@��Ԃ̏���
*/
void PlayerIdle()
{
	for(int i=0; i<2; i++)
	{
		if(g_input_state[INPUT_STATE_PADTRG] & PAD_B)
		{
			/*��ԕύX*/
			g_player[i]->state=PLAYER_STATE_PURIFICATION;
			DSoundStop(g_se[SE_PURIFICATION]);
			DSoundPlay(g_se[SE_PURIFICATION],false);
			int type[2]={
				{FBXTYPE_PLAYER_RITU},
				{FBXTYPE_KAGO},
			};
			g_player[i]->animetion->delete_time=g_layer_purification_time;
			/*�A�j���[�V�����̕ύX*/
			SetAnimetion(g_player[i]->animetion,
				(const char*)PLAYER_PURIFICATION);
			/*�Đ�*/
			g_fbx_list[type[i]].Play(
				(std::string)g_player[i]->animetion->motion_name);
		}
		float stick_x=(float)(g_controller.lslx*0.005);
		float stick_z=(float)(g_controller.lsly*0.005);
		D3DXVECTOR3 stick={ stick_x ,0.0f,stick_z };
		/*�~�܂��Ă��Ȃ��Ȃ�*/
		if(stick.x!=0 || stick.z!=0)
		{
			SetAnimetion(g_player[i]->animetion,PLAYER_WALK);
			g_player[i]->state=PLAYER_STATE_WALK;
			DSoundStop(g_se[SE_MOVE]);
			DSoundPlay(g_se[SE_MOVE],true);
			g_player[i]->animetion->delete_time=g_layer_walk_time;
			if(i==0)
			{
				g_fbx_list[FBXTYPE_PLAYER_RITU].Play(
					(std::string)g_player[i]->animetion->motion_name);
			}
			else
			{
				g_fbx_list[FBXTYPE_KAGO].Play(
					(std::string)g_player[i]->animetion->motion_name);
			}
		}
	}
}
/*
*	@fn �v���C���[�̕�����Ԃ̏���
*/
void PlayerWalk()
{
	for(int i=0; i<2; i++)
	{
		float stick_x=(float)(g_controller.lslx*0.005);
		float stick_z=(float)(g_controller.lsly*0.005);
		D3DXVECTOR3 stick={ stick_x ,0.0f,stick_z };
		D3DXVECTOR3 player_old_pos=g_player[i]->obj->pos;
		if(stick.x==0 && stick.z==0)
		{
			SetAnimetion(g_player[i]->animetion,PLAYER_WAIT);
			g_player[i]->state=PLAYER_STATE_IDLE;
			DSoundStop(g_se[SE_MOVE]);
			g_player[i]->animetion->delete_time=g_layer_wait_time;
			int type[2]={
				{FBXTYPE_PLAYER_RITU},
				{FBXTYPE_KAGO},
			};
			g_fbx_list[type[i]].Play(
				(std::string)g_player[i]->animetion->motion_name);
		}
		else
		{
			if(g_input_state[INPUT_STATE_PADTRG] & PAD_B)
			{
				/*��ԕύX*/
				g_player[i]->state=PLAYER_STATE_PURIFICATION;
				DSoundStop(g_se[SE_MOVE]);
				DSoundStop(g_se[SE_PURIFICATION]);
				DSoundPlay(g_se[SE_PURIFICATION] ,false);
				if(i==0)
				{
					/*�Đ����x�ύX*/
					g_player[i]->animetion->delete_time=
						g_layer_purification_time;
					/*�A�j���[�V�����̕ύX*/
					SetAnimetion(g_player[i]->animetion,
						(const char*)PLAYER_PURIFICATION);
					/*�Đ�*/
					g_fbx_list[FBXTYPE_PLAYER_RITU].Play(
						(std::string)g_player[i]->animetion->motion_name);
				}
				else
				{
					g_player[i]->animetion->delete_time=
						g_layer_purification_time;
					SetAnimetion(g_player[i]->animetion,
						(const char*)PLAYER_PURIFICATION);
					g_fbx_list[FBXTYPE_KAGO].Play(
						(std::string)g_player[i]->animetion->motion_name);
				}
			}
			/*�J�����̕���������*/
			D3DXVECTOR3 player_local_pos={0.0f,0.0f,0.0f};
			D3DXVECTOR3 player_local_rotation={0.0f,0.0f,0.0f};
			D3DXVECTOR3 player_local_scale={1.0f,1.0f,1.0f};
			D3DXMATRIX player_local_mat;
			D3DXMATRIX player_world_mat;
			
			if(g_game.mode==CUBE_UP)
			{
				float angle_y=g_camera.angle.y;

				float mat2_2[2][2]={
						{stick.x*cos(angle_y),stick.z*-sin(angle_y)},
						{stick.x*sin(angle_y),stick.z*cos(angle_y)}
				};
				stick.x=(float)mat2_2[0][0]+(float)mat2_2[0][1];
				stick.z=(float)mat2_2[1][0]+(float)mat2_2[1][1];
				/*�v���C���[�ƃJ�S�̈ړ�*/
				g_player[i]->obj->pos.x+=stick.x;
				g_player[i]->obj->pos.z+=stick.z;
				/*�t�H���[�h�x�N�g������*/
				D3DXVECTOR3 player_forward=g_player[i]->obj->pos-player_old_pos;
				g_player[i]->obj->rotation.y=RotationPlayer(player_forward,stick);
			}
			else if(g_game.mode==CUBE_BACK)
			{
				/*�v���C���[�ƃJ�S�̈ړ�*/
				g_player[i]->obj->pos.x+=stick.x;
				g_player[i]->obj->pos.y+=stick.z;
				/*�t�H���[�h�x�N�g������*/
				D3DXVECTOR3 player_forward=g_player[i]->obj->pos-player_old_pos;
				player_local_rotation.y=RotationPlayer(player_forward,stick);
				player_local_mat=SetMatrix(player_local_pos,
										   player_local_rotation,player_local_scale);
				D3DXVECTOR3 rotation={ -ANGLE*90.0f,0.0f,0.0f };
				player_world_mat=SetMatrix(
					g_player[i]->obj->pos,rotation,g_player[i]->obj->scale);
				D3DXMATRIX world=player_local_mat*player_world_mat;
				g_player[i]->obj->rotation=GetRotation(world);
			}
			else if(g_game.mode==CUBE_FORWARD)
			{
				stick.x*=-1;
				/*�v���C���[�ƃJ�S�̈ړ�*/
				g_player[i]->obj->pos.x+=stick.x;
				g_player[i]->obj->pos.y+=stick.z;
				/*�t�H���[�h�x�N�g������*/
				D3DXVECTOR3 player_forward=g_player[i]->obj->pos-player_old_pos;
				player_local_rotation.y=RotationPlayer(player_forward,stick);
				player_local_mat=SetMatrix(player_local_pos,
										   player_local_rotation,
										   player_local_scale);
				D3DXVECTOR3 rotation={ ANGLE*90.0f,0.0f,0.0f };
				player_world_mat=SetMatrix(g_player[i]->obj->pos,
										   rotation,g_player[i]->obj->scale);
				D3DXMATRIX world=player_local_mat*player_world_mat;
				g_player[i]->obj->rotation=GetRotation(world);
			}
			else if(g_game.mode==CUBE_LEFT)
			{
				stick.x*=-1;
				g_player[i]->obj->pos.z+=stick.x;
				g_player[i]->obj->pos.y+=stick.z;
				/*�t�H���[�h�x�N�g������*/
				D3DXVECTOR3 player_forward=g_player[i]->obj->pos-player_old_pos;
				player_local_rotation.y=RotationPlayer(player_forward,stick);
				player_local_mat=SetMatrix(player_local_pos,
										   player_local_rotation,
										   player_local_scale);
				D3DXVECTOR3 rotation={ 0.0f,0.0f,ANGLE*90.0f };
				player_world_mat=SetMatrix(g_player[i]->obj->pos,
										   rotation,g_player[i]->obj->scale);
				D3DXMATRIX world=player_local_mat*player_world_mat;
				g_player[i]->obj->rotation=GetRotation(world);

			}
			else if(g_game.mode==CUBE_RIGHT)
			{
				g_player[i]->obj->pos.z+=stick.x;
				g_player[i]->obj->pos.y+=stick.z;
				/*�t�H���[�h�x�N�g������*/
				D3DXVECTOR3 player_forward=g_player[i]->obj->pos-player_old_pos;
				player_local_rotation.y=RotationPlayer(player_forward,stick);
				player_local_mat=SetMatrix(player_local_pos,
										   player_local_rotation,
										   player_local_scale);
				D3DXVECTOR3 rotation={0.0f,0.0f,-ANGLE*90.0f };
				player_world_mat=SetMatrix(g_player[i]->obj->pos,
										   rotation,g_player[i]->obj->scale);
				D3DXMATRIX world=player_local_mat*player_world_mat;
				g_player[i]->obj->rotation=GetRotation(world);
			}
			
		}
	}
}
/*
*	@fn �v���C���[�򉻃��[�V����
*/
void PlayerPurification()
{
	for(int i=0; i<2; i++)
	{
		if(i==0)
		{
			int ritumotion_frame=g_fbx_list[FBXTYPE_PLAYER_RITU].GetMotionFrame();
			if(g_fbx_list[FBXTYPE_PLAYER_RITU].Frame>=ritumotion_frame-2)
			{
				g_player[i]->state=PLAYER_STATE_IDLE;
				g_player[i]->animetion->delete_time=g_layer_wait_time;
				SetAnimetion(g_player[i]->animetion,(const char*)PLAYER_WAIT);
				g_fbx_list[FBXTYPE_PLAYER_RITU].Play(
					(std::string)g_player[0]->animetion->motion_name);
				OBJECT** pupa=GetStagePupa();
				if(g_hit_player.pupa_no!=-1)
				{
					if(g_game.stage==ONE)
					{
						int story1[][2] =
						{
							{STAGE1_1_1,STAGE1_1_3},
							{STAGE1_2_1,STAGE1_2_2},
						};
						InitAdventure(story1[g_hit_player.pupa_no][0],
									  story1[g_hit_player.pupa_no][1]);
						pupa[g_hit_player.pupa_no]->draw_use=false;
						g_hit_player.pupa_no=-1;
						g_player[0]->pupa_count+=1;
						g_player[1]->pupa_count+=1;
					}
					else if(g_game.stage==TWO)
					{
						if(strcmp(pupa[g_hit_player.pupa_no]->name,"culture_tank")!=0)
						{
							int no=0;
							int story2[][2] =
							{
								{KAGARI_1_1,KAGARI_1_10},
								{KAGARI_2_1,KAGARI_2_10},
								{KAGARI_3_1,KAGARI_3_11},
								{KAGARI_4_1,KAGARI_4_8},
								{KAGARI_5_1,KAGARI_5_9},
								{KAGARI_6_1,KAGARI_6_11},
								{KAGARI_7_1,KAGARI_7_5},
								{KAGARI_8_1,KAGARI_8_2},
							};
							if(g_hit_player.pupa_no<GetStagePupaCount()-1)
							{
								if(strcmp(pupa[g_hit_player.pupa_no+1]->name,
								   "culture_tank")==0)
								{
									pupa[g_hit_player.pupa_no+1]->draw_use=false;
								}
							}
							no=g_hit_player.pupa_no;
							int sub_count=0;
							for(int no_count=0; no_count<no; no_count++)
							{
								if(strcmp(pupa[no_count]->name,"culture_tank")==0)
								{
									sub_count++;
								}
							}
							no=no-sub_count;
							InitAdventure(story2[no][0],story2[no][1]);
							pupa[g_hit_player.pupa_no]->draw_use=false;
							g_hit_player.pupa_no=-1;
							g_player[0]->pupa_count+=1;
							g_player[1]->pupa_count+=1;
						}
					}
					else if(g_game.stage==THREE)
					{
						if(strcmp(pupa[g_hit_player.pupa_no]->name,
						   "culture_tank")!=0)
						{
							int no=0;
							int story3[][2] =
							{
								{LUI_1_1,LUI_1_10},
								{LUI_2_1,LUI_2_9},
								{LUI_3_1,LUI_3_8},
								{LUI_4_1,LUI_4_9},
								{LUI_5_1,LUI_5_6},
								{LUI_6_1,LUI_6_14},
								{LUI_7_1,LUI_7_5},
								{LUI_8_1,LUI_8_2},
							};
							if(g_hit_player.pupa_no<GetStagePupaCount()-1)
							{
								if(strcmp(pupa[g_hit_player.pupa_no+1]->name,
								   "culture_tank")==0)
								{
									pupa[g_hit_player.pupa_no+1]->draw_use=false;
								}
							}
							no=g_hit_player.pupa_no;
							int sub_count=0;
							for(int no_count=0; no_count<no; no_count++)
							{
								if(strcmp(pupa[no_count]->name,"culture_tank")==0)
								{
									sub_count++;
								}
							}
							no=no-sub_count;
							InitAdventure(story3[no][0],story3[no][1]);
							pupa[g_hit_player.pupa_no]->draw_use=false;
							g_hit_player.pupa_no=-1;
							g_player[0]->pupa_count+=1;
							g_player[1]->pupa_count+=1;
						}
					}
				}
				if(g_hit_player.roll_no!=-1)
				{
					bool rotation=false;
					if(g_game.stage==ONE)
					{
						int clear_count[]=
						{
							1,0
						};
						if(g_player[i]->pupa_count==
						   clear_count[g_hit_player.roll_no])
						{
							rotation=true;
						}
						else
						{
							rotation=false;
							g_player[i]->state=PLAYER_STATE_IDLE;
							InitAdventure(PUPA_COUNT,PUPA_COUNT);
						}
						if(rotation)
						{
							g_player[i]->state=PLAYER_STATE_ROTATION;
							g_roll1[g_hit_player.roll_no].process_flg=true;
							g_roll1[g_hit_player.roll_no].player_old_position=
								g_player[i]->obj->pos;
							g_roll1[g_hit_player.roll_no].player_old_rotation=
								g_player[i]->obj->rotation;
						}
					}
					else if(g_game.stage==TWO|| g_game.stage==THREE)
					{
						int clear_count2[]=
						{
							1,3,6,7
						};
						if(g_player[i]->pupa_count==
						   clear_count2[g_hit_player.roll_no])
						{
							rotation=true;
						}
						else
						{
							rotation=false;
							g_player[i]->state=PLAYER_STATE_IDLE;
							InitAdventure(PUPA_COUNT,PUPA_COUNT);
						}
						if(rotation)
						{
							g_player[i]->state=PLAYER_STATE_ROTATION;
							g_roll2[g_hit_player.roll_no].process_flg=true;
							g_roll2[g_hit_player.roll_no].player_old_position=
								g_player[i]->obj->pos;
							g_roll2[g_hit_player.roll_no].player_old_rotation=
								g_player[i]->obj->rotation;
						}
					}
				}
				if(g_hit_player.base_no!=-1)
				{
					OBJECT** base=GetStageBase();
					if(strcmp(base[g_hit_player.base_no]->name,"warp")==0)
					{
						int no=g_hit_player.base_no-68;
						int warp[][2]={
							{68,69},
							{69,68},
							{70,71},
							{71,70},
							{72,73},
							{73,72},
							{74,75},
							{75,74}
						};
						for(int i=0; i<2; i++)
						{
							g_warp_no.warp_1=warp[no][0];
							g_warp_no.warp_2=warp[no][1];
							g_warp_no.percentage=0;
							g_player[i]->state=PLAYER_STATE_WARP;
							g_player[i]->obj->draw_use=false;
						}
					}
				}
			}
		}
		else
		{
			int ritumotion_frame=g_fbx_list[FBXTYPE_KAGO].GetMotionFrame();
			if(g_fbx_list[FBXTYPE_KAGO].Frame>=ritumotion_frame-2)
			{
				g_player[i]->state=PLAYER_STATE_IDLE;
				g_player[i]->animetion->delete_time=g_layer_wait_time;
				SetAnimetion(g_player[i]->animetion,(const char*)PLAYER_WAIT);
				g_fbx_list[FBXTYPE_KAGO].Play(
					(std::string)g_player[1]->animetion->motion_name);
				if(g_hit_player.roll_no!=-1)
				{
					if(g_player[i]->pupa_count>0 && g_hit_player.roll_no==0)
					{
						g_player[i]->state=PLAYER_STATE_ROTATION;	
					}
					else if(g_player[i]->pupa_count==0 && g_hit_player.roll_no==1)
					{
						g_player[i]->state=PLAYER_STATE_ROTATION;
					}
					else
					{
						g_player[i]->state=PLAYER_STATE_IDLE;
					}
				}
			}
		}
	}
}
/*
*	@fn �v���C���[����]�L���[�u�ƈꏏ�ɉ��
*/
void PlayerRotation()
{
	ROLL* roll=GetStageRoll();
	D3DXVECTOR3 player_local_rotation=
		roll[g_hit_player.roll_no].player_old_rotation;
	D3DXVECTOR3 player_local_position=
		roll[g_hit_player.roll_no].player_old_position-
		roll[g_hit_player.roll_no].obj->pos;
	//�������ĉ�]���Ă���L���[�u�̏��ɍX�V
	D3DXVECTOR3 cube_world_pos=roll[g_hit_player.roll_no].obj->pos;
	D3DXVECTOR3 cube_world_rotation={
		roll[g_hit_player.roll_no].limit_x,
		roll[g_hit_player.roll_no].limit_y,
		roll[g_hit_player.roll_no].limit_z
	};
	D3DXVECTOR3 cube_world_scale=roll[g_hit_player.roll_no].obj->scale;
	D3DXMATRIX cube_world=SetMatrix(cube_world_pos,
									cube_world_rotation,
									cube_world_scale);
	D3DXVECTOR3 player_local_scale{ 1.0f,1.0f,1.0f };
	D3DXMATRIX player=SetMatrix(player_local_position ,
								   player_local_rotation ,
								   player_local_scale);
	D3DXMATRIX mat=player*cube_world;
	D3DXVECTOR3 rotation=GetRotation(mat);
	if(roll[g_hit_player.roll_no].process_flg)
	{
		for(int i=0; i<2; i++)
		{
			g_player[i]->obj->pos.x=mat._41;
			g_player[i]->obj->pos.y=mat._42;
			g_player[i]->obj->pos.z=mat._43;
			g_player[i]->obj->rotation=rotation;
		}
	}
	else
	{
		for(int i=0; i<2; i++)
		{
			g_player[i]->state=PLAYER_STATE_IDLE;
			g_player[i]->obj->pos.x=roundf(g_player[i]->obj->pos.x);
			g_player[i]->obj->pos.y=roundf(g_player[i]->obj->pos.y);
			g_player[i]->obj->pos.z=roundf(g_player[i]->obj->pos.z);
			g_game.mode=roll[g_hit_player.roll_no].change_mode;
		}
		if(roll[g_hit_player.roll_no].is_rotation_process_flg==false)
		{
			roll[g_hit_player.roll_no].is_rotation_process_flg=true;
		}
	}
}
/*
* @fn ��`��ό`����
* @param ���ݓ������Ă���i����Ă���j�I�u�W�F�N�g
* @param �ׂ荇���Ă���I�u�W�F�N�g
* @param ��`��left	pointa
* @param ��`��top pointa
* @param ��`��right pointa
* @param ��`��bottom pointa
*/
void CangeLine2(OBJECT* obj_1,OBJECT* obj_2,float *left,float *top,
				float *right,float *bottom,CHECK_RECT* check_line)
{
	if(!obj_2->hit_use[g_game.mode])return;
	if(g_game.mode==CUBE_UP)
	{
		if(obj_1->pos.y==obj_2->pos.y)
		{
			if(obj_1->pos.z==obj_2->pos.z)
			{
				check_line->left=CangeLine(left,obj_2->pos.x+SIZE_MINUS,
										   obj_2->size.x);
				check_line->right=CangeLine(right,obj_2->pos.x-SIZE_MINUS,
											-obj_2->size.x);
			}
			if(obj_1->pos.x==obj_2->pos.x)
			{
				check_line->top=CangeLine(top,obj_2-> pos.z-SIZE_MINUS,
										  -obj_2->size.z);
				check_line->bottom=CangeLine(bottom,obj_2->pos.z+ SIZE_MINUS,
											 obj_2->size.z);
			}
		}
	}
	else if(g_game.mode==CUBE_BACK)
	{
		if(obj_1->pos.z==obj_2->pos.z)
		{
			if(obj_1->pos.y==obj_2->pos.y)
			{
				check_line->left=CangeLine(left,obj_2->pos.x+SIZE_MINUS,
										   obj_2->size.x);
				check_line->right=CangeLine(right,obj_2->pos.x-SIZE_MINUS,
											-obj_2->size.x);
			}
			if(obj_1->pos.x==obj_2->pos.x)
			{
				check_line->top=CangeLine(top,obj_2->pos.y-SIZE_MINUS,
										  -obj_2->size.y);
				check_line->bottom=CangeLine(bottom,obj_2->pos.y+SIZE_MINUS,
											 obj_2->size.y);
			}
		}
	}
	else if(g_game.mode==CUBE_RIGHT)
	{
		if(obj_1->pos.x==obj_2->pos.x)
		{
			if(obj_1->pos.y==obj_2->pos.y)
			{
				check_line->left=CangeLine(left,obj_2->pos.z+SIZE_MINUS,
										   obj_2->size.z);
				check_line->right=CangeLine(right,obj_2->pos.z-SIZE_MINUS,
											-obj_2->size.z);
			}
			if(obj_1->pos.z==obj_2->pos.z)
			{
				check_line->top=CangeLine(top,obj_2->pos.y-SIZE_MINUS,
										  -obj_2->size.y);
				check_line->bottom=CangeLine(bottom,obj_2->pos.y+SIZE_MINUS,
											 obj_2->size.y);
			}
		}
	}
}
/*
*	@fn �x�[�X�u���b�N�̑傫���ݒ�
*	@param *obj	�I�u�W�F�N�g�|�C���^
*	@param *left
*	@param *top
*	@param *right
*	@param *bottom
*/
void SetLeftTopRightBottom(OBJECT*obj,float *left,float* top,
						   float*right,float*bottom)
{
	if(g_game.mode==CUBE_UP)
	{
		*left=obj->pos.x-obj->size.x;
		*right=obj->pos.x+obj->size.x;
		*top=obj->pos.z+obj->size.z;
		*bottom=obj->pos.z-obj->size.z;
	}
	else if(g_game.mode==CUBE_BACK)
	{
		*left=obj->pos.x-obj->size.x;
		*right=obj->pos.x+obj->size.x;
		*top=obj->pos.y+obj->size.y;
		*bottom=obj->pos.y-obj->size.y;
	}
	else if(g_game.mode==CUBE_RIGHT)
	{
		*left=obj->pos.z-obj->size.z;
		*right=obj->pos.z+obj->size.z;
		*top=obj->pos.y+obj->size.y;
		*bottom=obj->pos.y-obj->size.y;
	}
}
/*
* @fn �v���C���[�����ꂩ��͂ݏo���ꍇ�ɖ߂�
* @param ��`��left
* @param ��`��top
* @param ��`��right
* @param ��`��bottom
* @param ���̃|�W�V����
* @param �ړ��O�̃|�W�V����
* @oaram ���a
*/
void ReturnPlayerPosition(float left,float top,float right,float bottom,
						  D3DXVECTOR3 pos,D3DXVECTOR3 player_old_position,D3DXVECTOR3 forward)
{

	for(int i=0; i<2; i++)
	{
		if(g_game.mode==CUBE_UP)
		{
			if(g_player[i]->obj->pos.x<left)
			{
				g_player[i]->obj->pos.x=left+1;
			}
			if(g_player[i]->obj->pos.x>right)
			{
				g_player[i]->obj->pos.x=right-1;
			}
			if(g_player[i]->obj->pos.z<bottom)
			{
				g_player[i]->obj->pos.z=bottom+1;
			}
			if(g_player[i]->obj->pos.z>top)
			{
				g_player[i]->obj->pos.z=top-1;
			}
			
		}
		else if(g_game.mode==CUBE_BACK)
		{
			if(g_player[i]->obj->pos.x<left)
			{
				g_player[i]->obj->pos.x=left+1;
			}
			if(g_player[i]->obj->pos.x>right)
			{
				g_player[i]->obj->pos.x=right-1;
			}
			if(g_player[i]->obj->pos.y<bottom)
			{
				g_player[i]->obj->pos.y=bottom+1;
			}
			if(g_player[i]->obj->pos.y>top)
			{
				g_player[i]->obj->pos.y=top-1;
			}
		}
		else if(g_game.mode==CUBE_RIGHT)
		{
			if(g_player[i]->obj->pos.z<left)
			{
				g_player[i]->obj->pos.z=left+1;
			}
			if(g_player[i]->obj->pos.z>right)
			{
				g_player[i]->obj->pos.z=right-1;
			}
			if(g_player[i]->obj->pos.y<bottom)
			{
				g_player[i]->obj->pos.y=bottom+1;
			}
			if(g_player[i]->obj->pos.y>top)
			{
				g_player[i]->obj->pos.y=top-1;
			}
		}
	}
}
/*
* @fn �ړ���̃v���C���[�̑����̓����蔻��
* @param �v���C���[�̈ړ��O�ʒu
*/
void HitPlayerFoot(D3DXVECTOR3 player_old_position)
{
	for(int i=0; i<2; i++)
	{
		/*player�Ƒ��̕��̂̓����蔻��*/
		D3DXVECTOR3 forward,out,normal,pos,vec;
		out={0,0,0};
		normal={0,0,0};
		pos={g_player[0]->obj->pos.x,
			g_player[0]->obj->pos.y,
			g_player[0]->obj->pos.z};
		forward=pos-player_old_position;
		D3DXVec3Normalize(&forward,&forward);
		vec=GetRayCastVec();
		D3DXVECTOR3 cange_pos=GetRayCastCangePos();
		pos=pos+cange_pos;
		float dist=20;
		bool player_hit=false;
		int base_max=GetStageBaseCount();
		OBJECT** base=GetStageBase();
		for(int loop_base=0; loop_base<base_max; loop_base++)
		{
			if(player_hit)
			{
				break;
			}
			if(!base[loop_base]->hit_use[g_game.mode])
			{
				continue;
			}
			if(strcmp(base[loop_base]->name,"goal")==0)
			{
				FbxUpdate(g_fbx_list,FBXTYPE_GOAL,base[loop_base]);
				if(g_fbx_list[FBXTYPE_GOAL].Raycast2(pos,vec,dist,out,normal)!=-1)
				{
					int limit_count=0;
					if(g_game.stage==ONE)
					{
						limit_count=2;
					}
					else if(g_game.stage==TWO)
					{
						limit_count=8;
					}
					if(g_player[0]->pupa_count<limit_count)
					{
						DSoundStop(g_se[SE_MOVE]);
						for(int p=0; p<2; p++)
						{
							g_player[p]->state=PLAYER_STATE_IDLE;
							g_player[p]->obj->pos=player_old_position;
							g_player[p]->animetion->delete_time=g_layer_wait_time;
							SetAnimetion(
								g_player[p]->animetion,(const char*)PLAYER_WAIT);
							if(p==0)
							{
								g_fbx_list[FBXTYPE_PLAYER_RITU].Play(
									(std::string)g_player[0]->animetion->motion_name);
							}
							else
							{
								g_fbx_list[FBXTYPE_KAGO].Play(
									(std::string)g_player[1]->animetion->motion_name);
							}
						}
						InitAdventure(PUPA_COUNT,PUPA_COUNT);
						break;
					}
					//DSoundStop(g_bgm[BGM_TITLE]);
					g_game.state=GOAL;
					InitGoal();
					for(int p=0; p<2; p++)
					{
						SetAnimetion(g_player[p]->animetion,PLAYER_WAIT);
						if(p==0)
						{
							g_fbx_list[FBXTYPE_PLAYER_RITU].Play(
								g_player[p]->animetion->motion_name);
						}
						else
						{
							g_fbx_list[FBXTYPE_KAGO].Play(
								g_player[p]->animetion->motion_name);
						}
					}
					DSoundStop(g_se[SE_MOVE]);
					g_hit_player.base_no=loop_base;
					g_hit_player.lift_no=-1;
					g_hit_player.roll_no=-1;
					player_hit=true;
					break;
				}
			}
			struct FBXCHECK_TABLE table[]=
			{
				{"base",FBXTYPE_BASE},
			{"base_2",FBXTYPE_BASE_2},
			{"base_b",FBXTYPE_BASE_3},
			{"warp",FBXTYPE_WARP},
			};
			for(int i=0;i<4;i++)
			{
				if(strcmp(base[loop_base]->name,table[i].name)==0)
				{
					FbxUpdate(g_fbx_list,table[i].fbx_type,base[loop_base]);
					if(g_fbx_list[table[i].fbx_type].Raycast2(pos,vec,dist,out,normal)!=-1)
					{
						g_hit_player.base_no=loop_base;
						g_hit_player.lift_no=-1;
						g_hit_player.roll_no=-1;
						player_hit=true;
						break;
					}
				}
			}
		}
		ROLL* roll=GetStageRoll();
		int roll_max=GetStageRollCount();
		if(!player_hit)
		{
			for(int loop_roll=0; loop_roll<roll_max; loop_roll++)
			{
				FbxUpdate(g_fbx_list,FBXTYPE_ROLL,roll[loop_roll].obj);
				if(g_fbx_list[FBXTYPE_ROLL].Raycast2(pos,vec,dist,out,normal)!=-1)
				{
					g_hit_player.base_no=-1;
					g_hit_player.lift_no=-1;
					g_hit_player.roll_no=loop_roll;
					player_hit=true;
					break;
				}
			}
		}
		LIFT* lift=GetStageLift();
		int lift_max=GetStageLiftCount();
		if(!player_hit)
		{
			for(int loop_lift=0; loop_lift<lift_max; loop_lift++)
			{
				FbxUpdate(g_fbx_list,FBXTYPE_LIFT,lift[loop_lift].obj);
				if(g_fbx_list[FBXTYPE_LIFT].Raycast2(pos,vec,dist,out,normal)!=-1)
				{
					g_hit_player.base_no=-1;
					g_hit_player.lift_no=loop_lift;
					g_hit_player.roll_no=-1;
					player_hit=true;
					break;
				}
			}
		}
		float left=0.0f,top=0.0f,right=0.0f,bottom=0.0f;
		if(g_hit_player.base_no!=-1)
		{
			SetLeftTopRightBottom(base[g_hit_player.base_no],
								  &left,&top,&right,&bottom);
		}
		if(g_hit_player.lift_no!=-1)
		{
			SetLeftTopRightBottom(lift[g_hit_player.lift_no].obj,
								  &left,&top,&right,&bottom);
		}
		if(g_hit_player.roll_no!=-1)
		{
			SetLeftTopRightBottom(roll[g_hit_player.roll_no].obj,
								  &left,&top,&right,&bottom);
		}
		struct CHECK_RECT check_line={false};
		//�O�㍶�E�̋�`
		struct MY_RECT rect[4]={
			{left,top,right,bottom},
		{left,top,right,bottom},
		{left,top,right,bottom},
		{left,top,right,bottom}
		};
		//�����蔻��
		for(int i=0; i<base_max; i++)//base�̐�-2(goal,start)
		{
			if(strcmp(base[i]->name,"strat")==0)
			{
				continue;
			}
			for(int l=0; l<lift_max; l++)//lift�̐�
			{
				for(int r=0; r<roll_max; r++)//roll�̐�
				{
					//�x�[�X�𓥂�ł�����
					if(g_hit_player.base_no!=-1)
					{
						if(g_hit_player.base_no==i)continue;
						CangeLine2(base[g_hit_player.base_no],base[i],
								   &left,&top,&right,&bottom,&check_line);
						CangeLine2(base[g_hit_player.base_no],roll[r].obj,
								   &left,&top,&right,&bottom,&check_line);
						CangeLine2(base[g_hit_player.base_no],lift[l].obj,
								   &left,&top,&right,&bottom,&check_line);
					}
					if(g_hit_player.roll_no!=-1)
					{
						if(g_hit_player.roll_no==r)continue;
						CangeLine2(roll[g_hit_player.roll_no].obj,base[i],
								   &left,&top,&right,&bottom,&check_line);
						CangeLine2(roll[g_hit_player.roll_no].obj,roll[r].obj,
								   &left,&top,&right,&bottom,&check_line);
						CangeLine2(roll[g_hit_player.roll_no].obj,lift[l].obj,
								   &left,&top,&right,&bottom,&check_line);
					}
					if(g_hit_player.lift_no!=-1)
					{
						if(g_hit_player.lift_no==l)continue;
						CangeLine2(lift[g_hit_player.lift_no].obj,
								   base[i],&left,&top,&right,&bottom,&check_line);
						CangeLine2(lift[g_hit_player.lift_no].obj,
								   roll[r].obj,&left,&top,&right,&bottom,&check_line);
						CangeLine2(lift[g_hit_player.lift_no].obj,
								   lift[l].obj,&left,&top,&right,&bottom,&check_line);
					}
				}
			}
		}
		ReturnPlayerPosition(left,top,right,bottom,pos,
							 player_old_position,forward);
	}
}
/*
* @fn�@�v���C���[�����t�g�ƂƂ��Ɉړ�����
*/
void PlayerLiftMove()
{
	LIFT* lift=GetStageLift();
	if(g_hit_player.lift_no!=-1)//lift�ɍŌ�ɏ���Ă����Ȃ�
	{
		for(int i=0; i<2; i++)
		{
			/*�ړ��O�|�W�V�����m��*/
			D3DXVECTOR3 player_old_pos=g_player[i]->obj->pos;
			//�ړ�
			D3DXVECTOR3 local_rotation={ 0.0f,0.0f,0.0f };
			D3DXVECTOR3 local_scale={ 1.0f,1.0f,1.0f };
			D3DXMATRIX local_mat=SetMatrix(lift[g_hit_player.lift_no].delta,
										   local_rotation,local_scale);
			D3DXMATRIX lift_mat=SetMatrix(D3DXVECTOR3(0.0f,0.0f,0.0f),
										  lift[g_hit_player.lift_no].obj->rotation,
										  lift[g_hit_player.lift_no].obj->scale);
			D3DXMATRIX world=local_mat*lift_mat;
			FbxUpdate(g_fbx_list,FBXTYPE_LIFT,lift[g_hit_player.lift_no].obj);
			D3DXMATRIX world_lift=g_fbx_list[FBXTYPE_LIFT].transform;
			if(lift[g_hit_player.lift_no].move)
			{
				g_player[i]->obj->pos.x=g_player[i]->obj->pos.x+world._41;
				g_player[i]->obj->pos.y=g_player[i]->obj->pos.y+world._42;
				g_player[i]->obj->pos.z=g_player[i]->obj->pos.z+world._43;
			}
			D3DXVECTOR3 pos,vec,out,normal;
			D3DXVECTOR3 pos_cange=GetRayCastCangePos();
			/*�ړ���|�W�V��������*/
			pos=g_player[i]->obj->pos;
			//������
			vec=GetRayCastVec();
			float dist=20;
			FbxUpdate(g_fbx_list,FBXTYPE_LIFT,lift[g_hit_player.lift_no].obj);
			if(g_fbx_list[FBXTYPE_LIFT].Raycast2(pos+pos_cange,vec,dist,out,normal)==-1)
			{
				/*�������ĂȂ���Έړ��Ȃ�*/
				g_player[i]->obj->pos=player_old_pos;
			}
		}
	}
}

/*
*	@fn �v���C���[�������߂�����
*	@param pos�@�v���C���[�̈ʒu
*	@param in ���C�ƃ��b�V���̌�_
*	@param forward	�O���������x�N�g��
*	@return �����߂��ꂽ�ʒu
*/
D3DXVECTOR3 PushBack(D3DXVECTOR3 pos, D3DXVECTOR3 in,D3DXVECTOR3 forward)
{
	D3DXVECTOR3 result=pos;
	switch(g_game.mode)
	{
	case CUBE_UP:
	case CUBE_DOWN:
		result.x=in.x+(-1*forward.x*10)-pos.x;
		result.z=in.z+(-1*forward.z*10)-pos.z;
		break;
	case CUBE_BACK:
	case CUBE_FORWARD:
		result.x=in.x+(-1*forward.x*10)-pos.x;
		result.y=in.y+(-1*forward.y*10)-pos.y;
		break;
	case CUBE_RIGHT:
	case CUBE_LEFT:
		result.y=in.y+(-1*forward.y*10)-pos.y;
		result.z=in.z+(-1*forward.z*10)-pos.z;
		break;
	}
	return result;
}
/*
* @fn �v���C���[�����[�v�����鏈��
*/
void PlayerWarp()
{
	float radius=50.0f;
	OBJECT** obj=GetStageBase();
	D3DXVECTOR3 pos1=obj[g_warp_no.warp_1]->pos;
	D3DXVECTOR3 pos2=obj[g_warp_no.warp_2]->pos;
	D3DXVECTOR3 vector=pos2-pos1;
	vector=vector*0.01f;
	for(int i=0; i<2; i++)
	{
		g_player[i]->obj->pos=pos1;
		if(g_game.mode==CUBE_UP)
		{
			g_player[i]->obj->pos.y+=50;
		}
		else if(g_game.mode==CUBE_BACK)
		{
			g_player[i]->obj->pos.z-=50;
		}
		else if(g_game.mode==CUBE_RIGHT)
		{
			g_player[i]->obj->pos.x+=50;
		}
		g_player[i]->obj->pos+=vector*(float)g_warp_no.percentage;
	}
	g_warp_no.percentage+=5;
	if(g_warp_no.percentage==100)
	{
		for(int i=0; i<2; i++)
		{
			g_player[i]->state=PLAYER_STATE_IDLE;
			g_player[i]->obj->draw_use=true;
			g_player[i]->obj->pos=pos2;
			if(g_game.mode==CUBE_UP)
			{
				g_player[i]->obj->pos.y+=50;
			}
			else if(g_game.mode==CUBE_BACK)
			{
				g_player[i]->obj->pos.z-=50;
			}
			else if(g_game.mode==CUBE_RIGHT)
			{
				g_player[i]->obj->pos.x+=50;
			}
		}
		g_warp_no.percentage=0;
	}
}
/*
* @fn �v���C���[�̏���
*/
void ProcessPlayer()
{
	D3DXVECTOR3 player_old_position={ 
		g_player[0]->obj->pos.x ,
		g_player[0]->obj->pos.y,
		g_player[0]->obj->pos.z };
	switch(g_player[0]->state)
	{
	case PLAYER_STATE_IDLE:
		PlayerLiftMove();
		PlayerIdle();
		HitPlayerFoot(player_old_position);
		break;
	case PLAYER_STATE_WALK:
		ProcessPupa();
		PlayerLiftMove();
		PlayerWalk();
		HitPlayerFoot(player_old_position);
		break;
	case PLAYER_STATE_PURIFICATION:
		PlayerLiftMove();
		PlayerPurification();
		HitPlayerFoot(player_old_position);
		break;
	case PLAYER_STATE_ROTATION:
		PlayerRotation();
		break;
	case PLAYER_STATE_WARP:
		PlayerWarp();
		break;
	}
}
/*
* @fn �v���C���[�̕`��
*/
void DrawPlayer()
{
	for(int i=0; i<2; i++)
	{
		DrawFbx(g_player[i]->obj,g_fbx_list,g_player[i]->animetion);
		D3DXMATRIX tex_mat=SetMatrix(D3DXVECTOR3(0.0f,1.0f,0.0f) ,
										D3DXVECTOR3(0.0f,0.0f,0.0f) ,
										D3DXVECTOR3(20.0f ,20.0f ,20.0f));
		tex_mat=tex_mat*g_fbx_list[FBXTYPE_PLAYER_RITU].transform;
		if(g_player[i]->obj->draw_use)
		{
			DrawTexture2D3(g_tex[PLAYER_SHADOW],tex_mat);
		}
	}
}
/*
* @fn �v���C���[�J��
*/
void DeletePlayer()
{
	for(int i=0; i<2; i++)
	{
		if(g_player[i])
		{
			if(g_player[i]->animetion)
			{
				if(g_player[i]->animetion->motion_name)
				{
					free(g_player[i]->animetion->motion_name);
				}
				free(g_player[i]->animetion);
			}
			DeleteObj(g_player[i]->obj);
			free(g_player[i]);
		}
	}
}