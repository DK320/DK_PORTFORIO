/**
*	@file	lift.cpp
*	@brief	���t�g�̏���
*	@author	D.K
*	@data	2020/01/10
*/
#include"../Directx9/Directx9MyLib.h"
#include"../fbx/FbxMeshAmg.h"
#include"../game/game.h"
#include"../global/global.h"
#include"lift.h"
#include"../camera/camera.h"
#include"stage.h"
#include"player.h"

struct LIFT g_stage1_lift[STAGE1_LIFT_MAX];
struct LIFT g_stage2_lift[STAGE2_LIFT_MAX];
/*
*	@fn �e�X�e�[�W��LIFT�̐擪�A�h���X��Ԃ��܂�
*/
LIFT* GetStageLift()
{
	switch(g_game.stage)
	{
	case ONE:
		return &g_stage1_lift[0];
		break;
	case TWO:
	case THREE:
		return &g_stage2_lift[0];
		break;
	}
	return NULL;
}
/*
*	@fn �e�X�e�[�W�̃��t�g�̑�����Ԃ��܂�
*/
int GetStageLiftCount()
{
	switch(g_game.stage)
	{
	case ONE:
		return STAGE1_LIFT_MAX;
		break;
	case TWO:
	case THREE:
		return STAGE2_LIFT_MAX;
		break;
	}
	return NULL;
}
/*
*	@fn ���t�g�̏�����
*/
void InitLift()
{
	OBJECT*obj[2]={NULL};
	LIFT* lift= GetStageLift();
	char* filename[3]={
		{"Assets/stage/kagari1_lift.source"},
		{"Assets/stage/kagari2_lift.source"},
		{"Assets/stage/lui_lift.source"},
	};
	switch(g_game.stage)
	{
	case ONE:
		CreateStage(filename[ONE],obj);
		break;
	case TWO:
		CreateStage(filename[TWO],obj);
		break;
	case THREE:
		CreateStage(filename[THREE],obj);
		break;
	}
	for(int i=0; i< GetStageLiftCount(); i++)
	{
		if(g_game.stage==ONE)
		{
			lift[i].delta.x=0.0f;
			lift[i].delta.y=0.0f;
			lift[i].delta.z=-LIFT_SPEED;
		}if(g_game.stage==TWO || g_game.stage==THREE)
		{
			if(i==0)
			{
				lift[i].delta.x=0.0f;
				lift[i].delta.y=-LIFT_SPEED;
				lift[i].delta.z=0.0f;
			}
			else
			{
				lift[i].delta.x=0.0f;
				lift[i].delta.y=-LIFT_SPEED;;
				lift[i].delta.z=0.0f;
			}
		}
		if(g_game.stage==ONE)
		{
			if(i==0)
			{
				lift[i].limit_min.x=0.0f;
				lift[i].limit_min.y=0.0f;
				lift[i].limit_min.z=-1100+200;
				
				lift[i].limit_max.x=0.0f;
				lift[i].limit_max.y=0.0f;
				lift[i].limit_max.z=-200+200;
			}
			else if(i==1)
			{
				lift[i].limit_min.x=0.0f;
				lift[i].limit_min.y=0.0f;
				lift[i].limit_min.z=-2800+2000;
				lift[i].limit_max.x=-2000+2000;
				lift[i].limit_max.y=0.0f;
				lift[i].limit_max.z=0.0f;
			}
		}
		if(g_game.stage==TWO || g_game.stage==THREE)
		{
			if(i==0)
			{
				lift[i].limit_min.y=-600;
				lift[i].limit_max.y=0;
			}
			else if(i==1)
			{
				lift[i].limit_min.y=100-100;
				lift[i].limit_max.y=500-100;
			}
		}
		lift[i].move=true;
		lift[i].frame=0;
		lift[i].obj=obj[i];
		lift[i].initial_pos=obj[i]->pos;
		if(g_game.stage==ONE)
		{
			lift[i].obj->size.x=LIFT_WIDTH_HALF;
			lift[i].obj->size.y=LIFT_HEIGHT_HALF;
			lift[i].obj->size.z=LIFT_DEPTH_HALF;
		}
		else if(g_game.stage==TWO || g_game.stage==THREE)
		{
			if(i==0)
			{
				lift[i].obj->size.x=LIFT_DEPTH_HALF;
				lift[i].obj->size.y=LIFT_HEIGHT_HALF;
				lift[i].obj->size.z=LIFT_WIDTH_HALF;
			}
			else
			{
				lift[i].obj->size.x=LIFT_HEIGHT_HALF;
				lift[i].obj->size.y=LIFT_WIDTH_HALF; 
				lift[i].obj->size.z=LIFT_DEPTH_HALF;
				lift[i].obj->hit_use[CUBE_UP]=false;
			}

		}
		lift[i].local_pos={ 0.0f,0.0f,0.0f };
	}

}


/*
*	@fn���t�g�̏���
*	@param OBJECT* �z��̍ő吔
*	@param OBJECT* lift[]�|�C���^�z��
*/
void ProcessLift(int no,LIFT* lift)
{
	D3DXVECTOR3 local_rotation={ 0.0f,0.0f,0.0f };
	D3DXVECTOR3 local_scale={ 1.0f,1.0f,1.0f };
	D3DXMATRIX local_mat;
	D3DXMATRIX lift_mat;
	D3DXMATRIX world;
	D3DXVECTOR3 rotation;
	bool move=lift[no].move;

	if(!move)
	{
		lift[no].frame+=1;
		if(lift[no].frame>LIFT_IDLE_FRAME)
		{
			move=true;
			lift[no].frame=0;
		}
		else
		{
			move=false;
		}
	}

	if(move)
	{
		lift[no].local_pos.x+=lift[no].delta.x;
		lift[no].local_pos.y+=lift[no].delta.y;
		lift[no].local_pos.z+=lift[no].delta.z;
	}

	if(lift[no].local_pos.x<lift[no].limit_min.x)
	{
		lift[no].local_pos.x=lift[no].limit_min.x;
		lift[no].delta.x*=-1;
		move=false;
	}

	if(lift[no].local_pos.x>lift[no].limit_max.x)
	{
		lift[no].local_pos.x=lift[no].limit_max.x;
		lift[no].delta.x*=-1;
		move=false;
	}

	if(lift[no].local_pos.y<lift[no].limit_min.y)
	{
		lift[no].local_pos.y=lift[no].limit_min.y;
		lift[no].delta.y*=-1;
		move=false;
	}

	if(lift[no].local_pos.y>lift[no].limit_max.y)
	{
		lift[no].local_pos.y=lift[no].limit_max.y;
		lift[no].delta.y*=-1;
		move=false;
	}

	if(lift[no].local_pos.z<lift[no].limit_min.z)
	{
		lift[no].local_pos.z=lift[no].limit_min.z;
		lift[no].delta.z*=-1;
		move=false;
	}

	if(lift[no].local_pos.z>lift[no].limit_max.z)
	{
		lift[no].local_pos.z=lift[no].limit_max.z;
		lift[no].delta.z*=-1;
		move=false;
	}
	local_mat=SetMatrix(lift[no].local_pos,local_rotation,local_scale);
	lift_mat=SetMatrix(lift[no].initial_pos,lift[no].obj->rotation,
					   lift[no].obj->scale);
	world=local_mat*lift_mat;
	lift[no].obj->pos.x=roundf(world._41);
	lift[no].obj->pos.y=roundf(world._42);
	lift[no].obj->pos.z=roundf(world._43);
	lift[no].move=move;
}
