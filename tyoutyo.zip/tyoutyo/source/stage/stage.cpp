#include"stage.h"
#include"../Directx9/Directx9MyLib.h"
#include"../fbx/FbxMeshAmg.h"
#include"../global/global.h"
#include"../game/game.h"
#include"lift.h"
#include"roll.h"
#include"pupa.h"
#define STAGE
FbxMeshAmg g_fbx_list[FBXTYPE_MAX];
struct OBJECT*  g_stage1_base[STAGE1_BASE_MAX]={ NULL };
struct OBJECT*  g_stage2_base[STAGE2_BASE_MAX]={ NULL };
/*
*	@fn �����񂩂���o�����l��Ԃ��܂�
*	@param *current_buffer	�}���t�@�C������R�s�[����������̐擪�|�C���^
*	@param *current_buffer_count	���̃|�C���^�̈ʒu
*	@param return �����񂩂���o�����l
*/
float SetParam(char*current_buffer, int* current_buffer_count)
{
	int count=0;
	char sz[32]={ '\0' };
	while (current_buffer[*current_buffer_count]!=',')
	{
		if(current_buffer[*current_buffer_count]!='}')
		{
			sz[count]=current_buffer[*current_buffer_count];
			count++;
		}
		*current_buffer_count+=1;
	}
	*current_buffer_count+=1;
	float value=(float)atof(sz);
	return value;
}
/*
*	@fn �X�e�[�W�̈ʒu���ǂݍ���
*	@param filename_maya	�ʒu���t�@�C����
*	@param obj	�I�u�W�F�N�g�̐擪�|�C���^�̃|�C���^
*/
bool CreateStage(char* filename_maya ,OBJECT *obj[])
{
	FILE* fp=fopen(filename_maya,"rb");
	if(fp)
	{
		fseek(fp,0,SEEK_END);
		int file_length=ftell(fp);
		fseek(fp,0,SEEK_SET);
		char* buffer=(char*)malloc(file_length+1);
		fread(buffer,1,file_length,fp);
		fclose(fp);
		buffer[file_length]='\0';
		char* stage_current_buffer=buffer;
		int char_count=0;
		int line_count=0;
		while(stage_current_buffer[char_count]!='\0')
		{
			if (stage_current_buffer[char_count]=='{')
			{
				line_count++;
				if(!obj[line_count-1])
				obj[line_count-1]=(OBJECT*)malloc(sizeof(OBJECT));
				ZeroMemory(obj[line_count-1],sizeof(OBJECT));
				obj[line_count-1]->draw_use=true;
				for(int hit=0; hit<GAME_MODE_MAX; hit++)
				{
					obj[line_count-1]->hit_use[hit]=true;
				}
			}
			char_count++;
		}
		char_count=0;
		int i=0;
		while(stage_current_buffer[char_count]!='\0')
		{
			char filename[128]={ '\0' };
			while(stage_current_buffer[char_count]!='\n')
			{
				if(stage_current_buffer[char_count]=='{')
				{
					int name_count=0;
					while(stage_current_buffer[char_count]!='"')
					{
						char_count++;
					}
					char_count++;

					while(stage_current_buffer[char_count]!='"')
					{
						filename[name_count]=stage_current_buffer[char_count];
						char_count++;
						name_count++;
					}
					filename[name_count+1]='\0';
					if(!obj[i]->name)
					obj[i]->name=(char*)malloc(sizeof(filename));
					strcpy(obj[i]->name,filename);
					while(stage_current_buffer[char_count]!=',')
					{
						char_count++;
					}
					if(stage_current_buffer[char_count]!='\0')
					{
						char_count++;
					}
					
					obj[i]->pos.x=SetParam(stage_current_buffer,&char_count);
					obj[i]->pos.y=SetParam(stage_current_buffer,&char_count);
					obj[i]->pos.z=SetParam(stage_current_buffer,&char_count);
					obj[i]->rotation.x=
						D3DXToRadian(SetParam(stage_current_buffer,&char_count));
					obj[i]->rotation.y=
						D3DXToRadian(SetParam(stage_current_buffer,&char_count));
					obj[i]->rotation.z=
						D3DXToRadian(SetParam(stage_current_buffer,&char_count));
					obj[i]->scale.x=SetParam(stage_current_buffer,&char_count);
					obj[i]->scale.y=SetParam(stage_current_buffer,&char_count);
					obj[i]->scale.z=SetParam(stage_current_buffer,&char_count);
					
				}
				if(stage_current_buffer[char_count]!='\0')
				{
					char_count++;
				}
			}
			if(stage_current_buffer[char_count]!='\0')
			{
				i++;
				char_count++;
			}
		}
		if(buffer)
		{
			free(buffer);
		}
	}
	else
	{
		return false;
	}
	return true;
}
/*
*	@fn �e�X�e�[�W�̃x�[�X�Ɏg���I�u�W�F�N�g�̃|�C���^�̐擪�A�h���X��Ԃ��܂�
*/
OBJECT** GetStageBase()
{
	switch(g_game.stage)
	{
	case ONE:
		return g_stage1_base;
		break;
	case TWO:
	case THREE:
		return g_stage2_base;
		break;
	}
	return NULL;
}
/*
*	@fn �e�X�e�[�W�̃x�[�X�̐���Ԃ��܂�
*	@return	�e�X�e�[�W�̃x�[�X�̐�
*/
int GetStageBaseCount()
{
	switch(g_game.stage)
	{
	case ONE:
		return STAGE1_BASE_MAX;
		break;
	case TWO:
	case THREE:
		return STAGE2_BASE_MAX;
		break;
	}
	return NULL;
}
/*
*	@fn �X�e�[�W�̏�����
*/
void InitStage()
{	
	if(g_game.stage==ONE)
	{
		g_fbx_list[FBXTYPE_BACK].position=D3DXVECTOR3(0.0f,0.0f,0.0f);
		g_fbx_list[FBXTYPE_BACK].rotation=D3DXVECTOR3(0.0f,0.0f,0.0f);
		g_fbx_list[FBXTYPE_BACK].scale=D3DXVECTOR3(120.0f,120.0f,120.0f);
		g_fbx_list[FBXTYPE_BACK].Update();
		CreateStage("Assets/stage/kagari1_base.source",g_stage1_base);
	}
	else if(g_game.stage==TWO)
	{
		g_fbx_list[FBXTYPE_BACK_2].position=D3DXVECTOR3(0.0f,0.0f,0.0f);
		g_fbx_list[FBXTYPE_BACK_2].rotation=D3DXVECTOR3(0.0f,0.0f,0.0f);
		g_fbx_list[FBXTYPE_BACK_2].scale=D3DXVECTOR3(120.0f,120.0f,120.0f);
		g_fbx_list[FBXTYPE_BACK_2].Update();
		CreateStage("Assets/stage/kagari2_base.source",g_stage2_base);
	}
	else if(g_game.stage==THREE)
	{
		g_fbx_list[FBXTYPE_BACK_3].position=D3DXVECTOR3(0.0f,0.0f,0.0f);
		g_fbx_list[FBXTYPE_BACK_3].rotation=D3DXVECTOR3(0.0f,0.0f,0.0f);
		g_fbx_list[FBXTYPE_BACK_3].scale=D3DXVECTOR3(20.0f,20.0f,20.0f);
		g_fbx_list[FBXTYPE_BACK_3].Update();
		CreateStage("Assets/stage/lui_base.source",g_stage2_base);
	}
	OBJECT** obj=GetStageBase();
	int base_count=GetStageBaseCount();
	for(int i=0; i<base_count ; i++)
	{
		obj[i]->size.x=BASE_WIDTH_HALF;
		obj[i]->size.y=BASE_HEIGHT_HALF;
		obj[i]->size.z=BASE_DEPTH_HALF;
		if(g_game.stage==ONE)
		{
			if(i==43-1 || i==7-1)
			{
				obj[i]->hit_use[CUBE_UP]=false;
			}
		}
		if(strcmp(obj[i]->name,"goal")==0)
		{
			obj[i]->size.x=GOAL_WIDTH_HALF;
			obj[i]->size.z=GOAL_DEPTH_HALF;
		}
	}
	InitPupa();
	InitRoll();
	InitLift();
}
/*
*	@fn �X�e�[�W�̏���
*/
void ProcessStage()
{
	int lift_count=GetStageLiftCount();
	LIFT* lift=GetStageLift();
	for(int i=0; i<lift_count; i++)
	{
		ProcessLift(i,lift);
	}
	ROLL* roll=GetStageRoll();
	int roll_count=GetStageRollCount();
	for(int i=0; i<roll_count; i++)
	{
		ProcessRoll(i, roll,roll[i].rotation_direction);
	}
}
/*
*	@fn �X�e�[�W�̕`��
*/
void DrawStage()
{

	OBJECT** obj=GetStageBase();
	ROLL* roll=GetStageRoll();
	LIFT* lift=GetStageLift();
	OBJECT** pupa=GetStagePupa();
	int base_count=GetStageBaseCount();
	int roll_count=GetStageRollCount();
	int lift_count=GetStageLiftCount();
	int pupa_count=GetStagePupaCount();
	for(int i=0; i<base_count; i++)
	{
		DrawFbx(obj[i],g_fbx_list,NULL);
	}
	for(int i=0; i<roll_count; i++)
	{
		DrawFbx(roll[i].obj,g_fbx_list,NULL);
	}
	for(int i=0; i<lift_count; i++)
	{
		DrawFbx(lift[i].obj,g_fbx_list,NULL);
	}
	for(int i=0; i<pupa_count; i++)
	{
		DrawFbx(pupa[i],g_fbx_list,NULL);
	}
	if(g_game.stage==ONE)
	{
		g_fbx_list[FBXTYPE_BACK].Render();
	}
	else if(g_game.stage==TWO)
	{
		g_fbx_list[FBXTYPE_BACK_2].Render();
	}
	else if(g_game.stage==THREE)
	{
		g_fbx_list[FBXTYPE_BACK_3].Render();
	}
}
/*
*	@fn �X�e�[�W�̊J��
*/
void DeleteStage()
{
	int loop_max[]=
	{
		STAGE1_ROLL_MAX,
		STAGE2_ROLL_MAX,
		STAGE1_LIFT_MAX,
		STAGE2_LIFT_MAX,
		STAGE1_BASE_MAX,
		STAGE2_BASE_MAX,
		STAGE1_PUPA_MAX,
		STAGE2_PUPA_MAX,
	};
	for(int i=0;i<8;i++)
	{
		for(int j=0;j<loop_max[i];j++)
		{
			if(i==0)
			{
				DeleteObj(g_roll1[j].obj);
			}
			else if(i==1)
			{
				DeleteObj(g_roll2[j].obj);
			}
			else if(i==2)
			{
				DeleteObj(g_stage1_lift[j].obj);
			}
			else if(i==3)
			{
				DeleteObj(g_stage2_lift[j].obj);
			}
			else if(i==4)
			{
				DeleteObj(g_stage1_base[j]);
			}
			else if(i==5)
			{
				DeleteObj(g_stage2_base[j]);
			}
			else if(i==6)
			{
				DeleteObj(g_stage1_pupa[j]);
			}
			else if(i==7)
			{
				DeleteObj(g_stage2_pupa[j]);
			}
		}
	}
}
