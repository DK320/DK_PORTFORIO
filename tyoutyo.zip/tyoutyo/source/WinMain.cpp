/**
*	@file	WinMain.cpp
*	@brief	�G���g���|�C���g
*	@author	D.K
*	@data	2019/10/15
*/
#include "Directx9/Directx9MyLib.h"
#include"game/game.h"
#include"sound/dslib.h"
#include"Framework/Framework.h"
Framework*	g_framework=NULL;//�t���[�����[�N
/*
*	@fn�@�G���g���|�C���g
*	@param hinst	
*	@param h_prev_inst
*	@param str
*	@param cmd_show
*	@return msg.wParam
*/
INT WINAPI WinMain(HINSTANCE hinst,HINSTANCE hprev_lnst,
					LPSTR str,INT cmd_show)
{
	MSG msg={};
	if(FAILED(InitDinput()))
	{
		FreeDx();
		return 0;
	}
	if(FAILED(InitD3d(hinst)))
	{
		FreeDx();
		return 0;
	}
	if(!DSoundInit(g_directx.hwnd,NULL))
	{
		MessageBox(g_directx.hwnd,"DirectSound Init Error",
					"error",MB_OK);
		FreeDx();
		DSoundRelease();
		return 0;
	}
	ZeroMemory(&msg,sizeof(msg));
	g_framework=new Framework();
	HMODULE fbxdll=LoadLibrary("libfbxsdk.dll");
	AppInit();
	InitFont();
	while(msg.message!=WM_QUIT)
	{
		if(PeekMessage(&msg,NULL,0U,0U,PM_NOREMOVE))
		{
			if(!GetMessage(&msg,NULL,0,0)) break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			if(g_framework->Update())
			{
				g_framework->Render();
			}
		}
	}
	//�I������,�I�u�W�F�N�g�̊J�� ���C�u�������
	UnregisterClass(_T("D3D Window Class"),GetModuleHandle(NULL));
	delete	g_framework;
	FontRelease();
	AppRelease();
	FreeDx();
	DSoundRelease();
	FreeLibrary(fbxdll);
	return (int)msg.wParam;
}