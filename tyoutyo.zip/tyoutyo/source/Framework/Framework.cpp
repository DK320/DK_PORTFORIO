/**
*	@file	Framework.cpp
*	@brief	�t���[�����[�N�iAMG�񋟁j
*	@author	H.M
*	@data	2019/11/27
*/
#include"../Directx9/Directx9MyLib.h"
#include "Framework.h"
#include "../game/game.h"
#include <time.h>


//*****************************************************************************************************************************
//
//		�t���[�����[�N
//
//*****************************************************************************************************************************

//------------------------------------------------------
//		�������E���
//------------------------------------------------------
Framework::Framework(int FPSMode)
{
	this->FPSMode=FPSMode;

	/*scene=NULL;*/

	dwGameFrame=0;
	dwFrameTime=clock();
}

Framework::~Framework()
{
	/*if(scene!=NULL) delete scene;*/
}


//*****************************************************************************************************************************
//		�X�V
//*****************************************************************************************************************************
bool Framework::Update()
{
	static 	DWORD	dwSec=0;
	DWORD CurrentTime=clock()*10;

	//	�t���[������
	if(CurrentTime<dwFrameTime+167) return false;

	//	�o�ߎ���
	DWORD	dTime=CurrentTime-dwFrameTime;
	if(dTime>2000) dwFrameTime=CurrentTime;

	//	�X�L�b�v�^�C�v 
	switch(FPSMode){
	case FPS_60:	bRender=TRUE;	break;
	case FPS_30:	if(dwGameFrame & 0x01) bRender=TRUE; else bRender=FALSE;
					break;
	case FPS_FLEX:	if(dTime>167*2) bRender=FALSE; else bRender=TRUE;
					break;
	}

	//	�t���[�����ԍX�V
	if(GetKeyState(VK_LCONTROL)<0) dwFrameTime+=300;
	dwFrameTime+=167;

	//	�b�ԃt���[�����ۑ�
	if(dwSec<CurrentTime){
		dwFPS      =dwCurFrame;
		dwRenderFPS=dwRCurFrame;
		dwCurFrame =dwRCurFrame=0;
		dwSec+=10000;
	}
	dwCurFrame ++;	//	�t���[�����X�V
	dwGameFrame++;	//	�Q�[���t���[�����X�V

	FrameInput();
	FrameProcess();
	////	�X�V����
	//if(scene!=NULL) scene->Update();

	return true;
}

//*****************************************************************************************************************************
//		�`��
//*****************************************************************************************************************************
void Framework::Render()
{
	if(!bRender) return;
	D3DLIGHT9 light;
	ZeroMemory(&light,sizeof(D3DLIGHT9));
	light.Type=D3DLIGHT_DIRECTIONAL;
	/*light.Type=D3DLIGHT_POINT;
	light.Range=10000.0f;
	light.Position=D3DXVECTOR3(-500.0f ,500.0f ,-250.0f);*/
	light.Diffuse.r=1.0f;
	light.Diffuse.g=0.3f;
	light.Diffuse.b=0.3f;
	light.Direction=D3DXVECTOR3(-1,-1,1);
	g_directx.device->SetLight(0,&light);
	g_directx.device->LightEnable(0,true);
	g_directx.device->SetRenderState(D3DRS_AMBIENT,0xC8C8C8);
	g_directx.device->SetRenderState(D3DRS_LIGHTING,true);
	g_directx.device->SetRenderState(D3DRS_FOGENABLE,false);
	g_directx.device->SetRenderState(D3DRS_ZENABLE,TRUE);
	g_directx.device->Clear(0,NULL,D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,0xFF606060,1.0f,0);

	if(SUCCEEDED(g_directx.device->BeginScene()))
	{
		FrameRender();
		g_directx.device->EndScene();
	}
	g_directx.device->Present(NULL,NULL,NULL,NULL);
	//	�t���[���\��
#ifdef _DEBUG
	char	str[64];
	wsprintf(str, "FPS %03d/%03d\n", dwFPS, dwRenderFPS);
//	IEX_DrawText(str, 10,10,200,20, 0xFFFFFF00);
#endif
	dwRCurFrame ++;	//	�`��t���[�����X�V
}
