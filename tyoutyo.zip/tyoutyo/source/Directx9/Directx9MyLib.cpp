/**
*	@file	Directx9MyLib.cpp
*	@brief	Directx9���C�u����
*	@author	D.K
*	@data	2019/11/01
*/
#include"Directx9MyLib.h"
#include"../camera/camera.h"
#include"../global/global.h"

struct DIRECTX g_directx={NULL};
struct JOYCON g_controller={0};
struct MOUSESTATE g_mouse_state={0};
struct TEXTURE_DATA* g_textuer_top=NULL;
struct TEXTURE_POLY g_tex_poly={ NULL };
int g_texture_num=0;
/*
*	@fn �E�C���h�E�v���V�[�W��
*	@param hwnd
*	@param imsg
*	@param wparam
*	@param lparam
*	@return DefWindowProc(hwnd, imsg, wparam, lparam);
*/
LRESULT CALLBACK WndProc(HWND hwnd, UINT imsg, WPARAM wparam, LPARAM lparam)
{
	switch (imsg)
	{
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	case WM_KEYDOWN:
		switch ((CHAR)wparam)
		{
		case VK_ESCAPE:
			PostQuitMessage(0);
			return 0;
		}
		break;
	}
	return DefWindowProc(hwnd, imsg, wparam, lparam);
}
/*
*	@fn DirectX�������֐�
*	@param �C���X�^���X�n���h��
*	@return S_OK ����I��
*	@return E_FAIL �G���[
*/
HRESULT InitD3d(HINSTANCE hinstance)
{
	static char sz_app_name[]="�Q�[���^�C�g��";
	WNDCLASSEX wndclass;
	wndclass.cbSize=sizeof(WNDCLASSEX);
	wndclass.style=CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc=WndProc;
	wndclass.cbClsExtra=0;
	wndclass.cbWndExtra=0;
	wndclass.hInstance=hinstance;
	wndclass.hIcon=LoadIcon(NULL, IDI_APPLICATION);
	wndclass.hCursor=LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH);
	wndclass.lpszMenuName=NULL;
	wndclass.lpszClassName=sz_app_name;
	wndclass.hIconSm=LoadIcon(NULL, IDI_ASTERISK);
	RegisterClassEx(&wndclass);
	//�E�B���h�E�T�C�Y�̑I�����b�Z�[�W
#ifndef RELEASE
	int answer;
	answer=MessageBox(g_directx.hwnd, "�t���X�N���[���ŋN�����܂����H",
					  "�E�B���h�E�T�C�Y", MB_YESNO);
	//�u�͂��v�������ꂽ�ꍇ�t���X�N���[���ŕ\��
	if (answer==IDYES)
	{
		g_directx.hwnd=CreateWindow(
		sz_app_name,
		sz_app_name,
		WS_POPUP& ~WS_THICKFRAME,
		0,
		0,
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		NULL,
		NULL,
		hinstance,
		NULL);
	ShowWindow(g_directx.hwnd, SHOW_FULLSCREEN);
	}
	//�u�������v�������ꂽ�ꍇ�E�B���h�E�T�C�Y�ŕ\��
	if (answer==IDNO)
	{
		g_directx.hwnd=CreateWindow(
		sz_app_name,
		sz_app_name,
		WS_OVERLAPPEDWINDOW & ~WS_THICKFRAME & ~WS_MINIMIZEBOX& ~WS_MAXIMIZEBOX,
		CW_USEDEFAULT,
		CW_USEDEFAULT,
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		NULL,
		NULL,
		hinstance,
		NULL);
	ShowWindow(g_directx.hwnd, SW_SHOW);
	}
#else
	g_directx.hwnd=CreateWindow(
		sz_app_name ,
		sz_app_name ,
		WS_OVERLAPPEDWINDOW & ~WS_THICKFRAME & ~WS_MINIMIZEBOX& ~WS_MAXIMIZEBOX ,
		CW_USEDEFAULT ,
		CW_USEDEFAULT ,
		WINDOW_WIDTH ,
		WINDOW_HEIGHT ,
		NULL ,
		NULL ,
		hinstance ,
		NULL);
	ShowWindow(g_directx.hwnd,SW_SHOW);
#endif
	UpdateWindow(g_directx.hwnd);
	// �uDirect3D�v�I�u�W�F�N�g�̍쐬
	if (NULL==(g_directx.d3d=Direct3DCreate9(D3D_SDK_VERSION)))
	{
		MessageBox(0, "Direct3D�̍쐬�Ɏ��s���܂���", "", MB_OK);
		return E_FAIL;
	}
	// �uDIRECT3D�f�o�C�X�v�I�u�W�F�N�g�̍쐬
	D3DPRESENT_PARAMETERS d3dpp;
	ZeroMemory(&d3dpp, sizeof(d3dpp));
	D3DDISPLAYMODE disp_mode;
	g_directx.d3d->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &disp_mode);
#ifndef RELEASE
	if (answer==IDYES)
	{
		d3dpp.Windowed=false;
		d3dpp.SwapEffect=D3DSWAPEFFECT_DISCARD;
		d3dpp.BackBufferFormat=disp_mode.Format;
		d3dpp.FullScreen_RefreshRateInHz=D3DPRESENT_RATE_DEFAULT;
		ShowCursor(false);
	}
	else
	{
		d3dpp.Windowed=true;
		d3dpp.SwapEffect=D3DSWAPEFFECT_DISCARD;
		d3dpp.BackBufferFormat=D3DFMT_UNKNOWN;
	}
#else
	d3dpp.Windowed=false;
	d3dpp.SwapEffect=D3DSWAPEFFECT_DISCARD;
	d3dpp.BackBufferFormat=disp_mode.Format;
	d3dpp.FullScreen_RefreshRateInHz=D3DPRESENT_RATE_DEFAULT;
	ShowCursor(false);
#endif
	d3dpp.BackBufferWidth=WINDOW_WIDTH;
	d3dpp.BackBufferHeight=WINDOW_HEIGHT;
	d3dpp.BackBufferCount=1;
	d3dpp.hDeviceWindow=g_directx.hwnd;
	d3dpp.EnableAutoDepthStencil=TRUE;
	d3dpp.AutoDepthStencilFormat=D3DFMT_D16;
	d3dpp.PresentationInterval=D3DPRESENT_INTERVAL_IMMEDIATE;
	d3dpp.MultiSampleType=D3DMULTISAMPLE_NONE;
	d3dpp.MultiSampleQuality=0;
	d3dpp.EnableAutoDepthStencil=true;

	if (FAILED(g_directx.d3d->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, g_directx.hwnd,
		D3DCREATE_HARDWARE_VERTEXPROCESSING,
		&d3dpp, &g_directx.device)))
	{
		if (FAILED(g_directx.d3d->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, g_directx.hwnd,
			D3DCREATE_SOFTWARE_VERTEXPROCESSING,
			&d3dpp, &g_directx.device)))
		{
			MessageBox(0,"HAL���[�h��DIRECT3D�f�o�C�X���쐬�ł��܂���\nREF���[�h�ōĎ��s���܂�"
					   , NULL, MB_OK);
			if (FAILED(g_directx.d3d->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_REF,
				g_directx.hwnd,D3DCREATE_HARDWARE_VERTEXPROCESSING,
				&d3dpp, &g_directx.device)))
			{
				if (FAILED(g_directx.d3d->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_REF,
					g_directx.hwnd,D3DCREATE_SOFTWARE_VERTEXPROCESSING,
					&d3dpp, &g_directx.device)))
				{
					MessageBox(0, "DIRECT3D�f�o�C�X�̍쐬�Ɏ��s���܂���",
							   NULL,MB_OK);
					return E_FAIL;
				}
			}
		}
	}
	return S_OK;
}
/*
*	@fn DirectInput�������֐�
*	@return S_OK ����I��
*	@return E_FAIL �G���[
*/
HRESULT InitDinput()
{
	// �uDirectInput�v�I�u�W�F�N�g�̍쐬
	if (FAILED(
		DirectInput8Create(GetModuleHandle(NULL),
		DIRECTINPUT_VERSION, IID_IDirectInput8,
		(void**) &g_directx.dinput,
		NULL)))
	{
		return E_FAIL;
	}
#ifdef KEYBORD
	//�uDirectInput�f�o�C�X�v�I�u�W�F�N�g�̍쐬
	if (FAILED(g_directx.dinput->CreateDevice(GUID_SysKeyboard,
		&g_input_state[INPUT_STATE_KEY]Device, NULL)))
	{
		return E_FAIL;
	}

	if (!g_input_state[INPUT_STATE_KEY]Device)
	{

		return E_FAIL;
	}

	// �f�o�C�X���L�[�{�[�h�ɐݒ�
	if (FAILED(g_input_state[INPUT_STATE_KEY]Device->SetDataFormat(&c_dfDIKeyboard)))
	{
		return E_FAIL;
	}

	// �������x���̐ݒ�
	if (FAILED(g_input_state[INPUT_STATE_KEY]Device->SetCooperativeLevel(
		g_directx.hwnd, DISCL_NONEXCLUSIVE | DISCL_BACKGROUND)))
	{
		return E_FAIL;
	}
	
	// ���͐���J�n
	if(FAILED(g_input_state[INPUT_STATE_KEY]Device->Acquire()))
	{
		return E_FAIL;
	}
#endif
#ifdef CONTROLLER
	//���p�\�ȃQ�[���R���g���[���[�̗񋓊֐�
	if (FAILED(g_directx.dinput->EnumDevices(DI8DEVCLASS_GAMECTRL, 
		EnumJoysticksCallback,NULL, DIEDFL_ATTACHEDONLY)))
	{
		return E_FAIL;
	}
	if (!g_directx.dinput_device[INPUTDEVICE_TYPE_JOY])
	{
		return E_FAIL;
	}
	// �f�o�C�X���W���C�X�e�B�b�N�ɐݒ�
	if (FAILED(g_directx.dinput_device[INPUTDEVICE_TYPE_JOY]->SetDataFormat(&c_dfDIJoystick)))
	{
		return E_FAIL;
	}
	// �������x���̐ݒ�
	if (FAILED(g_directx.dinput_device[INPUTDEVICE_TYPE_JOY]->SetCooperativeLevel(
		g_directx.hwnd, DISCL_NONEXCLUSIVE | DISCL_BACKGROUND)))
	{
		return E_FAIL;
	}
	//�A�v���P�[�V�����Ŏg�p����R���g���[���[�̃v���p�e�B��񋓂��Đݒ肷��
	if (FAILED(g_directx.dinput_device[INPUTDEVICE_TYPE_JOY]->EnumObjects(EnumObjectsCallback,
		NULL, DIDFT_ALL)))
	{
		return E_FAIL;
	}
	// �f�o�C�X���u�擾�v����
	g_directx.dinput_device[INPUTDEVICE_TYPE_JOY]->Acquire();
#endif
	return S_OK;
}
/*
*	@fn �R���g���[���[����֐�
*	@param 	�f�o�C�X
*	@return S_OK ����I��
*	@return E_FAIL �G���[
*/
int CALLBACK EnumObjectsCallback(const DIDEVICEOBJECTINSTANCE* pdidoi,
								 void* pContext)
{
	if (pdidoi->dwType & DIDFT_AXIS)
	{
		DIPROPRANGE diprg;
		diprg.diph.dwSize=sizeof(DIPROPRANGE);
		diprg.diph.dwHeaderSize=sizeof(DIPROPHEADER);
		diprg.diph.dwHow=DIPH_BYID;
		diprg.diph.dwObj=pdidoi->dwType;
		diprg.lMin=-MOVE_SPEED;
		diprg.lMax=MOVE_SPEED;

		if (FAILED(g_directx.dinput_device[INPUTDEVICE_TYPE_JOY]->SetProperty(DIPROP_RANGE, &diprg.diph)))
		{
			return DIENUM_STOP;
		}
	}
	return DIENUM_CONTINUE;
}
/*
*�@@fn ���p�\�R���g���[���[�̗񋓐���֐�
*	@param 	�f�o�C�X
*	@return S_OK ����I��
*	@return E_FAIL �G���[
*/
int CALLBACK EnumJoysticksCallback(const DIDEVICEINSTANCE* pdidInstance,
								   void* pContext)
{
	//�����񋓂����ꍇ�A���[�U�[�ɑI���E�m�F������
#ifndef RELEASE
	TCHAR szConfirm[MAX_PATH+1];
	sprintf(szConfirm, "���̕����f�o�C�X�Ńf�o�C�X�I�u�W�F�N�g���쐬���܂����H\n%s\n%s",
		pdidInstance->tszProductName, pdidInstance->tszInstanceName);
	if (MessageBox(0, szConfirm, "�m�F", MB_YESNO)==IDNO)
	{
		return DIENUM_CONTINUE;
	}
#endif
	// �uDirectInput�f�o�C�X�v�I�u�W�F�N�g�̍쐬
	if (FAILED(g_directx.dinput->CreateDevice(pdidInstance->guidInstance,
		&g_directx.dinput_device[INPUTDEVICE_TYPE_JOY], NULL)))
	{
		return DIENUM_CONTINUE;
	}
	return DIENUM_STOP;
}
/*
*	@fn ����֐�
*	@return S_OK ����I��
*	@return E_FAIL �G���[
*/
void FreeDx()
{
	SAFE_RELEASE(g_directx.device);
	SAFE_RELEASE(g_directx.d3d);
	SAFE_RELEASE(g_directx.dinput);
#ifdef CONTROLLER
	if (g_directx.dinput_device[INPUTDEVICE_TYPE_JOY])
	{
		g_directx.dinput_device[INPUTDEVICE_TYPE_JOY]->Unacquire();
	}
	SAFE_RELEASE(g_directx.dinput_device[INPUTDEVICE_TYPE_JOY]);
#endif //CONTROLLER

#ifdef KEYBORD
	if (g_input_state[INPUT_STATE_KEY]Device)
	{
		g_input_state[INPUT_STATE_KEY]Device->Unacquire();
	}
	SAFE_RELEASE(g_input_state[INPUT_STATE_KEY]Device);
#endif // KEYBORD
}
/*
*	@fn �R���g���[���[���͂̎擾�֐�
*	@param	0
*	@return state
*/
int JoyInput(int n_pad_state)
{
	DIJOYSTATE js ;
	ZeroMemory(&js,sizeof(js));
	HRESULT hr=g_directx.dinput_device[INPUTDEVICE_TYPE_JOY]->Acquire();
	if ((hr==DI_OK) || (hr==S_FALSE))
	{
		g_directx.dinput_device[INPUTDEVICE_TYPE_JOY]->GetDeviceState(sizeof(DIJOYSTATE), &js);
		//�X�e�B�b�N�l�i�[
		g_controller.lslx=js.lX ;
		g_controller.lsly=js.lY*-1;
		g_controller.rslx=js.lZ ;
		g_controller.rsly=js.lRz* -1;
		//�������l���ɂ�����0�ɂ���
		if (js.lX<JOY_THRESHOLD&&js.lX>-JOY_THRESHOLD &&
			js.lY<JOY_THRESHOLD &&js.lY>-JOY_THRESHOLD)
		{
			g_controller.lslx=0;
			g_controller.lsly=0;
		}
		if (js.lZ<JOY_THRESHOLD&&js.lZ>-JOY_THRESHOLD &&
			js.lRz<JOY_THRESHOLD && js.lRz>-JOY_THRESHOLD)
		{
			g_controller.rslx=0;
			g_controller.rsly=0;
		}
		if (js.rgbButtons[0] & 0x80) n_pad_state |= PAD_X;
		if (js.rgbButtons[1] & 0x80) n_pad_state |= PAD_A;
		if (js.rgbButtons[2] & 0x80) n_pad_state |= PAD_B;
		if (js.rgbButtons[3] & 0x80) n_pad_state |= PAD_Y;
		if (js.rgbButtons[4] & 0x80) n_pad_state |= PAD_LB;
		if (js.rgbButtons[5] & 0x80) n_pad_state |= PAD_RB;
		if (js.rgbButtons[6] & 0x80) n_pad_state |= PAD_LT;
		if (js.rgbButtons[7] & 0x80) n_pad_state |= PAD_RT;
		if (js.rgbButtons[8] & 0x80) n_pad_state |= PAD_BACK;
		if (js.rgbButtons[9] & 0x80) n_pad_state |= PAD_START;
		if (js.rgbButtons[10] & 0x80)n_pad_state |= PAD_LASB;
		if (js.rgbButtons[11] & 0x80)n_pad_state |= PAD_RASB;
		if (js.rgdwPOV[0]==0)     n_pad_state |= PAD_UP;
		if (js.rgdwPOV[0]==4500)  n_pad_state |= PAD_UP_RIGHT;
		if (js.rgdwPOV[0]==9000)  n_pad_state |= PAD_RIGHT;
		if (js.rgdwPOV[0]==13500) n_pad_state |= PAD_RIGHT_DOWN;
		if (js.rgdwPOV[0]==18000) n_pad_state |= PAD_DOWN;
		if (js.rgdwPOV[0]==22500) n_pad_state |= PAD_DOWN_LEFT;
		if (js.rgdwPOV[0]==27000) n_pad_state |= PAD_LEFT;
		if (js.rgdwPOV[0]== 31500) n_pad_state |= PAD_LEFT_UP;
	}
	return n_pad_state;
}
/*
*	@fn �L�[�{�[�h���͊֐�
*	@param 	0
*	@return state
*/
int KeyInput(int n_key_state)
{
	HRESULT hr=g_directx.dinput_device[INPUTDEVICE_TYPE_KEY]->Acquire();
	if ((hr==DI_OK) || (hr==S_FALSE))
	{
		BYTE diks[256];
		g_directx.dinput_device[INPUTDEVICE_TYPE_KEY]->GetDeviceState(sizeof(diks), &diks);
		if (diks[DIK_LEFT] & 0x80)   n_key_state |= KEY_LEFT;
		if (diks[DIK_RIGHT] & 0x80)  n_key_state |= KEY_RIGHT;
		if (diks[DIK_UP] & 0x80)     n_key_state |= KEY_UP;
		if (diks[DIK_DOWN] & 0x80)   n_key_state |= KEY_DOWN;
		if(diks[DIK_W] & 0x80)      n_key_state |= KEY_W;
		if(diks[DIK_A] & 0x80)      n_key_state |= KEY_A;
		if(diks[DIK_S] & 0x80)      n_key_state |= KEY_S;
		if(diks[DIK_D] & 0x80)      n_key_state |= KEY_D;
	}
	return n_key_state;
}
/*
*	@fn �}�E�X���͊֐�
*	@param 	0
*	@return state
*/
int MouseInput(int n_mouse_state)
{
	POINT pt;
	GetCursorPos(&pt);
	g_mouse_state.x=pt.x;
	g_mouse_state.y=pt.y;
	if(GetKeyState(VK_LBUTTON) & 0x80)n_mouse_state |= MOUSE_LEFT;
	if(GetKeyState(VK_RBUTTON) & 0x80)n_mouse_state |= MOUSE_RIGHT;
	if(GetKeyState(VK_MBUTTON) & 0x80)n_mouse_state |= MOUSE_CENTER;
	return n_mouse_state;
}
/*
*	@fn 2D�t�H���g������
*/
void InitFont()
{
	HFONT hF;
	D3DXFONT_DESC lf;
	//�t�H���g�ݒ�
	hF= (HFONT)GetStockObject(SYSTEM_FONT);
	GetObject(hF,sizeof(LOGFONT),(LPSTR)&lf);
	lf.Height=22;
	lf.Width=0;
	lf.Italic=0;
	lf.CharSet=SHIFTJIS_CHARSET;
	strcpy_s(lf.FaceName,"�l�r �S�V�b�N");
	D3DXCreateFontIndirect(g_directx.device,&lf,&g_directx.font[FONTSIZE_NORMAL]);
	lf.Height=12;
	D3DXCreateFontIndirect(g_directx.device, &lf,&g_directx.font[FONTSIZE_M]);
}
/*
*	@fn�t�H���g�����[�X
*/
void FontRelease()
{
	SAFE_RELEASE(g_directx.font[FONTSIZE_NORMAL]);
	SAFE_RELEASE(g_directx.font[FONTSIZE_M]);
}
/*
*	@fn 2D�t�H���g�`��
*/
void FontDrawString(LPSTR str,int x,int y,int width,
					int height,DWORD color,bool b_mini)
{
	RECT rect;
	rect.left=x;
	rect.top=y;
	rect.right=x+width;
	rect.bottom=y+height;
	g_directx.device->SetRenderState(D3DRS_FOGENABLE,FALSE);
	if(!b_mini)
	{
		g_directx.font[FONTSIZE_NORMAL]->DrawText(NULL,str,-1,&rect,DT_LEFT | DT_WORDBREAK,color);
	}
	else
	{
		g_directx.font[FONTSIZE_M]->DrawText(NULL,str,-1,&rect,DT_LEFT | DT_WORDBREAK,color);
	}
}
/*
*	@fn 2D�摜�̃��[�h
*	@param filename �ǂݍ��ރt�@�C���̖��O
*	@return �e�N�X�`���ԍ�
*/
int LoadTexture2D(const char* filename)
{
	struct TEXTURE_DATA* top;
	struct TEXTURE_DATA* current;
	if(g_textuer_top==NULL)
	{
		g_textuer_top=(TEXTURE_DATA*)malloc(sizeof(TEXTURE_DATA));
		g_textuer_top->next=NULL;
		g_texture_num=0;
		current=g_textuer_top;
	}
	else
	{
		top=g_textuer_top;
		while(top->next!=NULL)
		{
			top=top->next;
		}
		current=(TEXTURE_DATA*)malloc(sizeof(TEXTURE_DATA));
		top->next=current;
		current->next=NULL;
		g_texture_num++;
	}
	if(FAILED(D3DXCreateTextureFromFile(
		g_directx.device ,
		filename ,
		&current->texture)))
	{
		return -1;
	}
	else
	{
		D3DXIMAGE_INFO info;
		HRESULT hre=D3DXGetImageInfoFromFile((LPCSTR)filename,&info);
		if(hre==D3D_OK)
		{
			current->width=(float)info.Width;
			current->height=(float)info.Height;
		}
	}
	return g_texture_num;
}
/*
* @fn �摜���u���b�N������ݒ�
* @param texture�ԍ�
* @param �u���b�N���
*/
void SetTextureBlock(int texture_num,BLOCKTEXTURE_INFO block_info)
{
	int no=0;
	struct TEXTURE_DATA* top;
	top=g_textuer_top;
	while(no!=texture_num)
	{
		top=top->next;
		no++;
	}
	top->block=block_info;
}
/*
*	@fn �`��
*	@param x���W
*	@param y���W
*	@param �傫��
*	@param �e�N�X�`���n���h��
*	@param �u���b�N�`�悷�邩�H
*	@param ���Ԗڂ̃u���b�N��
*/
void DrawTexture2D(float x,float y,float magnification,
				   int texture_num,bool block,int block_no)
{
	int no=0;
	struct TEXTURE_DATA* top;
	top=g_textuer_top;	
	int vertex_count=4;
	while(no!=texture_num)
	{
		top=top->next;
		no++;
	}
	LPDIRECT3DVERTEXBUFFER9  vertex_buffer;
	g_directx.device->CreateVertexBuffer(vertex_count*sizeof(CUSTOM_VERTEX_2D),
								   D3DUSAGE_WRITEONLY ,
								   FVF_2D,D3DPOOL_MANAGED ,
								   &vertex_buffer,0);
	CUSTOM_VERTEX_2D bg[4];
	if(block)
	{
		int height_no=block_no % top->block.height_num;
		if(block_no==top->block.height_num)
		height_no=block_no;
		int width_no=block_no % top->block.width_num;
		if(block_no==top->block.width_num)
		width_no=block_no;
		float width=1.0f/top->block.width_num;
		float height=1.0f/top->block.height_num;
		float tu[2]={ (width_no-1)* width,width_no*width};
		float tv[2]={ (height_no-1)* height,height_no*height };
		bg[0].pos={ x,(y+(top->height/top->block.height_num)*magnification) ,0.0f };
		bg[0].rhw=1.0f;
		bg[0].uv={ tu[0],tv[1] };
		bg[1].pos={ x,y,0.0f };
		bg[1].rhw=1.0f;
		bg[1].uv={ tu[0],tv[0] };
		bg[2].pos={ (x+(top->width/top->block.width_num)*magnification),
			(y+(top->height/top->block.height_num) *magnification), 0.0f };
		bg[2].rhw=1.0f;
		bg[2].uv={ tu[1],tv[1] };
		bg[3].pos={ (x+(top->width/top->block.width_num)*magnification), y,0.0f };
		bg[3].rhw=1.0f;
		bg[3].uv={ tu[1],tv[0] };
	}
	else
	{
		bg[0].pos={ x,y+top->height*magnification,0.0f };
		bg[0].rhw=1.0f;
		bg[0].uv={ 0.0f,1.0f };
		bg[1].pos={ x,y,0.0f };
		bg[1].rhw=1.0f;
		bg[1].uv={ 0.0f,0.0f };
		bg[2].pos={ x+top->width*magnification,y+top->height*magnification,0.0f };
		bg[2].rhw=1.0f;
		bg[2].uv={ 1.0f,1.0f };
		bg[3].pos={ x+top->width*magnification,y,0.0f };
		bg[3].rhw=1.0f;
		bg[3].uv={ 1.0f,0.0f };
	}
	void *pBuf=NULL;
	if(SUCCEEDED(vertex_buffer->Lock(0,
	   vertex_count*sizeof(CUSTOM_VERTEX_2D),
	   (void**)&pBuf,0)))
	{
		memcpy(pBuf,bg,vertex_count*sizeof(CUSTOM_VERTEX_2D));
		vertex_buffer->Unlock();
	}
	LPDIRECT3DINDEXBUFFER9 index_buffer =NULL;
	g_directx.device->CreateIndexBuffer(sizeof(WORD)*6,
								  D3DUSAGE_WRITEONLY ,
								  D3DFMT_INDEX16,D3DPOOL_MANAGED,
								  &index_buffer ,0);
	WORD index[3*2];

	index[0]=1;
	index[1]=3;
	index[2]=0;
	index[3]=0;
	index[4]=3;
	index[5]=2;
	void *index_buf=NULL;
	if(SUCCEEDED(index_buffer->Lock(0,sizeof(WORD)*6,(void**)&index_buf,0)))
	{
		memcpy(index_buf,index, sizeof(WORD)*6);
		index_buffer->Unlock();
	}
	g_directx.device->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
	g_directx.device->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
	g_directx.device->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
	g_directx.device->SetFVF(FVF_2D);
	g_directx.device->SetStreamSource(0,vertex_buffer,0,sizeof(CUSTOM_VERTEX_2D));
	g_directx.device->SetIndices(index_buffer);
	g_directx.device->SetTexture(0,top->texture);
	g_directx.device->DrawIndexedPrimitive(D3DPT_TRIANGLELIST,0,0,4,0,2);
	vertex_buffer->Release();
	vertex_buffer=NULL;
	index_buffer->Release();
	index_buffer=NULL;
}
/*
*	@fn 2D�|���S���`��
*/
void InitTexturePoly()
{
	g_directx.device->CreateVertexBuffer(4*sizeof(CUSTOM_VERTEX_3D),D3DUSAGE_WRITEONLY ,
								   FVF_2D3,D3DPOOL_MANAGED ,
								   &g_tex_poly.vertex,0);
	CUSTOM_VERTEX_3D bg[4];
	bg[0].pos={ -0.5f,0.0f,0.5f };
	bg[0].uv={ 0.0f,0.0f };
	bg[1].pos={ 0.5f, 0.0f, 0.5f };
	bg[1].uv={ 1.0f,0.0f };
	bg[2].pos={ -0.5f,0.0f,-0.5f };
	bg[2].uv={ 0.0f,1.0f };
	bg[3].pos={ 0.5f,0.0f,-0.5f };
	bg[3].uv={ 1.0f,1.0f };
	void *pBuf=NULL;
	if(SUCCEEDED(g_tex_poly.vertex->Lock(0,
	   4*sizeof(CUSTOM_VERTEX_3D),
	   (void**)&pBuf,0)))
	{
		memcpy(pBuf,bg,4*sizeof(CUSTOM_VERTEX_3D));
		g_tex_poly.vertex->Unlock();
	}
	g_directx.device->CreateIndexBuffer(sizeof(WORD)*6,
								  D3DUSAGE_WRITEONLY ,
								  D3DFMT_INDEX16,
								  D3DPOOL_MANAGED,
								  &g_tex_poly.index,0);
	WORD index[3*2];
	index[0]=0;
	index[1]=1;
	index[2]=2;
	index[3]=2;
	index[4]=1;
	index[5]=3;
	void *index_buf=NULL;
	if(SUCCEEDED(g_tex_poly.index->Lock(0,sizeof(WORD)*6,(void**)&index_buf,0)))
	{
		memcpy(index_buf,index,sizeof(WORD)*6);
		g_tex_poly.index->Unlock();
	}
}
/*
*	@fn 3D��Ԃ�2D�`��
*	@param �e�N�X�`���ԍ�
*	@param �s��
*/
void DrawTexture2D3(int texture_num,D3DXMATRIX world_mat)
{
	int no=0;
	struct TEXTURE_DATA* top;
	top=g_textuer_top;
	while(no!=texture_num)
	{
		top=top->next;
		no++;
	}
	g_directx.device->SetTransform(D3DTS_WORLD,&world_mat);
	g_directx.device->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
	g_directx.device->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
	g_directx.device->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
	g_directx.device->SetIndices(g_tex_poly.index);
	g_directx.device->SetFVF(FVF_2D3);
	g_directx.device->SetStreamSource(0,g_tex_poly.vertex,0,sizeof(CUSTOM_VERTEX_3D));
	g_directx.device->SetTexture(0,top->texture);
	g_directx.device->DrawIndexedPrimitive(D3DPT_TRIANGLELIST,0,0,4,0,2);
}
/*
*	@fn �e�N�X�`���J��
*/
bool ReleaseTexture2D()
{
	struct TEXTURE_DATA* top;
	struct TEXTURE_DATA* temp;
	top=g_textuer_top;
	g_tex_poly.index->Release();
	g_tex_poly.index=NULL;
	g_tex_poly.vertex->Release();
	g_tex_poly.vertex=NULL;
	while(top!=NULL)
	{
		temp=top->next;
		top->texture->Release();
		free(top);
		top=temp;
	}
	return true;
}
/*
*	@fn ���̕`��
*	@param start_pos �n�܂�̈ʒu
*	@param end_pos �I���̈ʒu
*/
void DrawLine(D3DXVECTOR3 start_pos,D3DXVECTOR3 end_pos)
{
	D3DXMATRIX mWorld;
	D3DXMatrixIdentity(&mWorld);
	D3DXVECTOR3 v_point[2];
	v_point[0]=start_pos;
	v_point[1]=end_pos;
	g_directx.device->SetTransform(D3DTS_WORLD,&mWorld);
	g_directx.device->SetFVF(D3DFVF_XYZ);
	g_directx.device->DrawPrimitiveUP(D3DPT_LINELIST,1,v_point,sizeof(D3DXVECTOR3));
}
/*
*	@fn�@�F�t���̃|���S���`��
*	@param DrawColorPolygon(alpha,red,green,blue);
*/
void DrawColorPolygon(int a,int r,int g,int b)
{
	COSTOM_VERTEX_3D3 vPoint[] =
	{
		D3DXVECTOR3(-1.0f,1.0f,0.0f),D3DCOLOR_ARGB(a,r,g,b),
		D3DXVECTOR3(1.0f,1.0f,0.0f),D3DCOLOR_ARGB(a,r,g,b),
		D3DXVECTOR3 (-1.0f,-1.0f,0.0f),D3DCOLOR_ARGB(a,r,g,b),
		D3DXVECTOR3(1.0f,-1.0f,0.0f),D3DCOLOR_ARGB(a,r,g,b),
	};
	g_directx.device->SetTextureStageState(0,D3DTSS_ALPHAARG1,
									 D3DTA_DIFFUSE);
	D3DXMATRIX mat;
	D3DXMatrixIdentity(&mat);
	g_directx.device->SetTransform(D3DTS_WORLD,&mat);
	g_directx.device->SetTransform(D3DTS_VIEW,&mat);
	g_directx.device->SetTransform(D3DTS_PROJECTION,&mat);
	g_directx.device->SetRenderState(D3DRS_LIGHTING,false);
	g_directx.device->SetFVF(D3DFVF_XYZ | D3DFVF_DIFFUSE);
	g_directx.device->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP,2,
								vPoint,sizeof(COSTOM_VERTEX_3D3));
	g_directx.device->SetTextureStageState(0,D3DTSS_ALPHAARG1,
									 D3DTA_TEXTURE);
}