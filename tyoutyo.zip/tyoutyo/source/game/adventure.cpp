/**
*	@file	adventure.cpp
*	@brief	�A�h�x���`���[�p�[�g�̏���
*	@author	D.K
*	@data	2020/02/12
*/
#include"adventure.h"
#include"../global/global.h"
#include"../stage/player.h"
#include"end.h"
extern struct ADVENTURE g_adventure=
{
	{
#include"../../txt/string_data.txt"
	},
	{
		"���c",
		"�J�K��",
		"���C",
		"�J�K����",
		"���C�o",
		"���߂̒j",
		"TV�̐�",
	},
	{
#include"../../txt/string_facetex_type.txt"
	},
	{
#include"../../txt/string_faceno.txt"
	},
	{
#include"../../txt/string_name_no.txt"
	},
	{
#include"../../txt/string_setype.txt"
	},
	{
	0
	},
	{
	-1
	},
};
/*
*	@fn �A�h�x���`���[�p�[�g�̏�����
*	@param �e�L�X�g�̎n�߂�ʒu
*	@param �e�L�X�g�̏I���ʒu
*/
void InitAdventure(int first,int last)
{
	g_game.state=ADVENTURE;
	g_game.start_time_ms=(float)GetTickCount();
	g_adventure.stringline=first;
	g_adventure.adventure_end=last;
	int setype=g_adventure.adventure_voice_type[g_adventure.stringline];
	if( setype!=-1)
	{
		if(DSoundIsStop(g_se[setype]))
		{
			DSoundPlay(g_se[setype],false);
		}
	}

	if(g_game.endtype!=0)
	{
		Setargb(255,255,255,255);
	}
};
/*
*	@fn�@�A�h�x���`���[�p�[�g�̏���
*/
void ProcessAdventure()
{	
	float current_time_ms=(float)GetTickCount();
	float elapsed_time_s=((current_time_ms-g_game.start_time_ms)/1000);

	if(g_game.endtype!=0 && g_color_polygon.a!=0)
	{
		g_color_polygon.a-=1;
	}
	else
	{
		g_color_polygon.a=0;

		if((elapsed_time_s > ADVENTURE_LIMIT_TIME) && (g_input_state[INPUT_STATE_PADTRG]&PAD_B))
		{
			g_game.start_time_ms=(float)GetTickCount();
			g_adventure.stringline+=1;

			if(g_adventure.stringline > g_adventure.adventure_end)
			{
				g_adventure.stringline=g_adventure.adventure_end;
				for(int i=0; i < 2; i++)
				{
					g_player[i]->state=PLAYER_STATE_IDLE;
				}

				if(g_game.endtype == 0)
				{
					g_game.state=GAME;
				}
				else
				{
					g_game.state=END;
					InitEnd();
				}
			}
			int setype=g_adventure.adventure_voice_type[g_adventure.stringline];
			if(setype!= -1)
			{
				if(setype == BGM_ED)
				{
					DsoundAllStop(ALL_STOP);
					DSoundPlay(g_bgm[setype],true);
				}
				else
				{
					if(DSoundIsStop(g_se[setype]))
					{
						DSoundPlay(g_se[setype],false);
					}
				}
			}
		}
	}
};
/*
*	@fn�@�A�h�x���`���[�p�[�g�̕`��
*/
void DrawAdventure()
{
	LPSTR strp=(LPSTR)&g_adventure.string_data[g_adventure.stringline];
	LPSTR strp2=(LPSTR)&g_adventure.name_data[g_adventure.charname_no[g_adventure.stringline]];
	bool block=false;
	bool facerender=true;
	int textype=g_adventure.facetexture_data[g_adventure.stringline];
	float current_time_ms=(float)GetTickCount();
	float elapsed_time_s=((current_time_ms-g_game.start_time_ms)/1000);

	if(g_game.endtype==1)
	{
		DrawTexture2D(0,0,1.0f,g_tex[KAGARI_STILL],false,0);
	}
	else if(g_game.endtype==2)
	{
		DrawTexture2D(0,0,1.0f,g_tex[LUI_STILL],false,0);
	}

	DrawTexture2D(220,510,1.0f,g_tex[TEXTWINDOW],false,0);

	if(elapsed_time_s>ADVENTURE_LIMIT_TIME)
	{
		static int use_timming=0;
		if(use_timming>20)
		{
			DrawTexture2D(1080,600,1.0f,g_tex[CORSOR],false,0);
		}
		if(use_timming>40)
		{
			use_timming=0;
		}
		use_timming++;
	}
	if(g_tex[textype]==g_tex[KAGARI_FACE])
	{
		block=true;
	}
	else if(g_tex[textype]==g_tex[LUI_FACE])
	{
		block=true;
	}
	const char* facerender_false_name[]=
	{
		"�J�K����",
		"���C�o",
		"���߂̒j",
		"TV�̐�",
	};
	for(int i=0;i<4;i++)
	{
		if(strcmp(strp2,facerender_false_name[i])==0)
		{
			facerender=false;
			break;
		}
	}
	if(facerender)
	{
		int faceno=g_adventure.faceno_data[g_adventure.stringline];
		DrawTexture2D(140,470,1.0f,g_tex[textype],block,faceno);
	}
	FontDrawString(strp,390,610,1000,1000,
				   D3DCOLOR_ARGB(255,255,255,255),false);
	FontDrawString(strp2,390,530,1000,1000,
				   D3DCOLOR_ARGB(255,255,255,255),false);

	if(g_game.endtype!=0)
	{
		DrawColorPolygon(g_color_polygon.a,g_color_polygon.r,
						 g_color_polygon.g,g_color_polygon.b);
	}
};