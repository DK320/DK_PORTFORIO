/**
*	@file	title.cpp
*	@brief	�^�C�g���̏���
*	@author	D.K
*	@data	2020/02/05
*/
#include"title.h"
#include"../global/global.h"
#include"game.h"
#include"../stage/player.h"
#include"../camera/camera.h"
#include"../stage/stage.h"
#include"../Directx9/Directx9MyLib.h"
#include"../sound/dslib.h"
#include"stageselect.h"
/*
*	@fn �^�C�g����ʂ̏�����
*/
void InitTitle()
{
	DsoundAllStop(ALL_STOP);
	DSoundPlay(g_bgm[BGM_TITLE],true);

	g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].x=70.0f;
	g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].y=470.0f;
	g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].dx=0.0f;
	g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].dy=100.0f;
}
/*
*	@fn �^�C�g����ʂ̏���
*/
void ProcessTitle()
{
	if(g_input_state[INPUT_STATE_PADTRG] & PAD_B)
	{
		if(g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].y==470)
		{
			g_game.state=STAGESELECT;
			InitStageSelect();
			DSoundStop(g_bgm[BGM_TITLE]);
		}
		else if(g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].y==570)
		{
			PostQuitMessage(0);
		}

		if(DSoundIsStop(g_se[SE_DECISION]))
		{
			DSoundStop(g_se[SE_DECISION]);
			DSoundPlay(g_se[SE_DECISION],FALSE);
		}
	}

	if(g_input_state[INPUT_STATE_PADTRG] & PAD_DOWN)
	{
		g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].y+=
			g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].dy;

		if(g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].y>570)
		{
			g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].y=570.0f;
		}
		else
		{
			DSoundStop(g_se[SE_CURSOR]);
			DSoundPlay(g_se[SE_CURSOR],FALSE);
		}
	}

	if(g_input_state[INPUT_STATE_PADTRG] & PAD_UP)
	{
		g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].y-=
			g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].dy;

		if(g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].y<470)
		{
			g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].y=470.0f;
		}
		else
		{
			DSoundStop(g_se[SE_CURSOR]);
			DSoundPlay(g_se[SE_CURSOR],FALSE);
		}
	}
}
/*
*	@fn �^�C�g����ʂ̕`��
*/
void DrawTitle()
{
	
	DrawTexture2D(0.0f,0.0f,1.0f,g_tex[BACK_TITLE],false,0);
	DrawTexture2D(40.0f,30.0f,1.0f,g_tex[LOGO_TITLE],false,0);
	DrawTexture2D(130.0f,470.0f,1.0f,g_tex[START_TITLE],false,0);
	DrawTexture2D(130.0f,570.0f,1.0f,g_tex[EXIT_TITLE],false,0);
	DrawTexture2D(g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].x,
				  g_tex_info[TEX_INFO_TYPE_TITLE_CORSOR].y,
				  1.0f,g_tex[CORSOR],false,0);
}
