/**
*	@file	gameover.cpp
*	@brief	�Q�[���I�[�o�[��ʂ̏���
*	@author	D.K
*	@data	2019/02/19
*/
#include"gameover.h"
#include"../global/global.h"
#include"../sound/dslib.h"
#include"title.h"
#include"stageselect.h"
/*
*	@fn �Q�[���I�[�o�[��ʂ̏�����
*/
void InitGameOver()
{
	DSoundPlay(g_se[SE_GAMEOVER],false);
	g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].x=60;
	g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].y=400;
	g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].dx=640;
	g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].dy=0;
}
/*
*	@fn �Q�[���I�[�o�[��ʂ̏���
*/
void ProcessGameOver()
{

	if(g_input_state[INPUT_STATE_PADTRG] &PAD_LEFT)
	{
		g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].x-=
			g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].dx;

		if(g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].x<60)
		{
			g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].x=60;
		}
		else
		{
			DSoundStop(g_se[SE_CURSOR]);
			DSoundPlay(g_se[SE_CURSOR],FALSE);
		}
	}
	else if(g_input_state[INPUT_STATE_PADTRG] &PAD_RIGHT)
	{
		g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].x+=
			g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].dx;

		if(g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].x>700)
		{
			g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].x=700;
		}
		else
		{
			DSoundStop(g_se[SE_CURSOR]);
			DSoundPlay(g_se[SE_CURSOR],FALSE);
		}
	}

	if(g_input_state[INPUT_STATE_PADTRG] & PAD_B)
	{
		if(DSoundIsStop(g_se[SE_DECISION]))
		{
			DSoundStop(g_se[SE_DECISION]);
			DSoundPlay(g_se[SE_DECISION],FALSE);
		}

		if(g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].x==700)
		{
			DSoundStop(g_bgm[BGM_STAGE_1]);
			InitTitle();
			g_game.state=TITLE;
		}

		if(g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].x==60)
		{
			DSoundStop(g_bgm[BGM_STAGE_1]);
			InitStageSelect();
			g_game.state=STAGESELECT;
		}
	}
}
/*
*	@fn �Q�[���I�[�o�[��ʂ̕`��
*/
void DrawGameOver()
{
	DrawTexture2D(160,120,1.0f,g_tex[LOGO_GAMEOVER],false,0);
	DrawTexture2D(120,400,1.0f,g_tex[STAGE],false,0);
	DrawTexture2D(760,400,1.0f,g_tex[CLEAR_TITLE],false,0);
	DrawTexture2D(g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].x,
				  g_tex_info[TEX_INFO_TYPE_GAMEOVER_CORSOR].y,
				  1.0f,g_tex[CORSOR],false,0);
}