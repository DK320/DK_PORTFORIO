/**
*	@file	game.cpp
*	@brief	�Q�[���{��
*	@author	D.K
*	@data	2019/11/05
*/
#include"game.h"
#include"../camera/camera.h"
#include"../Directx9/Directx9MyLib.h"
#include"../stage/player.h"
#include"../sound/dslib.h"

#include"../stage/stage.h"
#include"../global/global.h"
#include"title.h"
#include"goal.h"
#include"adventure.h"
#include"stageselect.h"
#include"gameover.h"
#include"end.h"

int g_input_state[INPUT_STATE_MAX]={0};			//���͏�� 
struct GAME g_game={ 0 };						//�Q�[�����
struct COLOR_POLYGON g_color_polygon={0};		//�F�t���|���S��
bool g_teamlogo_render=false;					//�`�[�����S�`�悵�����H
/*
*	@fn �|���S���̐F���w�肷��
*	@param a,r,g,b �F
*/
void Setargb(int a,int r,int g,int b)
{
	g_color_polygon.a=a;
	g_color_polygon.r=r;
	g_color_polygon.g=g;
	g_color_polygon.b=b;

}
/*
*	@fn SOUND�����[�h����
*	@param sound_type ���y�̎�ށiSE��BGM���j
*	@param load_type ���̎��
*	@param filename	�t�@�C���̖��O
*/
void LoadSound(int sound_type,int load_type,const char* filename)
{
	if(sound_type==SOUND_LOAD_TYPE_BGM)
	{
		g_bgm[load_type]=DSoundLoadFile((LPSTR)filename,-1,DSLF_FLG_STREAM);
	}
	else if(sound_type==SOUND_LOAD_TYPE_SE)
	{
		g_se[load_type]=DSoundLoadFile((LPSTR)filename,-1,DSLF_FLG_STATIC);
	}
}
/*
*	@fn FBX�t�@�C�������[�h����
*	@param fbx_no �ǂ�FBX�t�@�C����
*	@param fbx_load_type_flg ���_�쐬���H���[�V�����ǉ����H
*	@param filename ���[�h����t�@�C���̖��O
*	@param motionname ���[�V�����̖��O
*/
void LoadMotion(int fbx_type,int fbx_load_type_flg,const char* filename,const char* motionname)
{
	if(fbx_load_type_flg==FBX_LOAD_TYPE_CREATE)
	{
		g_fbx_list[fbx_type].Create(filename);
	}
	else if(fbx_load_type_flg==FBX_LOAD_TYPE_ADDMOTION)
	{
		g_fbx_list[fbx_type].AddMotion((std::string)motionname,filename);
	}
}
/*
*	@fn FBX�t�@�C���̃��[�h
*/
void LoadFbx()
{
	struct FBX_LOAD_TABLE load_table[]=
	{
		{FBXTYPE_PLAYER_RITU,FBX_LOAD_TYPE_CREATE,"Assets/player/ritu/ritu.fbx",""},
		{FBXTYPE_PLAYER_RITU,FBX_LOAD_TYPE_ADDMOTION,"Assets/player/ritu/purification.fbx","playerpurification"},
		{FBXTYPE_PLAYER_RITU,FBX_LOAD_TYPE_ADDMOTION,"Assets/player/ritu/wait.fbx","playerwait"},
		{FBXTYPE_PLAYER_RITU,FBX_LOAD_TYPE_ADDMOTION,"Assets/player/ritu/walk.fbx","playerwalk"},
		{FBXTYPE_KAGO,FBX_LOAD_TYPE_CREATE,"Assets/player/ritu/kago.fbx",""},
		{FBXTYPE_KAGO,FBX_LOAD_TYPE_ADDMOTION,"Assets/player/ritu/purification_gage.fbx","playerpurification"},
		{FBXTYPE_KAGO,FBX_LOAD_TYPE_ADDMOTION,"Assets/player/ritu/wait_gage.fbx","playerwait"},
		{FBXTYPE_KAGO,FBX_LOAD_TYPE_ADDMOTION,"Assets/player/ritu/walk_gage.fbx","playerwalk"},
		{FBXTYPE_GOAL,FBX_LOAD_TYPE_CREATE,"Assets/stage/goal/goal.fbx",""},
		{FBXTYPE_BASE,FBX_LOAD_TYPE_CREATE,"Assets/stage/base/base.fbx",""},
		{FBXTYPE_START,FBX_LOAD_TYPE_CREATE,"Assets/stage/start/start.fbx",""},
		{FBXTYPE_ROLL,FBX_LOAD_TYPE_CREATE,"Assets/stage/roll/roll.fbx",""},
		{FBXTYPE_LIFT,FBX_LOAD_TYPE_CREATE,"Assets/stage/lift/lift.fbx",""},
		{FBXTYPE_BACK,FBX_LOAD_TYPE_CREATE,"Assets/back/back_1/stage1.fbx",""},
		{FBXTYPE_PUPA,FBX_LOAD_TYPE_CREATE,"Assets/stage/pupa/pupa_ste.fbx",""},
		{FBXTYPE_CULTURE_TANK,FBX_LOAD_TYPE_CREATE,"Assets/stage/pupa/culture_tank/culture_tank.fbx",""},
		{FBXTYPE_WARP,FBX_LOAD_TYPE_CREATE,"Assets/stage/warp/warp.fbx",""},
		{FBXTYPE_BACK_2,FBX_LOAD_TYPE_CREATE,"Assets/back/back_2/stage2.fbx",""},
		{FBXTYPE_BASE_2,FBX_LOAD_TYPE_CREATE,"Assets/stage/base/base_b/base_b.fbx",""},
		{FBXTYPE_BACK_3,FBX_LOAD_TYPE_CREATE,"Assets/back/back_3/back_b.fbx",""},
		{FBXTYPE_BASE_3,FBX_LOAD_TYPE_CREATE,"Assets/stage/base/base_c/base_c.fbx",""},
	};
	for(int i=0;i<21;i++)
	{
		LoadMotion(load_table[i].fbx_type,load_table[i].fbx_load_type_flg,
				   load_table[i].filename,load_table[i].motionname);
	}
}
/*
*	@fn se��bgm�̓ǂݍ���
*/
void LoadSeBgm()
{
	struct SOUND_LOAD_TABLE load_table[]=
	{
		{SOUND_LOAD_TYPE_BGM,BGM_STAGE_1,"sound/bgm/bgm_stage1.wav"},
		{SOUND_LOAD_TYPE_BGM,BGM_STAGE_2,"sound/bgm/bgm_stage2.wav"},
		{SOUND_LOAD_TYPE_BGM,BGM_ED,"sound/bgm/bgm_ed.wav"},
		{SOUND_LOAD_TYPE_BGM,BGM_TITLE,"sound/bgm/bgm_title.wav"},
		{SOUND_LOAD_TYPE_BGM,BGM_STAGESELECT,"sound/bgm/bgm_stage_select.wav"},
		{SOUND_LOAD_TYPE_BGM,BGM_ENDROLL,"sound/bgm/bgm_endroll.wav"},
		{SOUND_LOAD_TYPE_SE,SE_CURSOR,"sound/se/se_cursor.wav"},
		{SOUND_LOAD_TYPE_SE,SE_CANCEL,"sound/se/se_cancel.wav"},
		{SOUND_LOAD_TYPE_SE,SE_DECISION,"sound/se/se_decision.wav"},
		{SOUND_LOAD_TYPE_SE,SE_MOVE,"sound/se/se_move.wav"},
		{SOUND_LOAD_TYPE_SE,SE_PURIFICATION,"sound/se/se_purification.wav"},
		{SOUND_LOAD_TYPE_SE,SE_SURPRISE,"sound/se/se_surprise.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_RITU1,"sound/voice/ritu/voice_ritu1.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_RITU2,"sound/voice/ritu/voice_ritu2.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_RITU3,"sound/voice/ritu/voice_ritu3.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_RITU4,"sound/voice/ritu/voice_ritu4.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_RITU5,"sound/voice/ritu/voice_ritu5.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_RITU6,"sound/voice/ritu/voice_ritu6.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_RITU7,"sound/voice/ritu/voice_ritu7.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_RITU8,"sound/voice/ritu/voice_ritu8.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_RITU9,"sound/voice/ritu/voice_ritu9.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_RITU10,"sound/voice/ritu/voice_ritu10.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_RITU11,"sound/voice/ritu/voice_ritu11.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_KAGARI1,"sound/voice/kagari/voice_kagari1.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_KAGARI2,"sound/voice/kagari/voice_kagari2.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_KAGARI3,"sound/voice/kagari/voice_kagari3.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_KAGARI4,"sound/voice/kagari/voice_kagari4.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_KAGARI5,"sound/voice/kagari/voice_kagari5.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_KAGARI6,"sound/voice/kagari/voice_kagari6.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_KAGARI7,"sound/voice/kagari/voice_kagari7.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_KAGARI8,"sound/voice/kagari/voice_kagari8.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_KAGARI9,"sound/voice/kagari/voice_kagari9.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_KAGARI10,"sound/voice/kagari/voice_kagari10.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_KAGARI11,"sound/voice/kagari/voice_kagari11.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_KAGARI12,"sound/voice/kagari/voice_kagari12.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_LUI1,"sound/voice/lui/voice_lui1.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_LUI2,"sound/voice/lui/voice_lui2.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_LUI3,"sound/voice/lui/voice_lui3.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_LUI4,"sound/voice/lui/voice_lui4.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_LUI5,"sound/voice/lui/voice_lui5.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_LUI6,"sound/voice/lui/voice_lui6.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_LUI7,"sound/voice/lui/voice_lui7.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_LUI8,"sound/voice/lui/voice_lui8.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_LUI9,"sound/voice/lui/voice_lui9.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_LUI10,"sound/voice/lui/voice_lui10.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_LUI11,"sound/voice/lui/voice_lui11.wav"},
		{SOUND_LOAD_TYPE_SE,VOICE_LUI12,"sound/voice/lui/voice_lui12.wav"},
		{SOUND_LOAD_TYPE_SE,SE_DOOR_OPEN,"sound/se/se_door_open.wav"},
		{SOUND_LOAD_TYPE_SE,SE_HOLD,"sound/se/se_hold.wav"},
		{SOUND_LOAD_TYPE_SE,SE_SCENESWITCHING,"sound/se/se_SceneSwitching.wav"},
		{SOUND_LOAD_TYPE_SE,SE_CRUMBLE,"sound/se/se_crumble.wav"},
		{SOUND_LOAD_TYPE_SE,SE_HIT,"sound/se/se_hit.wav"},
		{SOUND_LOAD_TYPE_SE,SE_COLLAPSE,"sound/se/se_collapse.wav"},
		{SOUND_LOAD_TYPE_SE,SE_GAMECLEAR,"sound/se/se_gameclear.wav"},
		{SOUND_LOAD_TYPE_SE,SE_GAMEOVER,"sound/se/se_gameover.wav"},
	};
	for(int i=0;i<55;i++)
	{
		LoadSound(load_table[i].sound_type,
				  load_table[i].load_type,
				  load_table[i].filename);
	}
	DSoundSetVolume(g_bgm[BGM_STAGE_1],80);
}
/*
*	@fn texture�̓ǂݍ���
*/
void LoadTex()
{
	struct TEXTURE_LOAD_TABLE load_table[]=
	{
		{LOGO_TITLE,"res/1_logo_title.png"},
		{BACK_TITLE,"res/12_back_title.png"},
		{START_TITLE,"res/13_start.png"},
		{EXIT_TITLE,"res/14_exit.png"},
		{CORSOR,"res/10_ui_cursor.png"},
		{LOGO_GAMEOVER,"res/4_logo_gameover.png"},
		{LOGO_GAMECLEAR,"res/3_logo_gameclear.png"},
		{UI_INSTRUCTIONS,"res/ui_Instructions.png"},
		{TEXTWINDOW,"res/9_ui_textwindow.png"},
		{RESTART,"res/15_restart.png"},
		{CLEAR_TITLE,"res/16_title.png"},
		{BACK,"res/17_back.png"},
		{STAGE,"res/18_stage.png"},
		{PLAYER_SHADOW,"res/shadow.png"},
		{KAGARI_STAND,"res/kagari_texture/kagaristand.png"},
		{KAGARI_FACE,"res/kagari_texture/face_kagari.png"},
		{UI_STAGESELECT1,"res/11_ui_select1.png"},
		{UI_STAGESELECT2,"res/11_ui_select2.png"},
		{UI_STAGESELECT3,"res/11_ui_select3.png"},
		{BACK_SELECT,"res/21_back_select.png"},
		{UI_TIME,"res/0_ui_time.png"},
		{UI_PUPACOUNT,"res/0_ui_pupacount.png"},
		{RITU_FACE,"res/face_ritu.png"},
		{LUI_FACE,"res/lui_texture/face_lui.png"},
		{KAGARI_STILL,"res/kagari_texture/CG_kagari.png"},
		{LUI_STILL,"res/lui_texture/CG_lui.png"},
		{ENDROLL,"res/endroll.png"},
		{EXPLANATION,"res/ui_explanation.png"},
	};
	for(int i=0;i<28;i++)
	{
		g_tex[load_table[i].tex_type]=LoadTexture2D(load_table[i].filename);
	}
	
	BLOCKTEXTURE_INFO block_info;
	block_info.block_num=6;
	block_info.height_num=1;
	block_info.width_num=6;
	SetTextureBlock(g_tex[KAGARI_FACE],block_info);
	SetTextureBlock(g_tex[LUI_FACE],block_info);
}
/*
*	@fn �A�v���P�[�V�����̏�����
*/
void AppInit()
{
	g_game.state=TEAMLOGO;
	g_game.endtype=0;
	g_game.explanation=false;
	g_tex[LOGO_TEAM]=LoadTexture2D("res/2_logo_team.png");
	g_color_polygon.a=255;
	g_color_polygon.r=255;
	g_color_polygon.g=255;
	g_color_polygon.b=255;
	g_directx.device->SetRenderState(D3DRS_ALPHABLENDENABLE,true);
	g_directx.device->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
	g_directx.device->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
}	
/*
*	@fn ����
*/
void FrameInput()
{	
#ifdef CONTROLLER
	int pad_old=g_input_state[INPUT_STATE_PAD];
	g_input_state[INPUT_STATE_PAD]=JoyInput(0);
	g_input_state[INPUT_STATE_PADTRG]=
		(g_input_state[INPUT_STATE_PAD] ^ pad_old)&g_input_state[INPUT_STATE_PAD];
#endif
#ifdef MOUSE
	g_input_state[INPUT_STATE_MOUSE]=MouseInput(0);
#endif // MOUSE
#ifdef KEYBORD
	g_input_state[INPUT_STATE_KEY]=KeyInput(0);
#endif // KEYBORD
}
/*
*	@fn ����
*/
void FrameProcess()
{
	switch(g_game.state)
	{
	case TEAMLOGO:
	g_color_polygon.a-=10;
	if(g_teamlogo_render)
	{
		if(g_color_polygon.a<=0)
		{
			g_color_polygon.a=0;
			LoadSeBgm();
			LoadTex();
			InitTexturePoly();
			LoadFbx();
			if(g_fbx_list[FBXTYPE_KAGO].CheckMotion((std::string)"playerwalk"))
			{
				g_game.state=TITLE;
				InitTitle();
			}
		}
	}
	break;
	case TITLE:
		ProcessTitle();
		break;
	case STAGESELECT:
		ProcessStageSelect();
		break;
	case GAME:
		CameraProcess();
		if(g_color_polygon.a==0)
		{
			//����������ʂ��\������Ă���Ȃ�
			if(g_game.explanation==true||
			   g_game.stage==TWO||
			   g_game.stage==THREE)
			{
				if(g_game.fream==0)
				{
					DSoundPlay(g_se[VOICE_RITU1],false);
				}
				ProcessStage();
				ProcessPlayer();
				TimeCount();
			}
			else
			{
				if(g_game.start_time_ms==0)
				{
					g_game.start_time_ms=(float)GetTickCount();
				}
				float current_time_ms=(float)GetTickCount();
				if(((current_time_ms-g_game.start_time_ms)/1000)>1.0)
				{
					if(g_input_state[INPUT_STATE_PAD]&PAD_B)
					{
						g_game.explanation=true;
					}
				}
			}
		}
		break;
	case GOAL:
		ProcessStage();
		ProcessGoal();
		break;
	case ADVENTURE:
		if(g_game.endtype==0)
		{
			ProcessStage();
		}
		ProcessAdventure();
		break;
	case GAMEOVER:
		ProcessStage();
		ProcessGameOver();
		break;
	case END:
		ProcessEnd();
		break;
	}
}
/*
*	@fn �`��
*/
void FrameRender()
{
	switch(g_game.state)
	{
	case TEAMLOGO:
		DrawColorPolygon(255,255,255,255);
		DrawTexture2D(240.0f,280.0f,1.0f,g_tex[LOGO_TEAM],false,0);
		DrawColorPolygon(g_color_polygon.a, 255,255,255);
		g_teamlogo_render=true;
		break;
	case TITLE:
		DrawTitle();
		break;
	case STAGESELECT:
		DrawStageSelect();
		break;
	case GAME:
		DrawStage();
		DrawPlayer();
		DrawTime();
		if(g_color_polygon.a>0)
		{
			g_color_polygon.a--;
			DrawColorPolygon(g_color_polygon.a,g_color_polygon.r,
							 g_color_polygon.g,g_color_polygon.b);
		}
		if(g_game.stage==ONE)
		{	
			if(g_color_polygon.a==0 && g_game.explanation==false)
			{
				if(g_game.start_time_ms!=0)
				{
					float current_time_ms=(float)GetTickCount();
					if(((current_time_ms - g_game.start_time_ms)/1000)>1.0)
					{
						DrawTexture2D(120,40,1.0f,g_tex[EXPLANATION],false,0);
					}
				}
			}
		}
		break;
	case GOAL:
		DrawStage();
		DrawPlayer();
		DrawGoal();
		break;
	case ADVENTURE:
		if(g_game.endtype==0)
		{
			DrawStage();
			DrawPlayer();
			DrawTime();
		}
		DrawAdventure();
		break;
	case GAMEOVER:
		DrawStage();
		DrawPlayer();
		DrawTime();
		DrawGameOver();
		break;
	case END:
		DrawEnd();
		break;
	}
}
/*
*	@fn �A�v���P�[�V�����̊J��
*/
void AppRelease()
{
	ReleaseTexture2D();
	DeletePlayer();
	DeleteStage();
	for(int i=0; i<BGM_MAX; i++)
	{
		DSoundReleaseChannel(g_bgm[i]);
	}
	for(int i=0; i<SE_MAX; i++)
	{
		DSoundReleaseChannel(g_se[i]);
	}
}