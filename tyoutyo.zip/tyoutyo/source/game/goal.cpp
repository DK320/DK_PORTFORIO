/**
*	@file	goal.cpp
*	@brief	�S�[���̏���
*	@author	D.K
*	@data	2020/02/06
*/
#include"game.h"
#include"../global/global.h"
#include"../sound/dslib.h"
#include"title.h"
#include"stageselect.h"
#include"adventure.h"
/*
*	@fn �S�[����ʂ̏�����
*/
void InitGoal()
{
	switch(g_game.stage)
	{
	case TWO:
		g_game.endtype=1;
		break;
	case THREE:
		g_game.endtype=2;
		break;
	}

	g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].x=60;
	g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].y=400;
	g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].dx=640;
	g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].dy=0;

	DSoundPlay(g_se[SE_GAMECLEAR],false);
}
/*
*	@fn �S�[����ʂ̏���
*/
void ProcessGoal()
{
	if(g_game.endtype==0)
	{
		if(g_input_state[INPUT_STATE_PADTRG] &PAD_LEFT)
		{
			g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].x-=
				g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].dx;

			if(g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].x<60)
			{
				g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].x=60;
			}
			else
			{
				DSoundStop(g_se[SE_CURSOR]);
				DSoundPlay(g_se[SE_CURSOR],FALSE);
			}
		}
		else if(g_input_state[INPUT_STATE_PADTRG] &PAD_RIGHT)
		{
			g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].x+=
				g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].dx;

			if(g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].x>700)
			{
				g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].x=700;
			}
			else
			{
				DSoundStop(g_se[SE_CURSOR]);
				DSoundPlay(g_se[SE_CURSOR],FALSE);
			}
		}
		if(g_input_state[INPUT_STATE_PADTRG] & PAD_B)
		{
			if(DSoundIsStop(g_se[SE_DECISION]))
			{
				DSoundStop(g_se[SE_DECISION]);
				DSoundPlay(g_se[SE_DECISION],FALSE);
			}
			
			if(g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].x==700)
			{
				DSoundStop(g_bgm[BGM_STAGE_1]);
				InitTitle();
				g_game.state=TITLE;
			}
			
			if(g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].x==60)
			{
				DSoundStop(g_bgm[BGM_STAGE_1]);
				InitStageSelect();
				g_game.state=STAGESELECT;
			}
		}
	}
	else
	{
		if(g_input_state[INPUT_STATE_PADTRG] & PAD_B)
		{
			int no=0;

			if(g_game.stage==TWO)
			{
				no=0;
			}
			else if(g_game.stage==THREE)
			{
				no=1;
			}

			int story[][2]={
				{KAGARI_9_1,KAGARI_9_23 },
				{LUI_9_1,LUI_9_20},
			};

			g_game.state=ADVENTURE;
			InitAdventure(story[no][0],story[no][1]);
		}
	}
}
/*
*	@fn �S�[����ʂ̕`��
*/
void DrawGoal()
{
	DrawTexture2D(160,120,1.0f,g_tex[LOGO_GAMECLEAR],false,0);

	if(g_game.endtype==0)
	{
		DrawTexture2D(120,400,1.0f,g_tex[STAGE],false,0);
		DrawTexture2D(760,400,1.0f,g_tex[CLEAR_TITLE],false,0);
		DrawTexture2D(g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].x,
					  g_tex_info[TEX_INFO_TYPE_GOAL_CORSOR].y,
					  1.0f,g_tex[CORSOR],false,0);
	}
	else
	{
		DrawTexture2D(280,320,1.0f,g_tex[UI_INSTRUCTIONS],false,0);
	}
}