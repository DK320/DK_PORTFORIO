#include"end.h"
#include"../global/global.h"
#include"title.h"
/*
*	@fn �G���h���[���̏�����
*/
void InitEnd()
{
	DsoundAllStop(ALL_STOP);
	DSoundPlay(g_bgm[BGM_ENDROLL],true);

	Setargb(255,0,0,0);

	g_tex_info[TEX_INFO_TYPE_END_CORSOR].x=280;
	g_tex_info[TEX_INFO_TYPE_END_CORSOR].y=0;
	g_tex_info[TEX_INFO_TYPE_END_CORSOR].dx=0;
	g_tex_info[TEX_INFO_TYPE_END_CORSOR].dy=-1;
}
/*
*	@fn �G���h���[���̏���
*/
void ProcessEnd()
{
	if(g_color_polygon.a>0)
	{
		g_color_polygon.a-=1;
	}
	else
	{
		g_tex_info[TEX_INFO_TYPE_END_CORSOR].y+=
			g_tex_info[TEX_INFO_TYPE_END_CORSOR].dy;

		if(g_tex_info[TEX_INFO_TYPE_END_CORSOR].y<-5000)
		{
			g_tex_info[TEX_INFO_TYPE_END_CORSOR].y=-5000;
			g_game.state=TITLE;
			InitTitle();
		}

		g_color_polygon.a=0;
	}
}
/*
*	@fn �G���h���[���̕`��
*/
void DrawEnd()
{
	DrawColorPolygon(255,0,0,0);

	float x=g_tex_info[TEX_INFO_TYPE_END_CORSOR].x;
	float y=g_tex_info[TEX_INFO_TYPE_END_CORSOR].y;
	DrawTexture2D(x,y,1.0f,g_tex[ENDROLL],false,0);

	if(g_color_polygon.a>0)
	{
		DrawColorPolygon(g_color_polygon.a,g_color_polygon.r,
						 g_color_polygon.g,g_color_polygon.b);
	}
}