/**
*	@file	stageselect.cpp
*	@brief	�X�e�[�W�̑I����ʂ̏���
*	@author	D.K
*	@data	2019/02/18
*/
#include"../Directx9/Directx9MyLib.h"
#include"../global/global.h"
#include"../stage/player.h"
#include"../stage/stage.h"
#include"../camera/camera.h"
#include"../sound/dslib.h"
/*
*	@fn �Q�[���̏�����
*	@fn stage �X�e�[�W��
*	@fn bgm bgm�ԍ�
*/
static void InitGame(int stage,int bgm)
{
	g_game.mode=CUBE_UP;
	g_game.stage=stage;
	g_game.initialized=true;
	g_game.state=GAME;

	InitPlayer();
	InitStage();
	InitCamera();

	Setargb(255,255,255,255);

	DsoundAllStop(ALL_STOP);
	DSoundPlay(bgm,true);
	InitStageTime(200);
};
/*
*	@fn �X�e�[�W�I����ʂ̏�����
*/
void InitStageSelect()
{
	DsoundAllStop(ALL_STOP);
	DSoundPlay(g_bgm[BGM_STAGESELECT],true);

	g_tex_info[TEX_INFO_TYPE_STAGESELECT_CORSOR].x=20;
	g_tex_info[TEX_INFO_TYPE_STAGESELECT_CORSOR].y=120;
	g_tex_info[TEX_INFO_TYPE_STAGESELECT_CORSOR].dx=400;
	g_tex_info[TEX_INFO_TYPE_STAGESELECT_CORSOR].dy=0;
};
/*
*	@fn �X�e�[�W�I����ʂ̏���
*/
void ProcessStageSelect()
{
	if(g_input_state[INPUT_STATE_PADTRG]&PAD_RIGHT)
	{
		g_tex_info[TEX_INFO_TYPE_STAGESELECT_CORSOR].x+=
			g_tex_info[TEX_INFO_TYPE_STAGESELECT_CORSOR].dx;

		if(g_tex_info[TEX_INFO_TYPE_STAGESELECT_CORSOR].x>820)
		{
			g_tex_info[TEX_INFO_TYPE_STAGESELECT_CORSOR].x=820;
		}
		else
		{
			DSoundStop(g_se[SE_CURSOR]);
			DSoundPlay(g_se[SE_CURSOR],FALSE);
		}
	}
	if(g_input_state[INPUT_STATE_PADTRG]&PAD_LEFT)
	{
		g_tex_info[TEX_INFO_TYPE_STAGESELECT_CORSOR].x-=
			g_tex_info[TEX_INFO_TYPE_STAGESELECT_CORSOR].dx;

		if(g_tex_info[TEX_INFO_TYPE_STAGESELECT_CORSOR].x<20)
		{
			g_tex_info[TEX_INFO_TYPE_STAGESELECT_CORSOR].x=20;
		}
		else
		{
			DSoundStop(g_se[SE_CURSOR]);
			DSoundPlay(g_se[SE_CURSOR],FALSE);
		}
	}
	if(g_input_state[INPUT_STATE_PADTRG]&PAD_B)
	{
		int x=g_tex_info[TEX_INFO_TYPE_STAGESELECT_CORSOR].x;
		switch(x)
		{
		case 20:
			InitGame(ONE,g_bgm[BGM_STAGE_1]);
			break;
		case 420:
			InitGame(TWO,g_bgm[BGM_STAGE_2]);
			break;
		case 820:
			InitGame(THREE,g_bgm[BGM_STAGE_2]);
			break;
		default:
			break;
		}

		if(DSoundIsStop(g_se[SE_DECISION]))
		{
			DSoundStop(g_se[SE_DECISION]);
			DSoundPlay(g_se[SE_DECISION],FALSE);
		}
	}
};
/*
*	@fn �X�e�[�W�I����ʂ̕`��
*/
void DrawStageSelect()
{
	DrawTexture2D(0.0f,0.0f,1.0f,g_tex[BACK_SELECT],false,0);
	DrawTexture2D(80.0f,120.0f,1.0f,g_tex[UI_STAGESELECT1],false,0);
	DrawTexture2D(480.0f,120.0f,1.0f,g_tex[UI_STAGESELECT2],false,0);
	DrawTexture2D(880.0f,120.0f,1.0f,g_tex[UI_STAGESELECT3],false,0);
	DrawTexture2D(g_tex_info[TEX_INFO_TYPE_STAGESELECT_CORSOR].x,
				  g_tex_info[TEX_INFO_TYPE_STAGESELECT_CORSOR].y,
				  1.0f,g_tex[CORSOR],false,0);
};