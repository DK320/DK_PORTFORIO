#include  "vivacious_spring_selectstage.h"
#include	"../system/common.h"
#include	"../system/vivacious_spring_se.h"
#include	"../ingame/vivacious_spring_game.h"
#include  "../system/vivacious_spring_bgm.h"
#include  "game_setting.h"
#include  "charselect.h"
#include	"vivacious_spring_clear.h"


int cgFrame_b_On;
int cgFrame_b_Off;
int cgFrame_v_On;
int cgFrame_v_Off;
int character = 0;


int CharSelect()
{
	rand_voice = rand() % 2;

	if (gTrg & KEYIN_DOWN && gamecount == 5)
	{
		if (se_button == false)
		{
			PlayMemBack(se_move);
		}
		cursor++;
		if (cursor > 1)
		{
			cursor = 1;
		}
	}
	if (gTrg & KEYIN_UP)
	{
		if (se_button == false)
		{
			PlayMemBack(se_move);
		}
		cursor--;
		if (cursor < 0)
		{
			cursor = 0;
		}
	}
	if (gTrg & KEYIN_Z && cursor == 0)
	{
		if (voice_button2 == false)
		{
			switch (rand_voice)
			{
			case 0:

				if (rand_voice == 0)
				{
					PlayMemBack(voice_start_b_1);
				}
				break;
			case 1:
				if (rand_voice == 1)
				{
					PlayMemBack(voice_start_b_2);
				}
				break;
			}
		}
		PlayMemBack(seDecide);
		character = 1;
		InitStage();
		InitCharCur();
		return STATE_GAME;
	}
	/*else if (gTrg & KEYIN_SPC && cursor == 0)
	{
		if (voice_button == false)
		{
			switch (rand_voice)
			{
			case 0:

				if (rand_voice == 0)
				{
					PlayMemBack(voice_start_b_1);
				}
				break;
			case 1:
				if (rand_voice == 1)
				{
					PlayMemBack(voice_start_b_2);
				}
				break;
			}
		}
		PlayMemBack(seDecide);
		character = 1;
		InitStage();
		InitCharCur();
		return STATE_GAME;
	}
*/

	if (gTrg & KEYIN_Z && cursor == 1)
	{
		if (voice_button2 == false)
		{
			PlayMemBack(seDecide);
			switch (rand_voice)
			{
			case 0:
				if (rand_voice == 0)
				{
					PlayMemBack(voice_start_v_1);
				}
				break;
			case 1:
				if (rand_voice == 1)
				{
					PlayMemBack(voice_start_v_2);
				}
			}
		}

		character = 2;
		InitCharCur();
		InitStage();
		return STATE_GAME;

	}

	if (gTrg & KEYIN_X)
	{
		StopPlayMem(bgmStageselect);
		if (se_button == true)
		{
			PlayMemBack(seBack);
		}
		SetDrawBright(1000, 1000, 1000);
		return STATE_STAGESELECT;
	}
	return STATE_CHARSELECT;
}


void DrawCharSelect()
{
	DrawMemTh(0, 0, cgBlack);
	if (cursor == 0 && gamecount == 5)//�S�N������܂ŃL��������ł��Ȃ��悤��
	{

		SetDrawBright(1000, 1000, 1000);
		SetDrawMode(AMDRAW_ADDBLEND, 150);
		DrawMemTh(0, 0, cgWallPaper);
		DrawMemTh(0, 0, cgRoad);
		SetDrawMode(AMDRAW_ADDBLEND, 1000);
		DrawMemTh(360, 180, cgFrame_b_On);
		SetDrawBright(250, 250, 250);
		DrawMemTh(360, 400, cgFrame_v_Off);
	}
	if (cursor == 0 && gamecount < 5)
	{

		SetDrawBright(1000, 1000, 1000);
		SetDrawMode(AMDRAW_ADDBLEND, 150);
		DrawMemTh(0, 0, cgWallPaper);
		DrawMemTh(0, 0, cgRoad);
		SetDrawMode(AMDRAW_ADDBLEND, 1000);
		DrawMemTh(360, 180, cgFrame_b_On);
		SetDrawBright(100, 100, 100);
		DrawMemTh(360, 400, cgFrame_v_Off);
	}
	if (cursor == 1)
	{
		SetDrawBright(1000, 1000, 1000);
		SetDrawMode(AMDRAW_ADDBLEND, 150);
		DrawMemTh(0, 0, cgWallPaper);
		DrawMemTh(0, 0, cgRoad);
		SetDrawMode(AMDRAW_ADDBLEND, 1000);
		SetDrawBright(250, 250, 250);
		DrawMemTh(360, 180, cgFrame_b_Off);
		SetDrawBright(1000, 1000, 1000);
		DrawMemTh(360, 400, cgFrame_v_On);


	}

}