#pragma once

#include"../system/common.h"
#include "../amgame.h"
#include "../ingame/vivacious_spring.h"
#include	"../system/vivacious_spring_se.h"

#define STORY_STEP1 0
#define STORY_STEP2 1
#define STORY_STEP3 2
#define STORY_STEP4 3
#define STORY_STEP5 4
//#define STORY_STEP4 3
//#define STORY_STEP5 4
//#define STORY_STEP6 5
//#define STORY_STEP7 6




extern int gStep;
extern int cgKoma;
extern int cgKoma2;
extern int cgKoma3;
extern int cgKoma4;
extern int cgKoma5;
extern int cgManga;
extern int cgMoji;
extern int cgMoji2;
extern int cgStory1;
extern int cgStory2;
extern int cgStory3;
extern int cgStory4;
extern int cgStory5;
extern int cgStory6;
extern int cgStoryBg;
extern int cgStory_t1;
extern int cgStory_t2;
extern int cgStory_t3;
extern int cgStory_t4;
extern int cgStory_t5;
extern int cgStory_t6;
extern int cgStory_t7;
extern int cgStory_t8;
extern int cgStory_t9;
extern int cgStory_t10;
extern int cgStory_t11;
extern int cgStory_t12;

extern void DrawStoryBg();
extern void DrawStoryBg2();
extern void InitStory1();
extern int Story1();
extern void Koma();
extern void DrawStory1();
extern void DrawStory2();
extern void DrawStory3();
extern void DrawStory4();
extern void DrawStory5();