#include	<Windows.h>
#include	"../amgame.h"
#include	"../AmHelper.h"
#include	"../utility.h"
#include	<math.h>
#include	"../ingame/vivacious_spring.h"
#include	"../system/common.h"
#include	"vivacious_spring_clear.h"
#include	"../ingame/vivacious_spring_player.h"
#include	"../system/vivacious_spring_se.h"
#include	"../ingame/vivacious_spring_game.h"
#include	"../system/vivacious_spring_bgm.h"
#include	"vivacious_spring_title.h"
#include	"charselect.h"
#include	"../ingame/vivacious_spring_time.h"
#include	"../ingame/frame.h"
#include	"record.h"
#include	"game_setting.h"
int cgGoal = 0;
int cgClear = 0; //�N���A���
int cgSrank = 0;
int cgArank = 0;
int cgBrank = 0;
int cgCrank = 0;
int cgBlack = 0;//���w�i
int cgIcon_a = 0; //A�{�^��

int cgSuuji[SUUJI_MAX] = { 0 };

int clearcount = 0;
int gamecount = 5;//�N���A�������̃X�e�[�W���

int cgParts0 = 0;
int cgParts1 = 0;
int cgParts2 = 0;
int cgParts3 = 0;
int cgParts4 = 0;
int cgParts5 = 0;

int cgRankScreen = 0;
int cgClearBg = 0;
int rank = 0;
int srank = 100;
int arank = 80;
int brank = 40;
int crank = 0;
int point = 0;



int cgStage_name1 = 0;
int cgStage_name2 = 0;
int cgStage_name3 = 0;
int cgStage_name4 = 0;


void DrawClear() {
	SetDrawArea(0, 0, DISP_W, DISP_H);
	SetDrawMode(AMDRAW_NOBLEND, 0);
	DrawMemTh(200, 160, cgClear);
	//
	/*(30, 50, GetColor(255, 0, 0), "x = %f,y = %f", cgClearRank);
*/
}

int Clear() {
	/*StopPlayMem(bgmStage_1);*/
	f[CLEARRANKFRAME].frame++;
	if (f[CLEARRANKFRAME].frame >= 180) {
		f[CLEARRANKFRAME].frame = 0;
		if (voice_button2 == 1)
		{
			voice_button = 1;
		}
		else if (voice_button2 == 0)
		{
			voice_button = 0;
		}
		if (se_button == false)
		{
			PlayMemBack(seBack);
		}
		return STATE_CLEARRANK;
	}
	return STATE_CLEAR;
}



void LoadGoal() {
	cgGoal = LoadTexture("res/gimmick_goal.png");
}
void InitGoal() {
	InitChara(
		STAGE_1, CHARACTERTYPE_GOAL, cgGoal,
		12570, 440 - 80 + 560, 0, 0, 0, 1, 0, 0, -40, -80, 80, 80, 1, 0, 0
	);

	InitChara(
		STAGE_2, CHARACTERTYPE_GOAL, cgGoal,
		16960, 440 + 560, 0, 0, 0, 1, 0, 0, -40, -80, 80, 80, 1, 0, 0
	);
	InitChara(
		STAGE_3, CHARACTERTYPE_GOAL, cgGoal,
		40, 400 + 40, 0, 0, 0, 1, 0, 0, -40, -80, 80, 80, 1, 0, 0
	);
	InitChara(
		STAGE_4, CHARACTERTYPE_GOAL, cgGoal,
		2160, 2040 + 800, 0, 0, 0, 1, 0, 0, -40, -80, 80, 80, 1, 0, 0
	);
}
void Goal() {
	/*int se;*/
	int player = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);
	int goal = CheckCharaType(CHARACTERTYPE_GOAL, 1);
	ClearRankCalcu();
	if (HitChara(player, goal) == 1) {
		if (gNowstage == STAGE_1) {
			gamecount = 5;
			clearcount = f[GAMEFRAME].frame;
		}
		if (gNowstage == STAGE_2) {
			gamecount = 5;
			clearcount = f[GAMEFRAME].frame;
		}
		if (gNowstage == STAGE_3) {
			gamecount = 5;
			clearcount = f[GAMEFRAME].frame;
		}
		if (gNowstage == STAGE_4) {
			gamecount = 5;
			clearcount = f[GAMEFRAME].frame;
		}

		if (character == 1 && gNowstage == STAGE_1)
		{
			if (gParts > stage1b.parts) {
				stage1b.parts = gParts;
			}

			if (rank > stage1b.rank) {
				stage1b.rank = rank;
			}
			stage1b.coin = gCoin_b;
		}
		if (character == 2 && gNowstage == STAGE_1)
		{
			if (gParts > stage1v.parts) {
				stage1v.parts = gParts;
			}

			if (rank > stage1v.rank) {
				stage1v.rank = rank;
			}
			stage1v.coin = gCoin_v;
		}
		if (character == 1 && gNowstage == STAGE_2)
		{
			if (gParts > stage2b.parts) {
				stage2b.parts = gParts;
			}

			if (rank > stage1b.rank) {
				stage2b.rank = rank;
			}
			stage2b.coin = gCoin_b;
		}
		if (character == 2 && gNowstage == STAGE_2)
		{
			if (gParts > stage2v.parts) {
				stage2v.parts = gParts;
			}

			if (rank > stage2v.rank) {
				stage2v.rank = rank;
			}
			stage2v.coin = gCoin_v;
		}
		if (character == 1 && gNowstage == STAGE_3)
		{
			if (gParts > stage3b.parts) {
				stage3b.parts = gParts;
			}

			if (rank > stage3b.rank) {
				stage3b.rank = rank;
			}
			stage3b.coin = gCoin_b;
		}
		if (character == 2 && gNowstage == STAGE_3)
		{
			if (gParts > stage3v.parts) {
				stage3v.parts = gParts;
			}

			if (rank > stage3v.rank) {
				stage3v.rank = rank;
			}
			 stage3v.coin = gCoin_v;
		}
		if (character == 1 && gNowstage == STAGE_4)
		{
			if (gParts > stage4b.parts) {
				stage4b.parts = gParts;
			}

			if (rank > stage4b.rank) {
				stage4b.rank = rank;
			}
			 stage4b.coin = gCoin_b;
		}
		if (character == 2 && gNowstage == STAGE_4)
		{
			if (gParts > stage4v.parts) {
				stage4v.parts = gParts;
			}

			if (rank > stage4v.rank) {
				stage4v.rank = rank;
			}
			stage4v.coin = gCoin_v;
		}

		StopPlayMem(CheckBgm());
		if (se_button = false)
		{
			PlayMemBack(in_se[CLEAR].handle);
		}
		chara[player].state = PLAYER_STATE_GOAL;
	}
}
void FrameCalcu()//�t���[���v�Z
{
	clearcount = f[GAMEFRAME].frame;
	if (clearcount <= 6000)
	{
		point = 50;
	}
	if ((clearcount >= 6001) && (7200 >= clearcount))
	{
		point = 40;
	}
	if (clearcount >= 7201) {
		point = 30;
	}
}
void ClearRankCalcu()//�����N�v�Z
{
	FrameCalcu();
	rank = point * (1 + 0.2 * gParts);


}


void Suuji(int kazu)//�S�[�����̃J�E���g�\��
{

	if (kazu >= 100) //�J�E���g3����\��
	{
		DrawMemTh(620, 260, cgSuuji[kazu / 100]);//3���̈ʂ�100�̈ʂ�\�� �l�̏����_�ȉ���؂�̂�
		DrawMemTh(660, 260, cgSuuji[kazu / 10 % 10]);//3���̈ʂ�10�̈ʂ�\���@�l��2���ɂ��Ă���ɏ����_�ɂ��ĕ\��
		DrawMemTh(700, 260, cgSuuji[kazu % 10]);//3���̈ʂ�1�̈ʂ�\���@�l�̗]���\��

	}
	else if (kazu >= 10) 		//�J�E���g2���\��
	{
		DrawMemTh(660, 260, cgSuuji[kazu / 10]);
		DrawMemTh(700, 260, cgSuuji[kazu % 10]);
	}
	else //�J�E���g1����\��		
	{
		DrawMemTh(700, 260, cgSuuji[kazu]);
	}

}

void DrawClearRank() {
	SetDrawArea(0, 0, DISP_W, DISP_H);
	DrawMemTh(0, 0, cgClearBg);


	if (f[CLEARRANKFRAME].frame >= 60) {
		DrawMemTh(320, 80, cgRankScreen);
		if (gNowstage == STAGE_1) {
			DrawMemTh(50, 50, cgStage_name1);
		}
		if (gNowstage == STAGE_2) {
			DrawMemTh(50, 50, cgStage_name2);
		}
		if (gNowstage == STAGE_3) {
			DrawMemTh(50, 50, cgStage_name3);
		}
		if (gNowstage == STAGE_4) {
			DrawMemTh(50, 50, cgStage_name4);
		}
	}

	if (f[CLEARRANKFRAME].frame >= 120) {
		Suuji(clearcount / 60);//gFrame�̒l��`��
	}

	if (gParts == 0)
	{//������p�[�c�̕\��
		if (f[CLEARRANKFRAME].frame >= 180)
		{
			DrawMemTh(680, 340, cgSuuji[0]);
		}
	}
	if (gParts == 1)
	{
		if (f[CLEARRANKFRAME].frame >= 180)
		{
			DrawMemTh(680, 340, cgSuuji[1]);
		}
	}

	if (gParts == 2)
	{
		if (f[CLEARRANKFRAME].frame >= 180)
		{
			DrawMemTh(680, 340, cgSuuji[2]);
		}
	}
	if (gParts == 3)
	{

		if (f[CLEARRANKFRAME].frame >= 180)
		{
			DrawMemTh(680, 340, cgSuuji[3]);
		}
	}
	if (gParts == 4)
	{
		if (f[CLEARRANKFRAME].frame >= 180)
		{
			DrawMemTh(680, 340, cgSuuji[4]);
		}
	}
	if (gParts == 5)
	{

		if (f[CLEARRANKFRAME].frame >= 180)
		{
			DrawMemTh(680, 340, cgSuuji[5]);
		}
	}
	if (rank >= srank)
	{
		if (f[CLEARRANKFRAME].frame >= 240)
		{
			DrawMemTh(630, 460, cgSrank);
		}
	}
	if ((srank > rank) && (arank <= rank))
	{
		if (f[CLEARRANKFRAME].frame > 240)
		{
			DrawMemTh(630, 460, cgArank);
		}
	}
	if ((arank > rank) && (brank <= rank))
	{
		if (f[CLEARRANKFRAME].frame > 240)
		{
			DrawMemTh(630, 460, cgBrank);
		}

	}
	if (rank < brank)
	{
		if (f[CLEARRANKFRAME].frame > 240)
		{
			DrawMemTh(630, 460, cgCrank);
		}
	}
	if (f[CLEARRANKFRAME].frame > 300)
	{
		if ((f[CLEARRANKFRAME].frame % 60) < 30)
			DrawMemTh(780, 580, cgIcon_a);

	}

}


int ClearRank()//�N���A�����N��ʂֈڍs
{
	f[CLEARRANKFRAME].frame++;
	if (rank >= srank) {
		if (f[CLEARRANKFRAME].frame >= 240 && character == 1) {
			if (voice_button == false) {
				PlayMemBack(voice_rankS_b);
				voice_button = true;
			}
		}
		if (f[CLEARRANKFRAME].frame >= 240 && character == 2) {
			if (voice_button == false) {
				PlayMemBack(voice_rankS_v);
				voice_button = true;
			}
		}
	}
	if ((srank > rank) && (arank <= rank)) {
		if (f[CLEARRANKFRAME].frame >= 240 && character == 1) {
			if (voice_button == false) {
				PlayMemBack(voice_rankA_b);
				voice_button = true;
			}

		}
		if (f[CLEARRANKFRAME].frame >= 240 && character == 2) {
			if (voice_button == false) {
				PlayMemBack(voice_rankA_v);
				voice_button = true;
			}
		}
	}
	if ((arank > rank) && (brank <= rank)) {
		if (f[CLEARRANKFRAME].frame >= 240 && character == 1) {
			if (voice_button == false) {
				PlayMemBack(voice_rankB_b);
				voice_button = true;
			}
		}
		if (f[CLEARRANKFRAME].frame >= 240 && character == 2) {
			if (voice_button == false) {
				PlayMemBack(voice_rankB_v);
				voice_button = true;
			}
		}
	}
	if (rank < brank) {
		if (f[CLEARRANKFRAME].frame >= 240 && character == 1) {
			if (voice_button == false) {
				PlayMemBack(voice_rankC_b);
				voice_button = true;
			}
		}
		if (f[CLEARRANKFRAME].frame >= 240 && character == 2) {
			if (voice_button == false) {
				PlayMemBack(voice_rankC_v);
				voice_button = true;
			}
		}
	}
	if (f[CLEARRANKFRAME].frame >= 300 && gTrg & KEYIN_Z) {
		
		PlayMemBack(seDecide);
		Setumei();
		f[CLEARRANKFRAME].frame = 0;
		gFramecount = 0;
		voice_button = 0;
		if (bgm_button == false)
		{
			PlayMemLoop(bgmStageselect);
		}
		return STATE_STAGESELECT;
	}
	return STATE_CLEARRANK;
}


