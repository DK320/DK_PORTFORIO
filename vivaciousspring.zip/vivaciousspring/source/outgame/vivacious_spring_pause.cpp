#include	<Windows.h>
#include	"../amgame.h"
#include	"../AmHelper.h"
#include	"../system/common.h"
#include	"../ingame/vivacious_spring.h"
#include	"../ingame/vivacious_spring_game.h"
#include	"../system/vivacious_spring_se.h"
#include	"../system/vivacious_spring_bgm.h"
#include	"vivacious_spring_title.h"
#include	"vivacious_spring_selectstage.h"
#include	"../ingame/frame.h"
#include	"vivacious_spring_clear.h"
#include	"game_setting.h"
int cgPause = 0;	//�|�[�Y���
int cgRestart_On = 0;	//�ĊJ
int cgRestart_Off = 0;
int cgRetry_On = 0;	//�Q�[���ɖ߂�
int cgRetry_Off = 0;
int cgGo_to_title_On = 0;	//�Q�[���I��
int cgGo_to_title_Off = 0;


void LoadPause() {
	cgPause = LoadTexture("res/pause_message.png");
	cgRestart_On = LoadTexture("res/restart_on.png");
	cgRestart_Off = LoadTexture("res/restart_off.png");
	cgRetry_On = LoadTexture("res/retry_on.png");
	cgRetry_Off = LoadTexture("res/retry_off.png");
	cgGo_to_title_On = LoadTexture("res/go_to_title_on.png");
	cgGo_to_title_Off = LoadTexture("res/go_to_title_off.png");

}

void DrawPause() {
	SetDrawBright(1000, 1000, 1000);
	SetDrawArea(0, 0, DISP_W, DISP_H);
	DrawMemTh(440, 80, cgPause);
	double cur;
	cur = sin(gFramecount * 2 * PAI / 80) * 10;
	if (cursor == 0) {

		DrawMemTh(240, 150, cgRestart_On);
		DrawMemTh(360, 400, cgRetry_Off);
		DrawMemTh(360, 560, cgGo_to_title_Off);

	}
	if (cursor == 1) {

		DrawMemTh(240, 150, cgRestart_Off);
		DrawMemTh(360, 400, cgRetry_On);
		DrawMemTh(360, 560, cgGo_to_title_Off);

	}
	if (cursor == 2) {

		DrawMemTh(240, 150, cgRestart_Off);
		DrawMemTh(360, 400, cgRetry_Off);
		DrawMemTh(360, 560, cgGo_to_title_On);
	}
	if (gNowstage == STAGE_1) {
		DrawMemTh(0, 40, cgStage_name1);
	}
	if (gNowstage == STAGE_2) {
		DrawMemTh(0, 0, cgStage_name2);
	}
	if (gNowstage == STAGE_3) {
		DrawMemTh(0, 0, cgStage_name3);
	}
	if (gNowstage == STAGE_4) {
		DrawMemTh(0, 0, cgStage_name4);
	}

}
//�|�[�Y��ʏ���
int Pause() {
	gFramecount--;
	g_alpha4 = 0;
	if (gTrg & KEYIN_DOWN) {

		cursor++;
		if (cursor > 2) {
			cursor = 2;
		}
	}
	if (gTrg&KEYIN_UP) {

		cursor--;
		if (cursor < 0) {
			cursor = 0;
		}
	}

	if ((gTrg&KEYIN_Z) && (cursor == 0))//�Q�[���ɖ߂�
	{
		if (se_button == false)
		{
			PlayMemBack(seDecide);
		}
		for (int i = 0; i < CHARACTER_MAX; i++) {
			if (chara[i].type == CHARACTERTYPE_PLAYER_MAN) {
				chara[i].state = temp;
			}
		}
		return STATE_GAME;
	}
	if ((gTrg&KEYIN_Z) && (cursor == 1))//���g���C
	{
		/*StopPlayMem(bgmStage_1);*/
		if (se_button == false)
		{
			PlayMemBack(seBack);
		}
		cursor = 0;
		InitStage();
		gFramecount = 0;

		return STATE_GAME;
	}
	if ((gTrg&KEYIN_Z) && (cursor == 2)) {//�^�C�g���ֈڍs
		StopPlayMem(CheckBgm());
		if (se_button == false)
		{
			PlayMemBack(seBack);
		}
		cursor = 0;
		InitStage();
		f[TITLEFRAME].frame = 0;
		Setumei();
		InitCharCur();
		if (voice_button2 == 1)
		{
			voice_button = 1;
		}
		else if (voice_button2 == 0)
		{
			voice_button = 0;
		}
		if (se_button == false)
		{
			PlayMemBack(seBack);
		}
		return STATE_TITLE;
	}
	return STATE_PAUSE;
}