#include "vivacious_spring_option.h"
#include"../system/common.h"
#include "../amgame.h"
#include "../ingame/vivacious_spring.h"
#include	"../system/vivacious_spring_se.h"
#include	"vivacious_spring_clear.h"
#include	"game_setting.h"
#include	"record.h"
#include	"vivacious_spring_clear.h"
int cgRecordScreen = 0;
//�I�v�V�����̃��R�[�h�Ŏg���ϐ�
//int high_parts_b1 = 0;//�X�e�[�W1
//int high_parts_v1 = 0;
//int high_rank_b1 = 0;
//int high_rank_v1 = 0;
//int high_coin1 = 0;
//int high_parts_b2 = 0;//�X�e�[�W2
//int high_parts_v2 = 0;
//int high_rank_b2 = 0;
//int high_rank_v2
//int high_coin2 = 0;
//int high_parts_b3 = 0;
//int high_parts_v3 = 0;
int cgSuuji2[SUUJI_MAX] = { 0 };

int high_rank_b = 0;
int high_rank_v = 0;
//���R�[�h�\����
//struct HIGH_RECORD
//{
//	int parts;//�ō��p�[�c��
//	int rank;//�ō������N
//	int coin;//�l���R�C��
//};
struct HIGH_RECORD stage1b;//�X�e�[�W1�̃o�l���R�[�h
struct HIGH_RECORD stage1v;//�X�e�[�W1�̃o�l�b�T���R�[�h
struct HIGH_RECORD stage2b;//�X�e�[�W2�̃o�l���R�[�h
struct HIGH_RECORD stage2v;//�X�e�[�W2�̃o�l�b�T���R�[�h
struct HIGH_RECORD stage3b;//�X�e�[�W3�̃o�l���R�[�h
struct HIGH_RECORD stage3v;//�X�e�[�W3�̃o�l�b�T���R�[�h
struct HIGH_RECORD stage4b;//�X�e�[�W4�̃o�l���R�[�h
struct HIGH_RECORD stage4v;//�X�e�[�W4�̃o�l�b�T���R�[�h

void Suujib(int kazu2)//�S�[�����̃J�E���g�\��
{

	if (kazu2 >= 100) //�J�E���g3����\��
	{
		DrawMemTh(620, 260, cgSuuji2[kazu2 / 100]);//3���̈ʂ�100�̈ʂ�\�� �l�̏����_�ȉ���؂�̂�
		DrawMemTh(660, 260, cgSuuji2[kazu2 / 10 % 10]);//3���̈ʂ�10�̈ʂ�\���@�l��2���ɂ��Ă���ɏ����_�ɂ��ĕ\��
		DrawMemTh(700, 260, cgSuuji2[kazu2 % 10]);//3���̈ʂ�1�̈ʂ�\���@�l�̗]���\��

	}
	else if (kazu2 >= 10) 		//�J�E���g2���\��
	{
		DrawMemTh(460, 435, cgSuuji2[kazu2 / 10]);
		DrawMemTh(510, 435, cgSuuji2[kazu2 % 10]);
	}
	else //�J�E���g1����\��		
	{
		DrawMemTh(510, 435, cgSuuji2[kazu2]);
	}

}
void Suujiv(int kazu3)//�S�[�����̃J�E���g�\��
{

	if (kazu3 >= 100) //�J�E���g3����\��
	{
		DrawMemTh(620, 260, cgSuuji2[kazu3 / 100]);//3���̈ʂ�100�̈ʂ�\�� �l�̏����_�ȉ���؂�̂�
		DrawMemTh(660, 260, cgSuuji2[kazu3 / 10 % 10]);//3���̈ʂ�10�̈ʂ�\���@�l��2���ɂ��Ă���ɏ����_�ɂ��ĕ\��
		DrawMemTh(700, 245, cgSuuji2[kazu3 % 10]);//3���̈ʂ�1�̈ʂ�\���@�l�̗]���\��

	}
	else if (kazu3 >= 10) 		//�J�E���g2���\��
	{
		DrawMemTh(460, 555, cgSuuji2[kazu3 / 10]);
		DrawMemTh(510, 555, cgSuuji2[kazu3 % 10]);
	}
	else //�J�E���g1����\��		
	{
		DrawMemTh(510, 555, cgSuuji2[kazu3]);
	}

}



void DrawRecord()
{
	SetDrawArea(0, 0, DISP_W, DISP_H);
	SetDrawBright(1000, 1000, 1000);
	DrawMemTh(240, 280, cgRecordScreen);
	if (cursor == 0)
	{
		if (stage1b.parts == 0)
		{
			DrawMemTh(700, 415, cgSuuji[0]);
		}
		if (stage1b.parts == 1)
		{
			DrawMemTh(700, 415, cgSuuji[1]);
		}
		if (stage1b.parts == 2)
		{
			DrawMemTh(700, 415, cgSuuji[2]);
		}
		if (stage1b.parts == 3)
		{
			DrawMemTh(700, 415, cgSuuji[3]);
		}
		if (stage1b.parts == 4)
		{
			DrawMemTh(700, 415, cgSuuji[4]);
		}
		if (stage1b.parts == 5)
		{
			DrawMemTh(700, 415, cgSuuji[5]);
		}
		if (stage1b.rank == srank)
		{
			DrawMemTh(850, 390, cgSrank);
		}
		if ((srank > stage1b.rank) && (arank <= stage1b.rank))
		{
			DrawMemTh(850, 390, cgArank);
		}
		if ((arank > stage1b.rank) && (brank <= stage1b.rank))
		{
			DrawMemTh(850, 390, cgBrank);
		}
		if (stage1b.rank < brank)
		{
			DrawMemTh(850, 390, cgCrank);
		}
		Suujib(stage1b.coin);//�R�C��
		//�o�l�b�T
		if (stage1v.rank == 0)
		{
			DrawMemTh(700, 535, cgSuuji[0]);
		}
		if (stage1v.rank == 1)
		{
			DrawMemTh(700, 535, cgSuuji[1]);
		}
		if (stage1v.rank == 2)
		{
			DrawMemTh(700, 535, cgSuuji[2]);
		}
		if (stage1v.rank == 3)
		{
			DrawMemTh(700, 535, cgSuuji[3]);
		}
		if (stage1v.rank == 4)
		{
			DrawMemTh(700, 535, cgSuuji[4]);
		}
		if (stage1v.rank == 5)
		{
			DrawMemTh(700, 535, cgSuuji[5]);
		}
		if (stage1v.rank == srank)
		{
			DrawMemTh(850, 510, cgSrank);
		}
		if ((srank > stage1v.rank) && (arank <= stage1v.rank))
		{
			DrawMemTh(850, 510, cgArank);
		}
		if ((arank > stage1v.rank) && (brank <= stage1v.rank))
		{
			DrawMemTh(850, 510, cgBrank);
		}
		if (stage1v.rank < brank)
		{
			DrawMemTh(850, 510, cgCrank);
		}
		Suujiv(stage1v.coin);//�R�C��
	}
	if (cursor == 1)
	{
		if (stage2b.parts == 0)
		{
			DrawMemTh(700, 415, cgSuuji[0]);
		}
		if (stage2b.parts == 1)
		{
			DrawMemTh(700, 415, cgSuuji[1]);
		}
		if (stage2b.parts == 2)
		{
			DrawMemTh(700, 415, cgSuuji[2]);
		}
		if (stage2b.parts == 3)
		{
			DrawMemTh(700, 415, cgSuuji[3]);
		}
		if (stage2b.parts == 4)
		{
			DrawMemTh(700, 415, cgSuuji[4]);
		}
		if (stage2b.parts == 5)
		{
			DrawMemTh(700, 415, cgSuuji[5]);
		}
		if (stage2b.rank == srank)
		{
			DrawMemTh(850, 390, cgSrank);
		}
		if ((srank > stage2b.rank) && (arank <= stage2b.rank))
		{
			DrawMemTh(850, 390, cgArank);
		}
		if ((arank > stage2b.rank) && (brank <= stage2b.rank))
		{
			DrawMemTh(850, 390, cgBrank);
		}
		if (stage2b.rank < brank)
		{
			DrawMemTh(850, 390, cgCrank);
		}
		Suujib(stage2b.coin);//�R�C��
		//�o�l�b�T
		if (stage2v.rank == 0)
		{
			DrawMemTh(700, 535, cgSuuji[0]);
		}
		if (stage2v.rank == 1)
		{
			DrawMemTh(700, 535, cgSuuji[1]);
		}
		if (stage2v.rank == 2)
		{
			DrawMemTh(700, 535, cgSuuji[2]);
		}
		if (stage2v.rank == 3)
		{
			DrawMemTh(700, 535, cgSuuji[3]);
		}
		if (stage2v.rank == 4)
		{
			DrawMemTh(700, 535, cgSuuji[4]);
		}
		if (stage2v.rank == 5)
		{
			DrawMemTh(700, 535, cgSuuji[5]);
		}
		if (stage2v.rank == srank)
		{
			DrawMemTh(850, 510, cgSrank);
		}
		if ((srank > stage2v.rank) && (arank <= stage2v.rank))
		{
			DrawMemTh(850, 510, cgArank);
		}
		if ((arank > stage2v.rank) && (brank <= stage2v.rank))
		{
			DrawMemTh(850, 510, cgBrank);
		}
		if (stage2v.rank < brank)
		{
			DrawMemTh(850, 510, cgCrank);
		}
		Suujiv(stage2v.coin);//�R�C��
	}
	if (cursor == 2)
	{
		if (stage3b.parts == 0)
		{
			DrawMemTh(700, 415, cgSuuji[0]);
		}
		if (stage3b.parts == 1)
		{
			DrawMemTh(700, 415, cgSuuji[1]);
		}
		if (stage3b.parts == 2)
		{
			DrawMemTh(700, 415, cgSuuji[2]);
		}
		if (stage3b.parts == 3)
		{
			DrawMemTh(700, 415, cgSuuji[3]);
		}
		if (stage3b.parts == 4)
		{
			DrawMemTh(700, 415, cgSuuji[4]);
		}
		if (stage3b.parts == 5)
		{
			DrawMemTh(700, 415, cgSuuji[5]);
		}
		if (stage3b.rank == srank)
		{
			DrawMemTh(850, 390, cgSrank);
		}
		if ((srank > stage3b.rank) && (arank <= stage3b.rank))
		{
			DrawMemTh(850, 390, cgArank);
		}
		if ((arank > stage3b.rank) && (brank <= stage3b.rank))
		{
			DrawMemTh(850, 390, cgBrank);
		}
		if (stage3b.rank < brank)
		{
			DrawMemTh(850, 390, cgCrank);
		}
		Suujib(stage3b.coin);//�R�C��
		//�o�l�b�T
		if (stage3v.parts == 0)
		{
			DrawMemTh(700, 535, cgSuuji[0]);
		}
		if (stage3v.parts == 1)
		{
			DrawMemTh(700, 535, cgSuuji[1]);
		}
		if (stage3v.parts == 2)
		{
			DrawMemTh(700, 535, cgSuuji[2]);
		}
		if (stage3v.parts == 3)
		{
			DrawMemTh(700, 535, cgSuuji[3]);
		}
		if (stage3v.parts == 4)
		{
			DrawMemTh(700, 535, cgSuuji[4]);
		}
		if (stage3v.parts == 5)
		{
			DrawMemTh(700, 535, cgSuuji[5]);
		}
		if (stage3v.rank == srank)
		{
			DrawMemTh(850, 510, cgSrank);
		}
		if ((srank > stage3v.rank) && (arank <= stage3v.rank))
		{
			DrawMemTh(850, 510, cgArank);
		}
		if ((arank > stage3v.rank) && (brank <= stage3v.rank))
		{
			DrawMemTh(850, 510, cgBrank);
		}
		if (stage3v.rank < brank)
		{
			DrawMemTh(850, 510, cgCrank);
		}
		Suujiv(stage3v.coin);//�R�C��
	}
	if (cursor == 3)
	{
		if (stage4b.parts == 0)
		{
			DrawMemTh(700, 415, cgSuuji[0]);
		}
		if (stage4b.parts == 1)
		{
			DrawMemTh(700, 415, cgSuuji[1]);
		}
		if (stage4b.parts == 2)
		{
			DrawMemTh(700, 415, cgSuuji[2]);
		}
		if (stage4b.parts == 3)
		{
			DrawMemTh(700, 415, cgSuuji[3]);
		}
		if (stage4b.parts == 4)
		{
			DrawMemTh(700, 415, cgSuuji[4]);
		}
		if (stage4b.parts == 5)
		{
			DrawMemTh(700, 415, cgSuuji[5]);
		}
		if (stage4b.rank == srank)
		{
			DrawMemTh(850, 390, cgSrank);
		}
		if ((srank > stage4b.rank) && (arank <= stage4b.rank))
		{
			DrawMemTh(850, 390, cgArank);
		}
		if ((arank > stage4b.rank) && (brank <= stage4b.rank))
		{
			DrawMemTh(850, 390, cgBrank);
		}
		if (stage4b.rank < brank)
		{
			DrawMemTh(850, 390, cgCrank);
		}
		Suujib(stage4b.coin);//�R�C��
		//�o�l�b�T
		if (stage4v.parts == 0)
		{
			DrawMemTh(700, 535, cgSuuji[0]);
		}
		if (stage4v.parts == 1)
		{
			DrawMemTh(700, 535, cgSuuji[1]);
		}
		if (stage4v.parts == 2)
		{
			DrawMemTh(700, 535, cgSuuji[2]);
		}
		if (stage4v.parts == 3)
		{
			DrawMemTh(700, 535, cgSuuji[3]);
		}
		if (stage4v.parts == 4)
		{
			DrawMemTh(700, 535, cgSuuji[4]);
		}
		if (stage4v.parts == 5)
		{
			DrawMemTh(700, 535, cgSuuji[5]);
		}
		if (stage4v.rank == srank)
		{
			DrawMemTh(850, 510, cgSrank);
		}
		if ((srank > stage4b.rank) && (arank <= stage4b.rank))
		{
			DrawMemTh(850, 510, cgArank);
		}
		if ((arank > stage4b.rank) && (brank <= stage4b.rank))
		{
			DrawMemTh(850, 510, cgBrank);
		}
		if (stage4v.rank < brank)
		{
			DrawMemTh(850, 510, cgCrank);
		}
		Suujiv(stage4v.coin);//�R�C��
	}
}

int Record()
{
	if (gTrg & KEYIN_RIGHT)
	{
		if (se_button == false)
		{
			PlayMemBack(se_move);
		}

		cursor++;
		if (cursor > 3)
		{
			cursor = 3;
		}
	}
	if (gTrg&KEYIN_LEFT)
	{
		if (se_button == false)
		{
			PlayMemBack(se_move);
		}
		cursor--;
		if (cursor < 0)
		{
			cursor = 0;
		}
	}
	if (gTrg&KEYIN_X)
	{
		if (se_button == false)
		{
			PlayMemBack(seBack);
		}
		return STATE_OPTION;
	}
	return STATE_RECORD;
}