
#include"system/common.h"
#include "amgame.h"
#include "vivacious_spring.h"
#include	"system/vivacious_spring_se.h"

#define STORY_STEP1 0
#define STORY_STEP2 1
#define STORY_STEP3 2

extern int gStep;
extern int cgKoma ;
extern int cgKoma2 ;
extern int cgKoma3 ;
extern int cgKoma4;
extern int cgKoma5;
extern int cgManga;
extern int cgMoji;
extern int cgMoji2;

extern int Story1();
extern int Story();
extern void Koma();
extern void DrawStory1();
extern void DrawStory2();
extern void DrawStory3();