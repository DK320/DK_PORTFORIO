

#include "vivacious_spring_title.h"
#include	"../ingame/vivacious_spring.h"
#include	"../system/common.h"
#include	"../ingame/vivacious_spring_bg.h"
#include	<Windows.h>
#include	"../amgame.h"
#include	"../AmHelper.h"
#include	"../ingame/vivacious_spring_player.h"
#include	"../ingame/vivacious_spring_parts.h"
#include	"../ingame/vivacious_spring_game.h"
#include	"../system/vivacious_spring_se.h"
#include	"../system/vivacious_spring_bgm.h"
#include	"vivacious_spring_selectstage.h"
#include	"../ingame/frame.h"
#include	"game_setting.h"

int cgCursor = 0;
int cgCloudS = 0;
int cgCloudM = 0;
int cgCloud_start = 0;
int cgCloud_option = 0;
int cgTitleback = 0;
int cgOptionOn = 0;
int cgOptionOff = 0;
int cgStartOn = 0;
int cgStartOff = 0;
int cgTitle_logo = 0;
int cgCursorss_on = 0;
int cgCursorss_off = 0;
int cursor = 0;


struct SETUMEI//�������\����
{
	int x;
	double y;
	int spd_x;
	int spd_y;
};

struct SETUMEI cloud1;//�Q�[���X�^�[�g����
struct SETUMEI cloud2;
struct SETUMEI cloud3;
struct SETUMEI cloud4;//�I�v�V��������
struct SETUMEI cloud5;
struct SETUMEI cloud6;
struct SETUMEI title;
struct SETUMEI start;
struct SETUMEI option;
struct SETUMEI gameover;

void Setumei()//�摜�̏����ʒu
{

	cloud1.x = 900;
	cloud1.y = 200;

	cloud2.x = 875;
	cloud2.y = 400;

	cloud3.x = 850;
	cloud3.y = 450;

	cloud4.x = 900;
	cloud4.y = 320;

	cloud5.x = 875;
	cloud5.y = 520;

	cloud6.x = 850;
	cloud6.y = 570;

	title.x = 80;
	title.y = -120;
	title.spd_y = 1;

	start.x = 440;
	start.y = 720;
	start.spd_y = 2;

	option.x = 440;
	option.y = 840;
	option.spd_y = 2;

	gameover.x = 0;
	gameover.y = 0;
	gameover.spd_y = 2;



}
struct CURSOR cursor1;
struct CURSOR cursor2;



void DrawTitle()
{

	f[TITLEFRAME].frame++;
	g_alpha4 += 10;//�^�C�g����ʎ��̃t�F�[�h


	SetDrawMode(AMDRAW_NOBLEND, 0);
	DrawMem(0, 0, cgTitleback);
	/*SetDrawBright(g_alpha3, g_alpha3, g_alpha3);*/
	SetDrawMode(AMDRAW_NOBLEND, 0);//�摜�̓����x�̕ύX
	DrawMemTh(title.x, title.y, cgTitle_logo);
	title.y += title.spd_y;//�^�C�g�����S�̏ォ��\��
	if (title.y >= 0)
	{
		title.y = 0;
	}


	SetDrawBright(1000, 1000, 1000);
	SetDrawMode(AMDRAW_NOBLEND, 0);//�摜�̓����x�̕ύX
	DrawMemTh(start.x, start.y, cgStartOff);
	start.y -= start.spd_y;//�Q�[���X�^�[�g�̉�����\��

	if (start.y <= 440)
	{
		start.y = 440;
	}

	SetDrawMode(AMDRAW_NOBLEND, 0);//�摜�̓����x�̕ύX
	DrawMemTh(option.x, option.y, cgOptionOff);

	option.y -= option.spd_y;
	if (option.y <= 560)
	{
		option.y = 560;
	}

	SetDrawBright(1000, 1000, 1000);
	SetDrawMode(AMDRAW_NOBLEND, 0);


	double cur;
	cur = sin(f[TITLEFRAME].frame * 2 * PAI / 100) * 5;
	double cur2;
	cur2 = sin(f[TITLEFRAME].frame  * PAI / 80) * 4;
	//���������Ղ��Ղ����铮�� 100��1�t���[���ł��铮���@2�͏�̐U�ꕝ�H�@PAI�͉��̐U�ꕝ�H
	//if (f[TITLEFRAME].frame >= 400) {
	if (cursor == 0)
	{
		if (start.y == 440)//�X�^�[�g������������W�ɗ�����`��
		{
			SetDrawBright(1000, 1000, 1000);
			DrawMemTh(start.x, start.y, cgStartOn);
			SetDrawBright(300, 300, 300);
			DrawMemTh(option.x, option.y, cgOptionOff);
			SetDrawBright(1000, 1000, 1000);
			DrawMemTh((int)cloud3.x, cloud3.y, cgCloudS);
			DrawMemTh((int)cloud2.x, (int)(cloud2.y + cur2), cgCloudM);
			DrawMemTh((int)cloud1.x, (int)(cloud1.y + cur), cgCloud_start);


		}
	}
	if (cursor == 1)
	{
		if (option.y == 560)
		{
			SetDrawBright(300, 300, 300);
			DrawMemTh(start.x, start.y, cgStartOff);
			SetDrawBright(1000, 1000, 1000);
			DrawMemTh(option.x, option.y, cgOptionOn);
			SetDrawBright(1000, 1000, 1000);
			DrawMemTh((int)cloud6.x, (int)(cloud6.y), cgCloudS);
			DrawMemTh((int)cloud5.x, (int)(cloud5.y + cur2), cgCloudM);
			DrawMemTh((int)cloud4.x, (int)(cloud4.y + cur), cgCloud_option);



		}
	}
	//}
}
int ProcessTitle()
{
	f[TITLEFRAME].frame++;
	rand_voice = rand() % 2;
	int se;
	se = CheckPlayMem(bgmTitle);
	if (se == 0)
	{
		if (bgm_button == false)
		{
			PlayMemLoop(bgmTitle);
		}
	}
	if (title.y == 0)
	{
		if (voice_button == false)
		{
			switch (rand_voice)
			{
			case 0:
				if (rand_voice == 0)
				{
					PlayMemBack(voice_title_b);
					voice_button = true;

				}
				break;
			case 1:
				if (rand_voice == 1)
				{
					PlayMemBack(voice_title_v);
					voice_button = true;

				}
				break;
			}
		}

	}
	if (option.y == 560)
	{
		if (gTrg & KEYIN_DOWN)
		{
			if (se_button == false)
			{
				PlayMemBack(se_move);
			}

			cursor++;
			if (cursor > 1)
			{
				cursor = 1;
			}
		}
		if (gTrg&KEYIN_UP)
		{
			if (se_button == false)
			{
				PlayMemBack(se_move);
			}
			cursor--;
			if (cursor < 0)
			{
				cursor = 0;
			}
		}

		if (gTrg&KEYIN_Z&& cursor == 0)
		{
			StopPlayMem(bgmTitle);
			if (bgm_button == false)
			{
				PlayMemLoop(bgmStageselect);
			}
			if (se_button == false)
			{
				PlayMemBack(seDecide);
			}

			SetDrawBright(g_alpha, g_alpha, g_alpha);
			InitCharCur();
			InitStageCam();
			return STATE_STAGESELECT;

		}


		if (gTrg&KEYIN_Z && cursor == 1)
		{
			cursor = 0;
			StopPlayMem(bgmTitle);
			if (se_button == false)
			{
				PlayMemBack(seDecide);
			}

			return STATE_OPTION;
		}
	}
	return STATE_TITLE;
}