#include "vivacious_spring_option.h"
#include"../system/common.h"
#include "../amgame.h"
#include "../ingame/vivacious_spring.h"
#include	"../system/vivacious_spring_se.h"
#include	"vivacious_spring_title.h"

int cgOption_bgm = 0;
int cgOption_se = 0;
int cgOption_voice = 0;
int cgOption_dot = 0;
int cgSetting_wallpaper = 0;

bool bgm_button = 0;
bool se_button = 0;
bool voice_button = 0;//�^�C�g���A�X�g�[���[�{�C�X(�t���[���ŉ���Ă���j
bool voice_button2 = 0;//���̑��{�C�X



void DrawSettingBg()
{
	SetDrawBright(1000, 1000, 1000);
	DrawMemTh(0, 0, cgSetting_wallpaper);
}

int GameSetting()//�Q�[����SE�ݒ�
{
	if (gTrg&KEYIN_X)
	{
		return STATE_OPTION;
	}

	if (gTrg&KEYIN_UP)
	{
		PlayMemBack(se_move);
		cursor--;
		if (cursor < 0)
		{
			cursor = 0;
		}
	}
	if (gTrg&KEYIN_DOWN)
	{
		
		PlayMemBack(se_move);
		cursor++;
		if (cursor > 2)
		{
			cursor = 2;
		}
	}

	if (gTrg&KEYIN_Z && cursor == 0 && bgm_button == false)
	{
		if (se_button == false)
		{
			PlayMemBack(seDecide);
		}
		bgm_button = true;
	}
	else if (gTrg&KEYIN_Z && cursor == 0 && bgm_button == true)
	{
		if (se_button == false)
		{
			PlayMemBack(seDecide);
		}
		bgm_button = false;
	}
	if (gTrg&KEYIN_Z && cursor == 1 && se_button == false)
	{
		PlayMemBack(seDecide);
		se_button = true;

	}
	else if (gTrg&KEYIN_Z && cursor == 1 && se_button == true)
	{
		se_button = false;
	}
	if (gTrg&KEYIN_Z && cursor == 2 && voice_button2 == false)//&& voice_button2 == false)
	{
		if (se_button == false)
		{
			PlayMemBack(seDecide);
		}
		voice_button = true;
		voice_button2 = true;

	}
	else if (gTrg&KEYIN_Z && cursor == 2 && voice_button2 == true)// && voice_button2 == true)
	{
		if (se_button == false)
		{
			PlayMemBack(seDecide);
		}
		voice_button = false;
		voice_button2 = false;
	}
	return STATE_GAMESETTING;
}



void DrawGameSetting()
{
	if (cursor == 0 && bgm_button == false)
	{
		SetDrawBright(1000, 1000, 1000);
		DrawMemTh(280, 80, cgOption_bgm);
		DrawMemTh(823, 149, cgOption_dot);
		SetDrawBright(350, 350, 350);
		DrawMemTh(280, 280, cgOption_se);
		DrawMemTh(280, 480, cgOption_voice);
	}
	if (cursor == 0 && bgm_button == true)
	{
		SetDrawBright(1000, 1000, 1000);
		DrawMemTh(280, 80, cgOption_bgm);
		DrawMemTh(422, 149, cgOption_dot);
		SetDrawBright(350, 350, 350);
		DrawMemTh(280, 280, cgOption_se);
		DrawMemTh(280, 480, cgOption_voice);

	}
	if (cursor == 1 && se_button == false)
	{
		SetDrawBright(350, 350, 350);
		DrawMemTh(280, 80, cgOption_bgm);
		SetDrawBright(1000, 1000, 1000);
		DrawMemTh(280, 280, cgOption_se);
		DrawMemTh(823, 348, cgOption_dot);
		SetDrawBright(350, 350, 350);
		DrawMemTh(280, 480, cgOption_voice);
	}
	if (cursor == 1 && se_button == true)
	{
		SetDrawBright(350, 350, 350);
		DrawMemTh(280, 80, cgOption_bgm);
		SetDrawBright(1000, 1000, 1000);
		DrawMemTh(280, 280, cgOption_se);
		DrawMemTh(422, 348, cgOption_dot);
		SetDrawBright(350, 350, 350);
		DrawMemTh(280, 480, cgOption_voice);
	}
	if (cursor == 2 && voice_button2 == false)
	{

		SetDrawBright(350, 350, 350);
		DrawMemTh(280, 80, cgOption_bgm);
		DrawMemTh(280, 280, cgOption_se);
		SetDrawBright(1000, 1000, 1000);
		DrawMemTh(280, 480, cgOption_voice);
		DrawMemTh(823, 550, cgOption_dot);

	}
	if (cursor == 2 && voice_button2 == true)
	{
		SetDrawBright(350, 350, 350);
		DrawMemTh(280, 80, cgOption_bgm);
		DrawMemTh(280, 280, cgOption_se);
		SetDrawBright(1000, 1000, 1000);
		DrawMemTh(280, 480, cgOption_voice);
		DrawMemTh(422, 550, cgOption_dot);

	}
}