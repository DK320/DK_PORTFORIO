
#include "story1.h"
#include"../system/common.h"
#include "../amgame.h"
#include "../ingame/vivacious_spring.h"
#include	"../system/vivacious_spring_se.h"
#include "charselect.h"
#include "../ingame/frame.h"
#include "vivacious_spring_clear.h"
#include "game_setting.h"
#include "../system/vivacious_spring_bgm.h"

int cgKoma = 0;
int cgKoma2 = 0;
int cgKoma3 = 0;
int cgKoma4 = 0;
int cgKoma5 = 0;
int cgMoji = 0;
int cgMoji2 = 0;
int cgManga = 0;
int cgStory1 = 0;
int cgStory2 = 0;
int cgStory3 = 0;
int cgStory4 = 0;
int cgStory5 = 0;
int cgStory6 = 0;
int cgStoryBg = 0;
int cgStory_t1 = 0;
int cgStory_t2 = 0;
int cgStory_t3 = 0;
int cgStory_t4 = 0;
int cgStory_t5 = 0;
int cgStory_t6 = 0;
int cgStory_t7 = 0;
int cgStory_t8 = 0;
int cgStory_t9 = 0;
int cgStory_t10 = 0;
int cgStory_t11 = 0;
int cgStory_t12 = 0;

int Exp_size = 0;
int gStep = 0;
struct STORY1//�I�[�v�j���O�X�g�[���[���\����
{
	int x;
	double y;
	int spd_x;
	int spd_y;
};

struct STORY1 moji1;
struct STORY1 moji2;
struct STORY1 moji3;
struct STORY1 moji4;
struct STORY1 moji5;
struct STORY1 moji6;
struct STORY1 moji7;
struct STORY1 koma;
struct STORY1 koma2;
struct STORY1 koma3;
struct STORY1 koma4;
struct STORY1 koma5;
struct STORY1 koma6;

void Koma()
{
	moji1.x = 0;
	moji1.y = 30;
	moji1.spd_y = 1;

	moji2.x = 0;
	moji2.y = 30;
	moji2.spd_y = 1;

	moji3.x = 0;
	moji3.y = 600;

	moji4.y = 0;
	moji4.y = 30;
	moji4.spd_y = 1;

	moji5.x = 0;
	moji5.y = 30;
	moji5.spd_y = 1;

	moji6.x = 0;
	moji6.y = 30;
	moji6.spd_y = 1;

	moji7.x = 0;
	moji7.y = 30;
	moji7.spd_y = 1;

	koma.x = 0;
	koma.y = 20;
	koma.spd_y = 1;

	koma2.x = 0;
	koma2.y = 20;
	koma2.spd_y = 1;

	koma3.x = 0;
	koma3.y = 20;
	koma3.spd_y = 1;

	koma4.x = 0;
	koma4.y = 20;
	koma4.spd_y = 1;

	koma5.x = 0;
	koma5.y = 20;
	koma5.spd_y = 1;

	koma6.x = 0;
	koma6.y = 20;
	koma6.spd_y = 1;
}
void DrawStoryBg()
{
	SetDrawBright(1000, 1000, 1000);
	DrawMemTh(0, 0, cgStoryBg);
}

void DrawStoryBg2()
{
	SetDrawBright(1000, 1000, 1000);
	DrawMemTh(0, 0, cgBlack);
}

int Step1()
{
	if (f[STORYFRAME].frame >= 225)
	{

		f[STORYFRAME].frame = 0;
		g_alpha = 0;
		g_alpha2 = 0;
		g_alpha3 = 0;
		moji1.y = 600;
		moji2.y = 700;
		gStep = STORY_STEP2;

	}
	return STATE_STORY1;
}

int Step2()
{
	if (f[STORYFRAME].frame == 455)
	{
		if (voice_button == false)
		{
			PlayMemBack(voice_story_op6);

		}
	}
	if (f[STORYFRAME].frame >= 575 && koma3.y == 0)
	{
		f[STORYFRAME].frame = 0;
		g_alpha = 0;
		g_alpha2 = 0;
		g_alpha3 = 0;
		gStep = STORY_STEP3;

	}
	return STATE_STORY1;
}

int Step3()
{
	if (f[STORYFRAME].frame >= 325)
	{
		g_alpha = 0;
		g_alpha2 = 0;
		g_alpha3 = 0;
		f[STORYFRAME].frame = 0;
		gStep = STORY_STEP4;

	}
	return STATE_STORY1;
}

int Step4()
{
	if (f[STORYFRAME].frame == 380)
	{
		if (voice_button == false)
		{
			PlayMemBack(voice_story_op10);
		}
	}
	if (f[STORYFRAME].frame >= 580)
	{
		g_alpha = 0;
		g_alpha2 = 0;
		g_alpha3 = 0;
		f[STORYFRAME].frame = 0;
		gStep = STORY_STEP5;

	}
	return STATE_STORY1;
}

int Step5()
{

	if (f[STORYFRAME].frame >= 225 && gTrg & KEYIN_Z)
	{
		g_alpha = 0;
		g_alpha2 = 0;
		g_alpha3 = 0;
		f[STORYFRAME].frame = 0;

		PlayMemLoop(bgmStageselect);
		if (voice_button2 == 1)
		{
			voice_button = 1;
		}
		else if (voice_button2 == 0)
		{
			voice_button = 0;
		}

		return STATE_STAGESELECT;

	}
	return STATE_STORY1;
}

int	Story1()//�I�[�v�j���O�X�g�[���[
{
	f[STORYFRAME].frame++;
	SetDrawArea(0, 0, DISP_W, DISP_H);
	switch (gStep)
	{
	case  STORY_STEP1:
		gStep = STORY_STEP1;
		nowstate = Step1();
		break;
	case STORY_STEP2:
		gStep = STORY_STEP2;
		nowstate = Step2();
		break;
	case STORY_STEP3:
		gStep = STORY_STEP3;
		nowstate = Step3();
		break;
	case STORY_STEP4:
		gStep = STORY_STEP4;
		nowstate = Step4();
		break;
	case STORY_STEP5:
		gStep = STORY_STEP5;
		nowstate = Step5();
		break;
	}
	return nowstate;
}


void InitStory1()//�X�g�[���[1�̏�����
{
	gStep = STORY_STEP1;
	nowstate = Story1();
	//voice_button = 0;
}

void DrawStory1()
{
	g_alpha += 10;
	moji1.y -= moji1.spd_y;
	SetDrawBright(g_alpha, g_alpha, g_alpha);
	DrawMemTh(moji1.x, moji1.y, cgStory_t1);
	if (moji1.y <= 0)
	{
		moji1.y = 0;
	}
	if (f[STORYFRAME].frame >= 105)
	{
		moji2.y -= moji2.spd_y;
		g_alpha2 += 10;
		SetDrawBright(g_alpha2, g_alpha2, g_alpha2);
		DrawMemTh(moji2.x, moji2.y, cgStory_t2);
		if (moji2.y <= 0)
		{
			moji2.y = 0;
		}
	}
}

void DrawStory2()
{
	if (f[STORYFRAME].frame >= 75)
	{
		moji3.y -= moji3.spd_y;
		g_alpha += 10;
		koma.y -= koma.spd_y;
		SetDrawBright(g_alpha, g_alpha, g_alpha);
		DrawMemTh(koma.x, koma.y, cgStory1);
		if (koma.y <= 0)
		{
			koma.y = 0;
		}
		if (koma.y == 0)
		{
			DrawMemTh(moji3.x, moji3.y, cgStory_t3);
		}
	}
	if (f[STORYFRAME].frame >= 265)
	{
		g_alpha2 += 10;
		SetDrawBright(g_alpha2, g_alpha2, g_alpha2);
		koma2.y -= koma2.spd_y;
		DrawMemTh(koma2.x, koma2.y, cgStory2);
		if (koma2.y <= 0)
		{
			koma2.y = 0;
		}
		if (koma2.y == 0)
		{
			DrawMemTh(moji3.x, moji3.y, cgStory_t4);
		}
	}

	if (f[STORYFRAME].frame >= 455)
	{
		moji3.y = 1000;
		g_alpha3 += 10;
		SetDrawBright(g_alpha3, g_alpha3, g_alpha3);
		koma3.y -= koma3.spd_y;
		DrawMemTh(koma3.x, koma3.y, cgStory3);
		if (koma3.y <= 0)
		{
			koma3.y = 0;
		}
		if (koma3.y == 0)
		{
			DrawMemTh(moji1.x, moji1.y, cgStory_t5);
		}
		if (f[STORYFRAME].frame >= 465)
		{
			moji1.y = 1000;
			DrawMemTh(0, 600, cgStory_t6);
		}

	}
}

void DrawStory3()
{
	moji3.y = 600;
	g_alpha += 10;
	moji4.y -= moji4.spd_y;
	SetDrawBright(g_alpha, g_alpha, g_alpha);
	DrawMemTh(moji4.x, moji4.y, cgStory_t7);
	if (moji4.y <= 0)
	{
		moji4.y = 0;
	}
	if (f[STORYFRAME].frame >= 105)
	{
		g_alpha2 += 10;
		moji5.y -= moji5.spd_y;
		SetDrawBright(g_alpha2, g_alpha2, g_alpha2);
		DrawMemTh(moji5.x, moji5.y, cgStory_t8);
		if (moji5.y <= 0)
		{
			moji5.y = 0;
		}
	}
}

void DrawStory4()
{
	if (f[STORYFRAME].frame >= 75)
	{
		moji4.y = 600;
		g_alpha += 10;
		koma5.y -= koma5.spd_y;
		SetDrawBright(g_alpha, g_alpha, g_alpha);
		DrawMemTh(koma5.x, koma5.y, cgStory5);
		if (koma5.y <= 0)
		{
			koma5.y = 0;
		}
		if (koma5.y == 0)
		{
			DrawMemTh(moji3.x, moji3.y, cgStory_t9);
		}
	}
	if (f[STORYFRAME].frame >= 295)
	{
		g_alpha3 += 10;
		koma6.y -= koma6.spd_y;
		SetDrawBright(g_alpha3, g_alpha3, g_alpha3);
		DrawMemTh(koma6.x, koma6.y, cgStory6);
		if (koma6.y <= 0)
		{
			koma6.y = 0;
		}

		if (Exp_size >= 0)
		{
			Exp_size += 2;
		}
		if (Exp_size >= 100)
		{
			Exp_size = 100;
		}
		if (f[STORYFRAME].frame >= 340)
		{
			DrawMemThExp(koma6.x - Exp_size, koma6.y - Exp_size,
				1400 + Exp_size, 500 + Exp_size, cgStory6);
		}
		if (f[STORYFRAME].frame >= 390)
		{
			moji3.y = 1000;
			DrawMemTh(moji4.x, moji4.y, cgStory_t10);
		}
	}
}
void DrawStory5()
{

	g_alpha += 10;
	moji6.y -= moji6.spd_y;
	SetDrawBright(g_alpha, g_alpha, g_alpha);
	DrawMemTh(moji6.x, moji6.y, cgStory_t11);
	if (moji6.y <= 0)
	{
		moji6.y = 0;
	}
	if (f[STORYFRAME].frame >= 105)
	{
		moji7.y -= moji7.spd_y;
		g_alpha2 += 10;
		SetDrawBright(g_alpha2, g_alpha2, g_alpha2);
		DrawMemTh(moji7.x, moji7.y, cgStory_t12);
		if (moji7.y <= 0)
		{
			moji7.y = 0;
		}
	}
}

