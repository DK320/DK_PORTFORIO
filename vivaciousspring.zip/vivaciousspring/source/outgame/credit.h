#pragma once

#include"../system/common.h"
#include "../amgame.h"
#include "../ingame/vivacious_spring.h"
#include	"../system/vivacious_spring_se.h"
#include "story2.h"

extern int MoveCredit();
extern void Credit();
extern void DrawCredit();
extern int cgCredit;
extern int credit_count;