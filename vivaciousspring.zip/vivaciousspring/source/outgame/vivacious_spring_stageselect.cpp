#include	<Windows.h>
#include "vivacious_spring_option.h"
#include "../ingame/vivacious_spring.h"
#include "../amgame.h"
#include "../AmHelper.h"
#include "vivacious_spring_selectstage.h"
#include	"../system/common.h"
#include	"../system/vivacious_spring_se.h"
#include	"../ingame/vivacious_spring_game.h"
#include	"../system/vivacious_spring_bgm.h"
#include	"vivacious_spring_title.h"
#include	"../system/easing.h"
#include "vivacious_spring_clear.h"
#include "story1.h"
#include "story2.h"
#include	"../ingame/vivacious_spring_camera.h"
#include	"../ingame/frame.h"
#include	"game_setting.h"
#include	"record.h"

struct CAMERA cam;

struct CURSOR cursor5;
struct CURSOR cursor6;
struct CURSOR cursor7;
struct CURSOR cursor8;
struct CURSOR cursor9;
struct CURSOR cursor10;

//int cgSelectStage = 0;//�X�e�[�W�I�����


//int begin_frame;//�J�[�\���ړ��̊J�n����
//int life_time = 60 * 1;//�J�[�\���ړ��ɂ����鎞��

int move_x = 0;
int move_y = 0;

int curcount = 0;
int  cgWallPaper = 0;
int cgRoad = 0;
int cgClearRank = 0; //�N���A�����N���
int cgCloud_stage1 = 0;//�X�e�[�W����
int cgCloud_stage2 = 0;
int cgCloud_stage3 = 0;
int cgCloud_stage4 = 0;
int cgCloud_stage5 = 0;
int cgCloud_opening = 0;
int cgCloud_ending = 0;
int cgCoin_Collect = 0;


//struct SELECTSTAGE
//{
//	int x;
//	int y;
//	int spd_x;
//	int spd_y;
//};
enum AREA
{
	AREA1,
	AREA2,
};

struct SELECTSTAGE stagemap;
struct SELECTSTAGE map0;
struct SELECTSTAGE map1;
struct SELECTSTAGE map2;
struct SELECTSTAGE map3;
struct SELECTSTAGE map4;
struct SELECTSTAGE map5;

void StageMap()
{
	stagemap.x = 0;
	stagemap.y = 0;
	stagemap.spd_x = 10;

	cam.view_x = 0;
	cam.view_y = 0;

	map0.x = 160;
	map0.y = 313;

	map1.x = 316;
	map1.y = 446;

	map2.x = 748;
	map2.y = 428;


	map3.x = 1376;
	map3.y = 492;


	map4.x = 1680;
	map4.y = 468;

	map5.x = 2274;
	map5.y = 408;
}
void InitStageCam()
{
	cam.view_x = 0;
}

void InitCharCur()
{
	cursor = 0;
	cam.state = AREA1;
}
void Suujib_coin(int kazu2)//�S�[�����̃J�E���g�\��
{

	if (kazu2 >= 100) //�J�E���g3����\��
	{
		DrawMemTh(20, 10, cgSuuji2[kazu2 / 100]);//3���̈ʂ�100�̈ʂ�\�� �l�̏����_�ȉ���؂�̂�
		DrawMemTh(70, 10, cgSuuji2[kazu2 / 10 % 10]);//3���̈ʂ�10�̈ʂ�\���@�l��2���ɂ��Ă���ɏ����_�ɂ��ĕ\��
		DrawMemTh(120, 10, cgSuuji2[kazu2 % 10]);//3���̈ʂ�1�̈ʂ�\���@�l�̗]���\��

	}
	else if (kazu2 >= 10) 		//�J�E���g2���\��
	{
		DrawMemTh(70, 10, cgSuuji2[kazu2 / 10]);
		DrawMemTh(120, 10, cgSuuji2[kazu2 % 10]);
	}
	else //�J�E���g1����\��		
	{
		DrawMemTh(120, 10, cgSuuji2[kazu2]);
	}

}
void Suujiv_coin(int kazu3)//�S�[�����̃J�E���g�\��
{

	if (kazu3 >= 100) //�J�E���g3����\��
	{
		DrawMemTh(20, 10, cgSuuji2[kazu3 / 100]);//3���̈ʂ�100�̈ʂ�\�� �l�̏����_�ȉ���؂�̂�
		DrawMemTh(70, 10, cgSuuji2[kazu3 / 10 % 10]);//3���̈ʂ�10�̈ʂ�\���@�l��2���ɂ��Ă���ɏ����_�ɂ��ĕ\��
		DrawMemTh(120, 10, cgSuuji2[kazu3 % 10]);//3���̈ʂ�1�̈ʂ�\���@�l�̗]���\��

	}
	else if (kazu3 >= 10) 		//�J�E���g2���\��
	{
		DrawMemTh(70, 10, cgSuuji2[kazu3 / 10]);
		DrawMemTh(120, 10, cgSuuji2[kazu3 % 10]);
	}
	else //�J�E���g1����\��		
	{
		DrawMemTh(120, 10, cgSuuji2[kazu3]);
	}

}


void stageprocess()
{

	if (gamecount == 0)//�X�e�[�W�ړ��̐���
	{
		cursor = 0;
	}

	if (cursor < 1 && gamecount == 1)
	{
		//cursor = 1;
		cursor++;
	}

	if (cursor < 2 && gamecount == 2)
	{
		//cursor = 2;
		cursor++;
	}

	if (cursor < 3 && gamecount == 3)
	{
		//cursor = 3;
		cursor++;
	}

	if (cursor < 4 && gamecount == 4)
	{
		//cursor = 4;
		cursor++;
	}

	if (cursor < 5 && gamecount == 5)
	{
		//cursor = 5;
		cursor++;
	}
}





void StageselectCameraMove()
{

	switch (cursor)
	{
	case 0:
		if (cam.view_x < map0.x + 80 - (DISP_W / 2))
		{
			cam.view_x += 20;
		}
		if (cam.view_x > map0.x + 80 - (DISP_W / 2))
		{
			cam.view_x -= 20;
		}
		/*cam.view_x = map0.x+80 - (DISP_W/2);*/
		break;
	case 1:
		if (cam.view_x < map1.x + 80 - (DISP_W / 2))
		{
			cam.view_x += 20;
		}
		if (cam.view_x > map1.x + 80 - (DISP_W / 2))
		{
			cam.view_x -= 20;
		}
		/*	cam.view_x = map1.x + 80 - (DISP_W / 2);*/
		break;
	case 2:
		if (cam.view_x < map2.x + 80 - (DISP_W / 2))
		{
			cam.view_x += 20;
		}
		if (cam.view_x > map2.x + 80 - (DISP_W / 2))
		{
			cam.view_x -= 20;
		}
		/*cam.view_x = map2.x + 80 - (DISP_W / 2);*/
		break;
	case 3:
		if (cam.view_x < map3.x + 80 - (DISP_W / 2))
		{
			cam.view_x += 20;
		}
		if (cam.view_x > map3.x + 80 - (DISP_W / 2))
		{
			cam.view_x -= 20;
		}
		/*cam.view_x = map3.x + 80 - (DISP_W / 2);*/
		break;
	case 4:
		if (cam.view_x < map4.x + 80 - (DISP_W / 2))
		{
			cam.view_x += 20;
		}
		if (cam.view_x > map4.x + 80 - (DISP_W / 2))
		{
			cam.view_x -= 20;
		}
		/*	cam.view_x = map4.x + 80 - (DISP_W / 2);*/
		break;
	case 5:
		if (cam.view_x < map5.x + 80 - (DISP_W / 2))
		{
			cam.view_x += 20;
		}
		if (cam.view_x > map5.x + 80 - (DISP_W / 2))
		{
			cam.view_x -= 20;
		}
		/*cam.view_x = map5.x + 80 - (DISP_W / 2);*/
		break;
	}
	if (cam.view_x < 0)
	{
		cam.view_x = 0;
	}
	if (cam.view_x > 2560 - DISP_W)
	{
		cam.view_x = 2560 - DISP_W;
	}

}
int StartStage()
{
	//MoveCamF();
	f[STAGESELECTFRAME].frame++;
	if (gTrg&KEYIN_RIGHT)//�X�e�[�W�I�����̃L�����ړ�(�E�ړ��j
	{
		/*cursor++;*/
		stageprocess();
		//�X�e�[�W�E�ړ�
		if (se_button == false)
		{
			PlayMemBack(se_move);
		}

		/*	if (cursor == 3 && cam.view_x == 0)
			{
				cam.view_x -= 1280;
				cam.state = AREA2;*/
				//}
				/*if (cursor == 3)
				{
					MoveCamF();
				}*/
		if (cursor > 5)
		{
			cursor = 5;
		}
	}

	if (gTrg &KEYIN_LEFT)//�X�e�[�W�I�����̃L�����ړ�(���ړ�)
	{
		cursor--;
		//�X�e�[�W���ړ�
		if (se_button == false)
		{
			PlayMemBack(se_move);
		}
		if (cursor < 0)
		{
			cursor = 0;
		}
	}
	StageselectCameraMove();
	if (gTrg&KEYIN_Z && cursor == 0)
	{
		StopPlayMem(bgmStageselect);
		if (se_button == false)
		{
			PlayMemBack(seDecide);
		}

		count = 0;
		InitCursor();
		InitCharCur();
		Koma();
		InitStory1();
		if (voice_button2 == 1)
		{
			voice_button = 1;
		}
		else if (voice_button2 == 0)
		{
			voice_button = 0;
		}


		return STATE_STORY1;
	}
	if (gTrg&KEYIN_Z && cursor == 1 && gamecount >= 1)
	{
		StopPlayMem(bgmStageselect);
		if (se_button == false)
		{
			PlayMemBack(seDecide);
		}

		if (voice_button2 == 1)
		{
			voice_button = 0;
		}
		else if (voice_button2 == 0)
		{
			voice_button = 1;
		}
		gNowstage = STAGE_1;
		InitCursor();
		InitCharCur();
		return STATE_CHARSELECT;
	}
	if (gTrg&KEYIN_Z && cursor == 2 && gamecount >= 2)
	{
		StopPlayMem(bgmStageselect);
		if (se_button == false)
		{
			PlayMemBack(seDecide);
		}


		if (voice_button2 == 1)
		{
			voice_button = 1;
		}
		else if (voice_button2 == 0)
		{
			voice_button = 0;
		}

		gNowstage = STAGE_2;
		InitCursor();
		InitCharCur();
		return STATE_CHARSELECT;
	}
	if (gTrg&KEYIN_Z && cursor == 3 && gamecount >= 3)
	{
		StopPlayMem(bgmStageselect);
		if (se_button == false)
		{
			PlayMemBack(seDecide);
		}
		if (voice_button2 == 1)
		{
			voice_button = 1;
		}
		else if (voice_button2 == 0)
		{
			voice_button = 0;
		}


		gNowstage = STAGE_3;
		InitCursor();
		InitCharCur();
		return STATE_CHARSELECT;
	}
	if (gTrg&KEYIN_Z && cursor == 4 && gamecount >= 4)
	{
		StopPlayMem(bgmStageselect);
		if (se_button == false)
		{
			PlayMemBack(seDecide);
		}
		if (voice_button2 == 1)
		{
			voice_button = 1;
		}
		else if (voice_button2 == 0)
		{
			voice_button = 0;
		}

		gNowstage = STAGE_4;
		InitCursor();
		InitCharCur();
		return STATE_CHARSELECT;
	}
	if (gTrg&KEYIN_Z && cursor == 5 && gamecount >= 5)
	{
		StopPlayMem(bgmStageselect);
		if (se_button == false)
		{
			PlayMemBack(seDecide);
		}
		if (voice_button2 == 1)
		{
			voice_button = 1;
		}
		else if (voice_button2 == 0)
		{
			voice_button = 0;
		}

		InitCursor();
		/*InitStage();*/
		InitStory2();
		Koma2();
		return STATE_STORY2;
	}
	if (gTrg&KEYIN_X)
	{
		StopPlayMem(bgmStageselect);
		Setumei();
		cursor = 0;
		if (se_button == false)
		{
			PlayMemBack(seBack);
		}

		if (voice_button2 == 1)
		{
			voice_button = 1;
		}
		else if (voice_button2 == 0)
		{
			voice_button = 0;
		}
		return STATE_TITLE;
	}

	return STATE_STAGESELECT;
}


void DrawSelect()
{
	SetDrawBright(1000, 1000, 1000);
	double cur;
	cur = sin(f[STAGESELECTFRAME].frame * 2 * PAI / 100) * 5;
	double cur2;
	cur2 = sin(f[STAGESELECTFRAME].frame  * PAI / 80) * 4;
	DrawMemTh(0 - cam.view_x, 0, cgWallPaper);
	DrawMemTh(0 - cam.view_x, 0, cgRoad);
	DrawMemTh(0, 0, cgCoin_Collect);
	if (clear_v_up == 0)
	{
		Suujib_coin(stage1b.coin + stage2b.coin + stage3b.coin + stage4b.coin);
	}
	if (clear_v_up == 1)
	{
		Suujiv_coin(stage1v.coin + stage2v.coin + stage3v.coin + stage4v.coin);
	}
	switch (cam.state)
	{
	case AREA1:
		DrawMemTh(map0.x - cam.view_x, map0.y, cgCursorss_off);
		DrawMemTh(map1.x - cam.view_x, map1.y, cgCursorss_off);
		DrawMemTh(map2.x - cam.view_x, map2.y, cgCursorss_off);
		DrawMemTh(map3.x - cam.view_x, map3.y, cgCursorss_off);
		DrawMemTh(map4.x - cam.view_x, map4.y, cgCursorss_off);
		DrawMemTh(map5.x - cam.view_x, map5.y, cgCursorss_off);

		break;
	case AREA2:
		break;
	}

	switch (cursor)
	{
	case 0:
		DrawMemTh(map0.x - cam.view_x, map0.y, cgCursorss_on);
		DrawMemTh(300, 270, cgCloudS);
		DrawMemTh(325, (int)(220 + cur2), cgCloudM);
		DrawMemTh(350, (int)(20 + cur), cgCloud_opening);
		break;
	case 1:
		DrawMemTh(map1.x - cam.view_x, map1.y, cgCursorss_on);
		DrawMemTh(460, 400, cgCloudS);
		DrawMemTh(485, (int)(350 + cur2), cgCloudM);
		DrawMemTh(510, (int)(150 + cur), cgCloud_stage1);
		if (clear_v_up == 0)
		{
			if (stage1b.rank == srank)
			{
				DrawMemTh(720, (int)(300 + cur), cgSrank);
			}
			if ((srank > stage1b.rank) && (arank <= stage1b.rank))
			{
				DrawMemTh(720, (int)(300 + cur), cgArank);
			}
			if ((arank > stage1b.rank) && (brank <= stage1b.rank))
			{
				DrawMemTh(720, (int)(300 + cur), cgBrank);
			}
			if (stage1b.rank < brank)
			{
				DrawMemTh(720, (int)(300 + cur), cgCrank);
			}
		}
		if (clear_v_up == 1)
		{
			if (stage1v.rank == srank)
			{
				DrawMemTh(720, (int)(300 + cur), cgSrank);
			}
			if ((srank > stage1v.rank) && (arank <= stage1v.rank))
			{
				DrawMemTh(720, (int)(300 + cur), cgArank);
			}
			if ((arank > stage1v.rank) && (brank <= stage1v.rank))
			{
				DrawMemTh(720, (int)(300 + cur), cgBrank);
			}
			if (stage1v.rank < brank)
			{
				DrawMemTh(720, (int)(300 + cur), cgCrank);
			}
		}
		break;
	case 2:
		DrawMemTh(map2.x - cam.view_x, map2.y, cgCursorss_on);
		if (map2.x - cam.view_x >= (DISP_W - 160) / 2)
		{
			DrawMemTh(700, 380, cgCloudS);
			DrawMemTh(725, (int)(330 + cur2), cgCloudM);
			DrawMemTh(750, (int)(140 + cur), cgCloud_stage2);
			if (clear_v_up == 0)
			{
				if (stage2b.rank == srank)
				{
					DrawMemTh(975, (int)(290 + cur), cgSrank);
				}
				if ((srank > stage2b.rank) && (arank <= stage2b.rank))
				{
					DrawMemTh(975, (int)(290 + cur), cgArank);
				}
				if ((arank > stage2b.rank) && (brank <= stage2b.rank))
				{
					DrawMemTh(975, (int)(290 + cur), cgBrank);
				}
				if (stage2b.rank < brank)
				{
					DrawMemTh(975, (int)(290 + cur), cgCrank);
				}
			}
			if (clear_v_up == 1)
			{
				if (stage2v.rank == srank)
				{
					DrawMemTh(975, (int)(290 + cur), cgSrank);
				}
				if ((srank > stage2v.rank) && (arank <= stage2v.rank))
				{
					DrawMemTh(975, (int)(290 + cur), cgArank);
				}
				if ((arank > stage2v.rank) && (brank <= stage2v.rank))
				{
					DrawMemTh(975, (int)(290 + cur), cgBrank);
				}
				if (stage2v.rank < brank)
				{
					DrawMemTh(975, (int)(290 + cur), cgCrank);
				}
			}
		}
		break;
	case 3:
		DrawMemTh(map3.x - cam.view_x, map3.y, cgCursorss_on);
		if (map3.x - cam.view_x >= (DISP_W - 160) / 2)
		{
			DrawMemTh(1525 - cam.view_x, 460, cgCloudS);
			DrawMemTh(1550 - cam.view_x, (int)(410 + cur2), cgCloudM);
			DrawMemTh(1575 - cam.view_x, (int)(210 + cur), cgCloud_stage3);
			if (clear_v_up == 0)
			{
				if (stage3b.rank == srank)
				{
					DrawMemTh(1790 - cam.view_x, (int)(350 + cur), cgSrank);
				}
				if ((srank > stage3b.rank) && (arank <= stage3b.rank))
				{
					DrawMemTh(1790 - cam.view_x, (int)(350 + cur), cgArank);
				}
				if (stage3b.rank == brank)
				{
					DrawMemTh(1790 - cam.view_x, (int)(350 + cur), cgBrank);
				}
				if (stage3b.rank < brank)
				{
					DrawMemTh(1790 - cam.view_x, (int)(350 + cur), cgCrank);
				}
			}
			if (clear_v_up == 1)
			{
				if (stage3v.rank == srank)
				{
					DrawMemTh(1790 - cam.view_x, (int)(350 + cur), cgSrank);
				}
				if ((srank > stage3v.rank) && (arank <= stage3v.rank))
				{
					DrawMemTh(1790 - cam.view_x, (int)(350 + cur), cgArank);
				}
				if ((arank > stage3v.rank) && (brank <= stage3v.rank))
				{
					DrawMemTh(1790 - cam.view_x, (int)(350 + cur), cgBrank);
				}
				if (stage3v.rank == crank)
				{
					DrawMemTh(1790 - cam.view_x, (int)(350 + cur), cgCrank);
				}
			}
		}
		break;
	case 4:
		DrawMemTh(map4.x - cam.view_x, map4.y, cgCursorss_on);
		DrawMemTh(1830 - cam.view_x, 435, cgCloudS);
		DrawMemTh(1855 - cam.view_x, (int)(385 + cur2), cgCloudM);
		DrawMemTh(1880 - cam.view_x, (int)(185 + cur), cgCloud_stage4);
		if (clear_v_up == 0)
		{
			if (stage4b.rank == srank)
			{
				DrawMemTh(2085 - cam.view_x, (int)(350 + cur), cgSrank);
			}
			if ((srank > stage4b.rank) && (arank <= stage4b.rank))
			{
				DrawMemTh(2085 - cam.view_x, (int)(350 + cur), cgArank);
			}
			if ((arank > stage4b.rank) && (brank <= stage4b.rank))
			{
				DrawMemTh(2085 - cam.view_x, (int)(350 + cur), cgBrank);
			}
			if (stage4b.rank == crank)
			{
				DrawMemTh(2085 - cam.view_x, (int)(350 + cur), cgCrank);
			}
		}
		if (clear_v_up == 1)
		{
			if (stage4v.rank == srank)
			{
				DrawMemTh(2085 - cam.view_x, (int)(350 + cur), cgSrank);
			}
			if ((srank > stage4v.rank) && (arank <= stage4v.rank))
			{
				DrawMemTh(2085 - cam.view_x, (int)(350 + cur), cgArank);
			}
			if ((arank > stage4v.rank) && (brank <= stage4v.rank))
			{
				DrawMemTh(2085 - cam.view_x, (int)(350 + cur), cgBrank);
			}
			if (stage4v.rank < brank)
			{
				DrawMemTh(2085 - cam.view_x, (int)(350 + cur), cgCrank);
			}

			break;
	case 5:
		DrawMemTh(map5.x - cam.view_x, map5.y, cgCursorss_on);
		DrawMemTh(2230 - cam.view_x, 370, cgCloudS);
		DrawMemTh(2180 - cam.view_x, (int)(320 + cur2), cgCloudM);
		DrawMemTh(1920 - cam.view_x, (int)(100 + cur), cgCloud_ending);
		break;
		}
	}
}