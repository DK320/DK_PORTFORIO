#include	"../amgame.h"
#include	"../AmHelper.h"
#include "story1.h"
#include "story2.h"
#include"../system/common.h"
#include "../ingame/vivacious_spring.h"
#include	"../system/vivacious_spring_se.h"
#include "charselect.h"
#include "../ingame/frame.h"
#include "vivacious_spring_clear.h"
#include	"credit.h"
#include	"game_setting.h"
int clear_v_up = 0;

int cgStory7 = 0;
int cgStory8 = 0;
int cgStory9 = 0;
int cgStory10 = 0;
int cgStory11 = 0;
int cgStory12 = 0;

int cgStory_t13 = 0;
int cgStory_t14 = 0;
int cgStory_t15 = 0;
int cgStory_t16 = 0;
int cgStory_t17 = 0;
int cgStory_t18 = 0;
int cgStory_t19 = 0;
int cgStory_t20 = 0;
int cgStory_t21 = 0;
int cgStory_t22 = 0;
int cgStory_t23 = 0;
int cgStory_t24 = 0;
int cgStory_t25 = 0;
int cgStory_t26 = 0;
int cgStory_t27 = 0;
int cgStory_t28 = 0;
int cgStory_t29 = 0;
int cgStory_t30 = 0;
int cgStory_t31 = 0;
int cgStory_t32 = 0;
int cgStory_t33 = 0;
int cgStory_t34 = 0;

struct STORY2 //�G���f�B���O�X�g�[���[���\����
{
	int x;
	double y;
	int spd_x;
	int spd_y;
};
struct STORY2 moji8;
struct STORY2 moji9;
struct STORY2 moji10;
struct STORY2 moji11;
struct STORY2 moji12;
struct STORY2 moji13;
struct STORY2 moji14;
struct STORY2 moji15;
struct STORY2 koma7;
struct STORY2 koma8;
struct STORY2 koma9;
struct STORY2 koma10;
struct STORY2 koma11;
struct STORY2 koma12;


void Koma2()
{
	moji8.x = 0;
	moji8.y = 30;
	moji8.spd_y = 1;

	moji9.x = 0;
	moji9.y = 30;
	moji9.spd_y = 1;

	moji10.x = 0;
	moji10.y = 30;
	moji10.spd_y = 1;

	moji11.x = 0;
	moji11.y = 600;

	moji12.x = 0;
	moji12.y = 600;

	moji13.y = 600;

	moji14.y = 30;
	moji14.spd_y = 1;

	moji15.y = 30;
	moji14.spd_y = 1;

	koma7.x = 0;
	koma7.y = 20;
	koma7.spd_y = 5;

	koma8.x = 0;
	koma8.y = 20;
	koma8.spd_y = 8;

	koma9.x = 0;
	koma9.y = 20;
	koma9.spd_y = 5;

	koma10.x = 0;
	koma10.y = 20;
	koma10.spd_y = 5;

	koma11.x = 0;
	koma11.y = 20;
	koma11.spd_y = 5;

	koma12.x = 0;
	koma12.y = 20;
	koma12.spd_y = 5;
}

int Step6()
{
	if (f[STORYFRAME].frame >= 360)
	{

		f[STORYFRAME].frame = 0;
		g_alpha = 0;
		g_alpha2 = 0;
		g_alpha3 = 0;
		gStep = STORY_STEP7;


	}
	return STATE_STORY2;
}

int Step7()
{
	if (f[STORYFRAME].frame == 90)
	{
		if (voice_button == false)
		{
			PlayMemBack(voice_story_ed4);
		}
	}
	if (f[STORYFRAME].frame >= 515)
	{
		f[STORYFRAME].frame = 0;
		g_alpha = 0;
		g_alpha2 = 0;
		g_alpha3 = 0;
		gStep = STORY_STEP8;
	}
	return STATE_STORY2;
}

int Step8()
{
	if (f[STORYFRAME].frame == 80)
	{
		if (voice_button == false)
		{
			PlayMemBack(voice_story_ed8);

		}
	}

	if (f[STORYFRAME].frame >= 555)
	{
		f[STORYFRAME].frame = 0;
		g_alpha = 0;
		g_alpha2 = 0;
		g_alpha3 = 0;
		moji13.y = 600;
		gStep = STORY_STEP9;
	}
	return STATE_STORY2;
}
int Step9()
{
	if (f[STORYFRAME].frame == 80)
	{
		if (voice_button == false)
		{
			PlayMemBack(voice_story_ed12);

		}
	}
	if (f[STORYFRAME].frame >= 690)
	{
		f[STORYFRAME].frame = 0;
		g_alpha = 0;
		g_alpha2 = 0;
		g_alpha3 = 0;
		moji13.y = 600;
		gStep = STORY_STEP10;
	}
	return STATE_STORY2;
}

int Step10()
{
	if (f[STORYFRAME].frame >= 400)
	{
		f[STORYFRAME].frame = 0;
		g_alpha = 0;
		g_alpha2 = 0;
		g_alpha3 = 0;
		moji9.y = 600;
		moji10.y = 600;
		moji11.y = 600;
		moji12.y = 600;
		moji13.y = 600;
		gStep = STORY_STEP11;
	}
	return STATE_STORY2;
}

int Step11()
{
	if (f[STORYFRAME].frame == 80)
	{
		if (voice_button == false)
		{
			PlayMemBack(voice_story_ed15);
		}
	}
	if (f[STORYFRAME].frame == 460)
	{
		if (voice_button == false)
		{
			PlayMemBack(voice_story_ed16);
		}
	}
	if (f[STORYFRAME].frame >= 1415)
	{
		f[STORYFRAME].frame = 0;
		g_alpha = 0;
		g_alpha2 = 0;
		g_alpha3 = 0;
		moji9.y = 600;
		moji10.y = 600;
		moji11.y = 600;
		moji12.y = 600;
		moji13.y = 600;
		gStep = STORY_STEP12;
	}
	return STATE_STORY2;

}

int Step12()
{
	if (f[STORYFRAME].frame >= 245 && gTrg & KEYIN_Z)
	{
		f[STORYFRAME].frame = 0;
		SetDrawBright(1000, 1000, 1000);
		clear_v_up = 1;
		Credit();
		return STATE_CREDIT;
	}
	return STATE_STORY2;
}


int	Story2()//�G���f�B���O�X�g�[���[
{
	f[STORYFRAME].frame++;
	SetDrawArea(0, 0, DISP_W, DISP_H);
	switch (gStep)
	{
	case  STORY_STEP6:
		gStep = STORY_STEP6;
		nowstate = Step6();
		break;
	case STORY_STEP7:
		gStep = STORY_STEP7;
		nowstate = Step7();
		break;
	case STORY_STEP8:
		gStep = STORY_STEP8;
		nowstate = Step8();
		break;
	case STORY_STEP9:
		gStep = STORY_STEP9;
		nowstate = Step9();
		//Credit();
		break;
	case STORY_STEP10:
		gStep = STORY_STEP10;
		nowstate = Step10();
		break;
	case STORY_STEP11:
		gStep = STORY_STEP11;
		nowstate = Step11();
		break;
	case STORY_STEP12:
		gStep = STORY_STEP12;
		nowstate = Step12();
		break;
	}
	return nowstate;
}


void InitStory2()
{
	gStep = STORY_STEP6;
	nowstate = Story2();
}
void DrawStory6()
{
	g_alpha += 10;
	moji8.y -= moji8.spd_y;
	SetDrawBright(g_alpha, g_alpha, g_alpha);
	DrawMemTh(moji8.x, moji8.y, cgStory_t13);
	if (moji8.y <= 0)
	{
		moji8.y = 0;
	}
	if (f[STORYFRAME].frame >= 105)
	{
		moji9.y -= moji9.spd_y;
		g_alpha2 += 10;
		SetDrawBright(g_alpha2, g_alpha2, g_alpha2);
		DrawMemTh(moji9.x, moji9.y, cgStory_t14);
		if (moji9.y <= 0)
		{
			moji9.y = 0;
		}
	}
	if (f[STORYFRAME].frame >= 210)
	{
		moji10.y -= moji10.spd_y;
		g_alpha3 += 10;
		SetDrawBright(g_alpha3, g_alpha3, g_alpha3);
		DrawMemTh(moji9.x, moji9.y, cgStory_t15);
		if (moji10.y <= 0)
		{
			moji10.y = 0;
		}
	}

}



void DrawStory7()
{
	if (f[STORYFRAME].frame >= 225)
	{
		koma8.y -= koma8.spd_y;
		g_alpha2 += 10;
		SetDrawBright(g_alpha2, g_alpha2, g_alpha2);
		DrawMemTh(koma8.x, koma8.y, cgStory8);

		if (koma8.y <= 0)
		{
			koma8.y = 0;
		}
		if (koma8.y == 0)
		{
			DrawMemTh(moji12.x, moji12.y, cgStory_t17);
		}
	}
	if (f[STORYFRAME].frame >= 75)
	{
		koma7.y -= koma7.spd_y;
		g_alpha += 10;
		SetDrawBright(g_alpha, g_alpha, g_alpha);
		DrawMemTh(koma7.x, koma7.y, cgStory7);
		if (koma7.y <= 0)
		{
			koma7.y = 0;
		}
		if (koma7.y == 0)
		{
			DrawMemTh(moji11.x, moji11.y, cgStory_t16);
		}
	}
	if (f[STORYFRAME].frame >= 320)
	{
		moji11.y = 1000;
		moji12.y = 1200;
		DrawMemTh(0, 600, cgStory_t18);
	}
	if (f[STORYFRAME].frame >= 395)
	{
		DrawMemTh(0, 600, cgStory_t19);
	}
}



void DrawStory8()
{
	if (f[STORYFRAME].frame >= 75)
	{
		koma9.y -= koma9.spd_y;
		g_alpha += 10;
		SetDrawBright(g_alpha, g_alpha, g_alpha);
		DrawMemTh(koma9.x, koma9.y, cgStory9);
		if (koma9.y <= 0)
		{
			koma9.y = 0;
		}
		if (koma9.y == 0)
		{
			DrawMemTh(0, moji13.y, cgStory_t20);
		}
	}
	if (f[STORYFRAME].frame >= 265)
	{
		koma10.y -= koma10.spd_y;
		g_alpha2 += 10;
		SetDrawBright(g_alpha2, g_alpha2, g_alpha2);
		DrawMemTh(koma10.x, koma10.y, cgStory10);
		moji13.y = 1000;
		if (koma10.y <= 0)
		{

			koma10.y = 0;
		}
		if (koma10.y == 0)
		{
			DrawMemTh(0, 600, cgStory_t21);
		}
		if (f[STORYFRAME].frame >= 360)
		{
			DrawMemTh(0, 600, cgStory_t22);
		}
		if (f[STORYFRAME].frame >= 435)
		{
			DrawMemTh(0, 600, cgStory_t23);
		}
	}
}

void DrawStory9()
{
	if (f[STORYFRAME].frame >= 75)
		g_alpha += 50;
	koma11.y -= koma11.spd_y;
	SetDrawBright(g_alpha, g_alpha, g_alpha);
	DrawMemTh(koma11.x, koma11.y, cgStory11);
	if (koma11.y <= 0)
	{
		koma11.y = 0;
	}
	if (f[STORYFRAME].frame >= 90)
	{
		DrawMemTh(0, moji13.y, cgStory_t24);
	}
	if (f[STORYFRAME].frame >= 150)
	{
		DrawMemTh(0, 600, cgStory_t25);
	}
	if (f[STORYFRAME].frame >= 450)
	{
		DrawMemTh(0, 600, cgStory_t26);
	}
	/*if (f[STORYFRAME].frame >= 75)
	{
		g_alpha += 10;
		koma12.y -= koma12.spd_y;
		SetDrawBright(g_alpha, g_alpha, g_alpha);
		DrawMemTh(koma12.x, koma12.y, cgStory12);
		if (koma12.y <= 0)
		{
			koma12.y = 0;
		}
	}*/
}

void DrawStory10()
{
	if (f[STORYFRAME].frame >= 75)
	{
		g_alpha += 10;
		if (g_alpha >= 300)
		{
			g_alpha = 300;
		}
		moji14.y -= moji14.spd_y;
		SetDrawBright(g_alpha, g_alpha, g_alpha);
		DrawMemTh(0, moji14.y, cgStory_t27);
		if (moji14.y <= 0)
		{
			moji14.y = 0;
		}
	}
}

void DrawStory11()
{
	if (f[STORYFRAME].frame >= 75)
	{
		g_alpha += 10;
		koma12.y -= koma12.spd_y;
		SetDrawBright(g_alpha, g_alpha, g_alpha);
		DrawMemTh(koma12.x, koma12.y, cgStory12);
		if (koma12.y <= 0)
		{
			koma12.y = 0;
		}
		if (koma12.y == 0)
		{
			DrawMemTh(0, moji12.y, cgStory_t28);
		}
		if (f[STORYFRAME].frame >= 455)
		{
			DrawMemTh(0, moji13.y, cgStory_t29);
		}
		if (f[STORYFRAME].frame >= 815)
		{
			moji12.y = 1000;
			moji13.y = 1000;
			DrawMemTh(0, moji10.y, cgStory_t30);
		}
		if (f[STORYFRAME].frame >= 965)
		{
			moji10.y = 1000;
			DrawMemTh(0, moji11.y, cgStory_t31);
		}
		if (f[STORYFRAME].frame >= 1115)
		{
			DrawMemTh(0, moji9.y, cgStory_t32);
		}
		if (f[STORYFRAME].frame >= 1265)
		{
			moji11.y = 1000;
			moji9.y = 1000;
			DrawMemTh(0, 600, cgStory_t33);
		}
	}
}

void DrawStory12()
{
	if (f[STORYFRAME].frame >= 75)
	{
		g_alpha += 10;
		moji15.y -= moji15.spd_y;
		SetDrawBright(g_alpha, g_alpha, g_alpha);
		DrawMemTh(0, moji15.y, cgStory_t34);
		if (moji15.y <= 0)
		{
			moji15.y = 0;
		}
	}
}
