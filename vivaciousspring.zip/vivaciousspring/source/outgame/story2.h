#pragma once

#include"../system/common.h"
#include "../amgame.h"
#include "../ingame/vivacious_spring.h"
#include	"../system/vivacious_spring_se.h"
#include "story1.h"

#define STORY_STEP6 5
#define STORY_STEP7 6
#define STORY_STEP8 7
#define STORY_STEP9 8
#define STORY_STEP10 9
#define STORY_STEP11 10
#define STORY_STEP12 11
#define STORY_STEP13 12
extern int clear_v_up;
extern int cgStory7;
extern int cgStory8;
extern int cgStory9;
extern int cgStory10;
extern int cgStory11;
extern int cgStory12;
extern int cgStory_t13;
extern int cgStory_t14;
extern int cgStory_t15;
extern int cgStory_t16;
extern int cgStory_t17;
extern int cgStory_t18;
extern int cgStory_t19;
extern int cgStory_t20;
extern int cgStory_t21;
extern int cgStory_t22;
extern int cgStory_t23;
extern int cgStory_t24;
extern int cgStory_t25;
extern int cgStory_t26;
extern int cgStory_t27;
extern int cgStory_t28;
extern int cgStory_t29;
extern int cgStory_t30;
extern int cgStory_t31;
extern int cgStory_t32;
extern int cgStory_t33;
extern int cgStory_t34;

extern void Koma2();
extern void InitStory2();
extern int Story2();
extern void DrawStory6();
extern void DrawStory7();
extern void DrawStory8();
extern void DrawStory9();
extern void DrawStory10();
extern void DrawStory11();
extern void DrawStory12();