#pragma once
extern int cgOpga; //�I�v�V�������
extern int cgSetting_setting_On;
extern int cgSetting_setting_Off;
extern int cgSetting_record_On;
extern int cgSetting_record_Off;

extern void DrawOption();
extern int Option();
