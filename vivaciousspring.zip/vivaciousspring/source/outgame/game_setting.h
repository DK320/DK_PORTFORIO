#include "vivacious_spring_option.h"
#include"../system/common.h"
#include "../amgame.h"
#include "../ingame/vivacious_spring.h"
#include	"../system/vivacious_spring_se.h"

void DrawGameSetting();

extern bool bgm_button;
extern bool se_button;
extern bool voice_button;
extern bool voice_button2;

extern int cgOption_bgm;
extern int cgOption_se;
extern int cgOption_voice;
extern int cgOption_dot;
extern int cgSetting_wallpaper;
int GameSetting();
void DrawSettingBg();