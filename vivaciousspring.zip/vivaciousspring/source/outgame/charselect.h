#pragma once
int CharSelect();
void DrawCharSelect();
extern int cgFrame_b_On;
extern int cgFrame_b_Off;
extern int cgFrame_v_On;
extern int cgFrame_v_Off;
extern int character;
