#include "vivacious_spring_option.h"
#include"../system/common.h"
#include "../amgame.h"
#include "../ingame/vivacious_spring.h"
#include "../system/vivacious_spring_bgm.h"
#include	"../system/vivacious_spring_se.h"
#include	"vivacious_spring_title.h"
#include	"game_setting.h"
int cgOpga = 0;
int cgGamesetting = 0;
int cgSetting_record_On = 0;
int cgSetting_record_Off = 0;
int cgSetting_setting_On = 0;
int cgSetting_setting_Off = 0;


void DrawOption()//�I�v�V�����`��
{
	DrawMemTh(280, 120, cgSetting_record_Off);
	DrawMemTh(300, 450, cgSetting_setting_Off);
	if (cursor == 0)
	{
		SetDrawBright(1000, 1000, 1000);
		DrawMemTh(280, 120, cgSetting_record_On);
		SetDrawBright(300, 300, 300);
		DrawMemTh(300, 450, cgSetting_setting_Off);
	}
	if (cursor == 1)
	{
		SetDrawBright(1000, 1000, 1000);
		DrawMemTh(300, 450, cgSetting_setting_On);
		SetDrawBright(300, 300, 300);
		DrawMemTh(280, 120, cgSetting_record_Off);
	}
}

int Option()//�I�v�V�����؂�ւ�
{
	g_alpha = 0;
	if (gTrg & KEYIN_DOWN)
	{
		if (se_button == false)
		{
			PlayMemBack(se_move);
		}
		cursor++;
		if (cursor > 1)
		{
			cursor = 1;
		}
	}
	if (gTrg & KEYIN_UP)
	{
		if (se_button == false)
		{
			PlayMemBack(se_move);
		}
		cursor++;
		if (cursor > 0)
		{
			cursor = 0;
		}
	}

	if (gTrg&KEYIN_Z && cursor == 0)
	{
		if (se_button == false)
		{
			PlayMemBack(seDecide);
		}
		cursor = 0;
		return STATE_RECORD;
	}
	if (gTrg&KEYIN_Z && cursor == 1)
	{
		PlayMemBack(seDecide);
		cursor = 1;
		/*if (voice_button == 1)
		{
			voice_button = 0;
		}
		else if (voice_button == 0)
		{
			voice_button = 1;
		}*/
		return STATE_GAMESETTING;
	}

	if (gTrg & KEYIN_X)
	{
		if (voice_button2 == 1)
		{
			voice_button = 1;
		}
		else if (voice_button2 == 0)
		{
			voice_button = 0;
		}
		if (se_button == false)
		{
			PlayMemBack(seBack);
		}

		Setumei();
		return STATE_TITLE;
	}
	return STATE_OPTION;
};
