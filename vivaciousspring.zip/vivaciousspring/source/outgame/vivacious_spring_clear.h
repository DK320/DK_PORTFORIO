#pragma once
#define SUUJI_MAX 10
extern void DrawClear();
extern int Clear();
extern void LoadGoal();
extern void InitGoal();
extern void Goal();
extern void  FrameCalcu();
extern void ClearRankCalcu();
extern void DrawClearRank();
extern int ClearRank();

extern int gamecount;
extern int clearcount;
extern int srank;
extern int arank;
extern int brank;
extern int crank;
extern int cgGoal;
extern int cgClear; //�N���A���
extern int cgSrank;
extern int cgArank;
extern int cgBrank;
extern int cgCrank;
extern int cgBlack;
extern int cgIcon_a;
extern int cgRankScreen;
extern int cgClearBg;
extern int cgParts0;
extern int cgParts1;
extern int cgParts2;
extern int cgParts3;
extern int cgParts4;
extern int cgParts5;

extern int cgStage_name1;
extern int cgStage_name2;
extern int cgStage_name3;
extern int cgStage_name4;
extern int cgSuuji[SUUJI_MAX];