#pragma once
#include	<Windows.h>
#include	"../amgame.h"
#include	"../AmHelper.h"
#include	"../ingame/vivacious_spring.h"

extern struct CAMERA cam;
struct SELECTSTAGE
{
	int x;
	int y;
	int spd_x;
	int spd_y;
};
extern struct SELECTSTAGE map2;
extern int cgCoin_Collect;
extern int cgClearRank; //�N���A�����N���
extern int cgWallPaper;
extern int cgRoad;
extern int cgCursorss_on;
extern int cgCursorss_off;
extern int cgCloud_stage1;
extern int cgCloud_stage2;
extern int cgCloud_stage3;
extern int cgCloud_stage4;
extern int cgCloud_stage5;
extern int cgCloud_opening;
extern int cgCloud_ending;

void DrawSelect();
int StartStage();
void InitCharCur();
void StageMap();
void stageprocess();
void InitStageCam();

