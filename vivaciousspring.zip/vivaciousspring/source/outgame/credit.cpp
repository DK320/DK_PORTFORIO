#include	"../amgame.h"
#include	"../AmHelper.h"
#include "story1.h"
#include "story2.h"
#include"../system/common.h"
#include "../ingame/vivacious_spring.h"
#include	"../system/vivacious_spring_se.h"
#include "charselect.h"
#include "../ingame/frame.h"
#include "vivacious_spring_clear.h"
#include"../system/vivacious_spring_bgm.h"
#include "game_setting.h"

int cgCredit;
int credit_count;
struct CREDIT
{
	int x;
	int y;
	int spd_y;
};
struct CREDIT credit;

void Credit()
{
	credit.x = 0;
	credit.y = 800;
	credit.spd_y = 2;

}
int MoveCredit()
{
	f[CREDITFRAME].frame++;
	if (f[CREDITFRAME].frame >= 2520) 
	{
		PlayMemLoop(bgmStageselect);
		if (voice_button2 == 1)
		{
			voice_button = 1;
		}
		else if (voice_button2 == 0)
		{
			voice_button = 0;
		}
		return STATE_STAGESELECT;
	}
	return STATE_CREDIT;
}

void DrawCredit() 
{
	DrawMemTh(credit.x, credit.y, cgCredit);
	credit.y -= credit.spd_y;
	//DrawPrintf(0, 780, GetColor(0, 255, 0), "credit.y= %d\n", credit.y);
}
	