//
// �g�������@�\�▽�߂ɂ��킹�� include ��ǉ�����
//
#include	<Windows.h>
#include	"../amgame.h"
#include	"../AmHelper.h"
#include	"../utility.h"
#include	<math.h>
#include	"vivacious_spring_camera.h"
#include	"vivacious_spring.h"
#include	"vivacious_spring_mapdata1.h"
#include	"vivacious_spring_bg.h"
#include	"vivacious_spring_game.h"
#include	"../system/common.h"
//�w�i�̃n���h���i�[
int cgBg1 = 0;
int cgBg2 = 0;
int cgBg3 = 0;
int cgBg4 = 0;


BG bg[BG_MAX] = { 0 };
int cgBg()
{
	switch (gNowstage)
	{
	case STAGE_1:
		return cgBg1;
		break;
	case STAGE_2:
		return cgBg2;
		break;
	case STAGE_3:
		return cgBg3;
		break;
	case STAGE_4:
		return cgBg4;
		break;
	}
	return -1;
}
//�w�i�̏�����
void InitBg()
{
	
		//�w�i�̍����Ɖ������擾
	GetPictureSize(cgBg1, &bg[STAGE_1].w, &bg[STAGE_1].h);
	GetPictureSize(cgBg2, &bg[STAGE_2].w, &bg[STAGE_2].h);
	GetPictureSize(cgBg3, &bg[STAGE_3].w, &bg[STAGE_3].h);
	GetPictureSize(cgBg4, &bg[STAGE_4].w, &bg[STAGE_4].h);
}

void LoadBg()
{
	cgBg1 = LoadTexture("res/wallpaper_stage_1.png");
	cgBg2 = LoadTexture("res/wallpaper_stage_2.png");
	cgBg3 = LoadTexture("res/wallpaper_stage_3.png");
	cgBg4 = LoadTexture("res/wallpaper_stage_4.png");
	
}


void MoveBg()
{
	int stage = gNowstage;
	int mapsize_h = WhereStageH();
	int mapsize_w = WhereStageW();
	bg[stage].x = cv.view_x / ((mapsize_w * CHIPSIZE_W_STAGE) / DISP_W);
	if (
		(gNowstage == STAGE_3) ||
		(gNowstage == STAGE_4)
		) 
	{
		bg[stage].y = cv.view_y / ((mapsize_h * CHIPSIZE_H_STAGE) / DISP_H);
	}
}


void DrawBg()
{
	int cg = cgBg();
	g_alpha2 = 0;//�Q�[���I�[�o�[�t�F�[�h�C�����Z�b�g�J�E���g
	g_alpha += 30;//�t�F�[�h�C���@
	SetDrawBright(g_alpha, g_alpha, g_alpha);//�t�F�[�h�C��
	SetDrawMode(AMDRAW_NOBLEND, 0);
	int i = gNowstage;
	SetDrawArea(0, 0, bg[i].w, bg[i].h);
	DrawMemTh(0 - bg[i].x, 0 - bg[i].y, cg);
}