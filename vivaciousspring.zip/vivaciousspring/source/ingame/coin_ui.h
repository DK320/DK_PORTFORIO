#pragma once

//
//define��`
//
#define COIN_NUMBER_MAX 3//�R�C���̍ő吔�̌���
#define CG_COIN_NUMBER_W_NUM 5
#define CG_COIN_NUMBER_H_NUM 2
#define CG_COIN_NUMBER_W 150
#define CG_COIN_NUMBER_H 126




//
//�\���̒�`
//
typedef struct
{
	int x, y;
	int w, h;
	int frame;
}COIN_UI;

typedef struct
{
	int x, y;
	int w, h;
	int no;
}COIN_NUMBER;

//
//�O���[�o���ϐ���`
//
extern COIN_UI co;
extern COIN_NUMBER co_num_b[COIN_NUMBER_MAX];
extern COIN_NUMBER co_num_v[COIN_NUMBER_MAX];
extern int cg_coin_ui;
extern int cg_coin_number[CG_COIN_NUMBER_W_NUM*CG_COIN_NUMBER_H_NUM];
extern bool hit_coin_b;
extern bool hit_coin_v;
//
//�O���[�o���֐�
//
extern void LoadCoinUi();
extern void InitCoinUi();
extern void ProcessCoinUi();
extern void DrawCoinUi();

