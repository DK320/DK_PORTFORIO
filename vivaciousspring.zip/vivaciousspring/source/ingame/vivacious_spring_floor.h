#pragma once
#define FLOOR_STATE_IDLE 0
#define FLOOR_STATE_HIT 1
#define FLOOR_STATE_REVIVAL 2

#define MOVEFLOOR_MAX_1 4
#define MOVEFLOOR_MAX_2 6
#define MOVEFLOOR_MAX_3 45
#define MOVEFLOOR_MAX_4 12

#define CRUMBLE_MAX_1 3
#define CRUMBLE_MAX_2 13
#define CRUMBLE_MAX_3 26/*27*/
#define CRUMBLE_MAX_4 20

#define	SF3_MAX 3
#define SF2_200_40 0
#define SF3_80_40 1
#define SF3_560_40 2
#define SF4_G_40_1520 3
#define SF4_G_160_40 4
#define SF4_R_160_40 5


#define CRUMBLEFLOOR_80_40 1
#define CRUMBLEFLOOR_120_40 2
#define CRUMBLEFLOOR_160_40 3
#define CRUMBLEFLOOR_240_40 4
#define CRUMBLEFLOOR_280_40 5
#define CRUMBLEFLOOR_280_440 6
#define CRUMBLEFLOOR_40_1200 7
#define CRUMBLEFLOOR_40_400 8
#define CRUMBLEFLOOR_40_520 9
#define CRUMBLEFLOOR_200_40 10

#define MOVEFLOOR_280_240 1
#define MOVEFLOOR_160_40 2
#define MOVEFLOOR_200_40 3
#define MOVEFLOOR_40_40 4
#define MOVEFLOOR_40_280 5
#define MOVEFLOOR_120_40 6
#define MOVEFLOOR_280_520 7
#define MOVEFLOOR_40_80 8
#define MOVEFLOOR_40_160 9
#define MOVEFLOOR_40_200 10
#define MOVEFLOOR_80_40 11
#define MOVEFLOOR_1280_120 12

extern void InitMovefloor();
extern void LoadFloor();
extern void Movefloor();

extern int MoveFloorMax();


extern int cg_switch_2_land_200_40;
extern int cg_switch_3_land_80_40;
extern int cg_switch_3_land_560_40;

extern int cg_gimmick_crumble_land_80_40;
extern int cg_gimmick_crumble_land_120_40;
extern int cg_gimmick_crumble_land_160_40;
extern int cg_gimmick_crumble_land_200_40;
extern int cg_gimmick_crumble_land_240_40;
extern int cg_gimmick_crumble_land_280_40;
extern int cg_gimmick_crumble_land_280_440;
extern int cg_gimmick_crumble_land_40_1200;
extern int cg_gimmick_crumble_land_40_400;
extern int cg_gimmick_crumble_land_40_520;



extern int cg_gimmick_move_land_280_520;
extern int cg_gimmick_move_land_280_240;
extern int cg_gimmick_move_land_200_40;
extern int cg_gimmick_move_land_160_40;
extern int cg_gimmick_move_land_120_40;
extern int cg_gimmick_move_land_40_40;
extern int cg_gimmick_move_land_40_280;
extern int cg_gimmick_move_land_80_40;
extern int cg_gimmick_move_land_40_200;
extern int cg_gimmick_move_land_40_160;
extern int cg_gimmick_move_land_40_80;
extern int cg_gimmick_move_land_1280_120;


extern void CrumbleFloor();
extern void InitCrumbleFloor();
extern void HitCrumbleFloorPlayer(int , int ,int );

extern void HitMoveFloorPlayerx(int ,int);
extern void HitMoveFloorPlayery(int ,int);

extern int HitSwitchFloorMovefloor(int floor);
extern void HitSwitchFloorPlayer(int,int,int);

extern int MoveFloorCg(int kind);
extern int CrumbleFloorCg(int kind);
extern int CgSwitchFloor(int kind);


extern void InitSwitchFloor();
extern void ProcessSwitchGimmick();