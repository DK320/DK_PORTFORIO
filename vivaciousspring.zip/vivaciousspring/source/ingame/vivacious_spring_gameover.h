void DrawGameOver();
void GameOver();
int Continue();
extern int cgGameOver;
extern int cgContinue_message;
extern int cgContinue_yes_on;
extern int cgContinue_yes_off;
extern int cgContinue_no_on;
extern int cgContinue_no_off;