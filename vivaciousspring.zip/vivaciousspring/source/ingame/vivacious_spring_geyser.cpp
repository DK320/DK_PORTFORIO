#include	"../amgame.h"
#include	"../system/common.h"
#include	"vivacious_spring_geyser.h"
#include	"vivacious_spring_player.h"
#include	"frame.h"
#include	"../outgame/game_setting.h"
#include	"vivacious_spring_game.h"
#include	"vivacious_spring_camera.h"
#include	"../outgame/charselect.h"
#include	"vivacious_spring.h"
#include	"../system/vivacious_spring_se.h"
#include	"vivacious_spring_time.h"
int cggimmick_geyser_80_165[CGGEYSER_MAX] = { 0 };
int cggimmick_geyser_80_165_d[CGGEYSER_MAX] = { 0 };
int cggimmick_geyser_165_80[CGGEYSER_MAX] = { 0 };
int cggimmick_geyser_165_80_r[CGGEYSER_MAX] = { 0 };
int cggimmick_geyser_80_325[CGGEYSER_MAX] = { 0 };
int cggimmick_geyser_80_325_d[CGGEYSER_MAX] = { 0 };
int cggimmick_geyser_325_80[CGGEYSER_MAX] = { 0 };
int cggimmick_geyser_325_80_r[CGGEYSER_MAX] = { 0 };
int cggimmick_geyser_80_645[CGGEYSER_MAX] = { 0 };
int cggimmick_geyser_645_80[CGGEYSER_MAX]={ 0 };

void LoadGeyser()
{
	LoadBlkTexture("res/gimmick_geyser_80_165.png",80,165,20,1,20*1, cggimmick_geyser_80_165);
	LoadBlkTexture("res/gimmick_geyser_80_165_d.png",80,165,20,1,20*1, cggimmick_geyser_80_165_d);
	LoadBlkTexture("res/gimmick_geyser_165_80.png",165,80,20,1,20*1, cggimmick_geyser_165_80);
	LoadBlkTexture("res/gimmick_geyser_165_80_r.png",165,80,2,10,2*10, cggimmick_geyser_165_80_r);
	LoadBlkTexture("res/gimmick_geyser_80_325.png",80,325,20,1,20*1, cggimmick_geyser_80_325);
	LoadBlkTexture("res/gimmick_geyser_80_325_d.png",80,325,20,1,20*1, cggimmick_geyser_80_325_d);
	LoadBlkTexture("res/gimmick_geyser_325_80.png",325,80,2,10,2*10, cggimmick_geyser_325_80);
	LoadBlkTexture("res/gimmick_geyser_325_80_r.png",325,80,2,10,2*10, cggimmick_geyser_325_80_r);
	LoadBlkTexture("res/gimmick_geyser_80_645.png", 80, 645, 20, 1, 20 * 1, cggimmick_geyser_80_645);
	LoadBlkTexture("res/gimmick_geyser_645_80.png", 645, 80, 2, 10, 2 * 10, cggimmick_geyser_645_80);
}

int InitGeyserwh(int kind)
{
	switch (kind)
	{
	case G80_165:
		return cggimmick_geyser_80_165[0];
		break;
	case G80_165_D:
		return cggimmick_geyser_80_165_d[0];
		break;
	case G165_80:
		return cggimmick_geyser_165_80[0];
		break;
	case G165_80_R:
		return cggimmick_geyser_165_80_r[0];
		break;
	case G80_325:
		return cggimmick_geyser_80_325[0];
		break;
	case G80_325_D:
		return cggimmick_geyser_80_325_d[0];
		break;
	case G325_80:
		return cggimmick_geyser_325_80[0];
		break;
	case G325_80_R:
		return cggimmick_geyser_325_80_r[0];
		break;
	case G80_645:
		return cggimmick_geyser_80_645[0];
		break;
	case G645_80:
		return cggimmick_geyser_645_80[0];
		break;
	}
	return -1;
}
int GeyserMax() 
{
	switch (gNowstage) 
	{
	case STAGE_2:
		return GEYSER_MAX_2;
		break;
	case STAGE_3:
		return GEYSER_MAX_3;
		break;
	case STAGE_4:
		return GEYSER_MAX_4;
		break;
	}
	return -1;
}
void InitGeyser()
{
	int geyser_max = GeyserMax();
	//���X�e�[�W�Q���[��]
	int x2[GEYSER_MAX_2] =
	{
		280,2560,2640,3160,12800,15280,15440,15860,16040,
		1320.0,
		15080.0,15600.0,16200,
		360,640
	};

	int y2[GEYSER_MAX_2]
	{
		480,120,120,360,480,40,40,40,40,
		360,
		40,40,40,
		280,160
	};
	int kind[GEYSER_MAX_2]=
	{
		G80_165,G80_165,G80_165,G80_165,G80_165,G80_165,G80_165,G80_165,G80_165,
		G80_325,
		G645_80,G645_80,G645_80,
		G325_80_R,G325_80_R,
	};
	
	int x3[GEYSER_MAX_3]=
	{
		920,1080,560,880,
		240,440,
		360,
		920,920,920,920,920,760,760,760,760,760,760
	};

	int y3[GEYSER_MAX_3]=
	{
		2080,13440,21280,21960,
		760,760,
		10540,
		1000,1240,1400,1640,11920,13600,13680,13760,13840,13920,14000
	};
	int kind3[GEYSER_MAX_3]=
	{
		G80_165_D,G80_165,G165_80,G165_80,
		G80_645,G80_645,
		G165_80_R,
		G325_80,G325_80,G325_80,G325_80,
		G325_80_R,G325_80_R,G325_80_R,G325_80_R,G325_80_R,G325_80_R,G325_80_R
	};

	int	x4[GEYSER_MAX_4]=
	{
		3040,3120,3200,3280,3440,
		3520,3600,3680,3760,3840,
		3920,4000,4080,

		80,

		2400,2560,

		1080,2640
	};

	int y4[GEYSER_MAX_4]=
	{
		560,560,560,560,560,
		560,560,560,560,560,
		560,560,560,

		1560,

		2600,2600,

		1560,3000
	};

	int kind4[GEYSER_MAX_4]=
	{
		G80_165,G80_165,G80_165,G80_165,G80_165,
		G80_165,G80_165,G80_165,G80_165,G80_165,
		G80_165,G80_165,G80_165,

		G80_325,

		G80_325_D,G80_325_D,

		G165_80_R,G165_80_R
	};

	for (int i = 0; i < geyser_max; i++)
	{
		int cg = InitGeyserwh(kind[i]);
		InitChara(
			STAGE_2, CHARACTERTYPE_GEYSER, cg,
			x2[i], y2[i]+560, 0, 0, 0, 1, 0, 0,0,0,0,0,
			i, -15, kind[i]
		);
		cg = InitGeyserwh(kind3[i]);
		InitChara(
			STAGE_3, CHARACTERTYPE_GEYSER, cg,
			x3[i], y3[i]+ 40, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
			i, -15, kind3[i]
		);
		cg = InitGeyserwh(kind4[i]);
		InitChara(
			STAGE_4, CHARACTERTYPE_GEYSER, cg,
			x4[i], y4[i] +800, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0,
			i, -15, kind4[i]
		);
	}
	
}



int CgGeyser(int i) 
{
	int cg = 0;
	 
	if (chara[i].frame < 150) 
	{
		switch (chara[i].kind)
		{
		case G80_165:
			return cggimmick_geyser_80_165[0];
			break;
		case G80_165_D:
			return cggimmick_geyser_80_165_d[0];
			break;
		case G165_80:
			return cggimmick_geyser_165_80[0];
			break;
		case G165_80_R:
			return cggimmick_geyser_165_80_r[0];
			break;
		case G80_325:
			return cggimmick_geyser_80_325[0];
			break;
		case G80_325_D:
			return cggimmick_geyser_80_325_d[0];
			break;
		case G325_80:
			return cggimmick_geyser_325_80[0];
			break;
		case G325_80_R:
			return cggimmick_geyser_325_80_r[0];
			break;
		case G80_645:
			return cggimmick_geyser_80_645[0];
			break;
		case G645_80:
			return cggimmick_geyser_645_80[0];
			break;
		}
		
	}
	if(chara[i].frame > 149) 
	{
		int k = (((chara[i].frame - 150) / 4) % 19) + 1;
		switch (chara[i].kind)
		{
		case G80_165:
			return cggimmick_geyser_80_165[k];
			break;
		case G80_165_D:
			return cggimmick_geyser_80_165_d[k];
			break;
		case G165_80:
			return cggimmick_geyser_165_80[k];
			break;
		case G165_80_R:
			return cggimmick_geyser_165_80_r[k];
			break;
		case G80_325:
			return cggimmick_geyser_80_325[k];
			break;
		case G80_325_D:
			return cggimmick_geyser_80_325_d[k];
			break;
		case G325_80:
			return cggimmick_geyser_325_80[k];
			break;
		case G325_80_R:
			return cggimmick_geyser_325_80_r[k];
			break;
		case G80_645:
			return cggimmick_geyser_80_645[k];
			break;
		case G645_80:
			return cggimmick_geyser_645_80[k];
			break;
		}
	}
	return cg;
}

void ProcessGeyser()
{
		int player = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);
		int geyser_max = GeyserMax();
		for (int i = 0; i < geyser_max; i++)
		{
			int geyser = CheckCharaType(CHARACTERTYPE_GEYSER, i);
			
			if (
				(chara[player].hit == NOHIT) &&
				(chara[geyser].frame > 149)
				)
			{
				if (HitChara(geyser, player) == 1)
				{
					chara[player].hit = HIT;
					time_cloud_action = true;
					time_action = true; 
					StopInVoice();
					if (character == 1)
					{
						int no = rand() % 3;
						if (no == 0)
						{
							if (voice_button2 == false)
							PlayInSe(in_voice[DAMAGE_B_1].handle);
						}
						else if(no == 1)
						{
							if (voice_button2 == false)
							PlayInSe(in_voice[DAMAGE_B_2].handle);
						}
						else 
						{
							if (voice_button2 == false)
							PlayInSe(in_voice[DAMAGE_B_3].handle);
						}
						
					}
					else
					{
						int no = rand() % 4;
						if (no == 0)
						{
							if (voice_button2 == false)
							PlayInSe(in_voice[DAMAGE_V_1].handle);
						}
						else if (no == 1)
						{
							if (voice_button2 == false)
							PlayInSe(in_voice[DAMAGE_V_2].handle);
						}
						else if(no==2)
						{
							if (voice_button2 == false)
							PlayInSe(in_voice[DAMAGE_V_3].handle);
						}
						else 
						{
							if (voice_button2 == false)
							PlayInSe(in_voice[DAMAGE_V_4].handle);
						}
					}
				}
			}
			if (chara[geyser].frame > 149)
			{
				if (
					(chara[geyser].x + chara[geyser].dx > cv.view_x) &&
					(chara[geyser].x - chara[geyser].dx < cv.view_x + DISP_W) &&
					(chara[geyser].y + chara[geyser].dy > cv.view_y) &&
					(chara[geyser].y < cv.view_y + DISP_H)
					)
				{
					if (se_button == false)
					PlayMemBack(in_se[GEYSER].handle);
				}
			}
			if (chara[geyser].frame > 149 + 76)
			{
				chara[geyser].frame = 0;
				StopPlayMem(in_se[GEYSER].handle);
			}
			chara[geyser].frame++;
		}
	
}