#include	<Windows.h>
#include	"../amgame.h"
#include	"../AmHelper.h"
#include	"../utility.h"
#include	<math.h>
#include	"vivacious_spring.h"
#include	"vivacious_spring_player.h"
#include	"vivacious_spring_camera.h"
#include	"vivacious_spring_mapdata1.h"
#include	"../system/common.h"
#include	"vivacious_spring_floor.h"
#include	"../system/vivacious_spring_se.h"
#include	"vivacious_spring_gameover.h"
#include	"vivacious_spring_game.h"
#include	"../outgame/game_setting.h"
#include	"vivacious_spring_bumper.h"
#include	"../outgame/charselect.h"
int cgPlayer[PLAYER_PICTURE_MAX * 2] = { 0 };
int cgPlayer2[PLAYER2_PICTURE_MAX * 2] = { 0 };
int cgjump_b[PLAYER_PICTURE_JAMP_B_MAX * 2] = {0};
int cgjump_b2[PLAYER2_PICTURE_JAMP_B_MAX * 2] = {0};
int cgjump_high_b[PLAYER_PICTURE_HIGH_B_MAX * 2] = {0};
int cgjump_high_b2[PLAYER2_PICTURE_HIGH_B_MAX * 2] = {0};
int cg_n_b[PLAYER_PARALYSIS_W_NUM*PLAYER_PARALYSIS_H_NUM * 2] = { 0 };
int cg_n_v[PLAYER_PARALYSIS_W_NUM*PLAYER_PARALYSIS_H_NUM * 2] = { 0 };

int lingout = 0;
int ling_out = 0;//�����O�A�E�g�������H0���Ă��Ȃ�1����
void LoadPlayer()
{
	LoadBlkTextureLR(
		"res/normal_b.png",
		90, 80,
		PLAYER_PICTURE_MAX, 1,
		PLAYER_PICTURE_MAX, cgPlayer
	);
	LoadBlkTextureLR(
		"res/jump_b.png",
		90, 80,
		PLAYER_PICTURE_JAMP_B_MAX, 1,
		PLAYER_PICTURE_JAMP_B_MAX, cgjump_b
	);
	LoadBlkTextureLR(
		"res/jump_high_b.png",
		90, 80,
		PLAYER_PICTURE_HIGH_B_MAX, 1,
		PLAYER_PICTURE_HIGH_B_MAX, cgjump_high_b
	);
	LoadBlkTextureLR(
		"res/n_b.png",
		(PLAYER_PARALYSIS_W / PLAYER_PARALYSIS_W_NUM),
		(PLAYER_PARALYSIS_H / PLAYER_PARALYSIS_H_NUM),
		PLAYER_PARALYSIS_W_NUM, PLAYER_PARALYSIS_H_NUM,
		(PLAYER_PARALYSIS_W_NUM*PLAYER_PARALYSIS_H_NUM),
		cg_n_b
	);
	LoadBlkTextureLR(
		"res/n_v.png",
		(PLAYER_PARALYSIS_W_V / PLAYER_PARALYSIS_W_NUM),
		(PLAYER_PARALYSIS_H / PLAYER_PARALYSIS_H_NUM),
		PLAYER_PARALYSIS_W_NUM, PLAYER_PARALYSIS_H_NUM,
		(PLAYER_PARALYSIS_W_NUM*PLAYER_PARALYSIS_H_NUM),
		cg_n_v
	);

	//�΂˂���
	LoadBlkTextureLR(
		"res/normal_v.png",
		100, 80,
		PLAYER2_PICTURE_MAX, 1,
		PLAYER2_PICTURE_MAX, cgPlayer2
	);
	LoadBlkTextureLR(
		"res/jump_v.png",
		100, 80,
		PLAYER2_PICTURE_JAMP_B_MAX, 1,
		PLAYER2_PICTURE_JAMP_B_MAX, cgjump_b2
	);
	LoadBlkTextureLR(
		"res/highjump_v.png",
		100, 80,
		PLAYER2_PICTURE_HIGH_B_MAX, 1,
		PLAYER2_PICTURE_HIGH_B_MAX, cgjump_high_b2
	);
}


//�v���C���[�̏�����
void InitPlayer()
{
	int i;

	if (character == 1)//�΂ˌN
	{
		i = CheckCharaType(CHARACTERTYPE_NONE, 0);
		chara[i].type = CHARACTERTYPE_PLAYER_MAN;
		//�����ʒu
		switch (gNowstage)
		{
		case STAGE_1:
			chara[i].x = 40.0;
			chara[i].y = 1160.0;
			break;
		case STAGE_2:
			/*chara[i].x = 7460;
			chara[i].y = 200 + 560;*/
			chara[i].x = 40.0;
			chara[i].y = 1160.0;
			break;
		case STAGE_3:
			/*chara[i].x = 840.0;
			chara[i].y = 4200.0;*/
			/*chara[i].x = 840.0;
			chara[i].y = 9000.0;*/
			/*chara[i].x = 80.0;
			chara[i].y = 17440;*/
			chara[i].x = 40.0;
			chara[i].y = 23880.0;
			break;
		case STAGE_4:
			chara[i].x = 80.0;
			chara[i].y = 3600 + 800;
			/*chara[i].x = 5760.0;
			chara[i].y = 2000 + 880;*/
			break;
		}
		//�ix�Ay�j����`��J�n����ʒu����
		chara[i].dx = -45.0;
		chara[i].dy = -80.0;
		chara[i].jamp_frame = 0;
		chara[i].jamp_count = -1;
		chara[i].state = PLAYER_STATE_IDLE;
		chara[i].frame = 0;
		chara[i].direction = 1;
		chara[i].gr = 0.0;
		chara[i].spd_x = 2;
		chara[i].jamp_spd_x = 4;
		chara[i].w = 90;
		chara[i].h = 80;

		chara[i].hit_x = PLAYER_HIT_X_B;
		chara[i].hit_y = PLAYER_HIT_Y_B;
		chara[i].hit_w = PLAYER_HIT_W_B;
		chara[i].hit_h = PLAYER_HIT_H_B;

		chara[i].use = 1;
		chara[i].stand = false;
		chara[i].floor_under = false;
		chara[i].hit_count = 0;
		chara[i].hp = 120.0;
		chara[i].hit = NOHIT;
		chara[i].save = false;
		chara[i].kind = 1;
		chara[i].no = 1;
	}
	else
	{
		i = CheckCharaType(CHARACTERTYPE_NONE, 0);
		chara[i].type = CHARACTERTYPE_PLAYER_MAN;
		//�����ʒu
		switch (gNowstage)
		{
		case STAGE_1:
			chara[i].x = 40.0;
			chara[i].y = 1160.0;
			break;
		case STAGE_2:
			/*chara[i].x = 7460;
			chara[i].y = 200 + 560;*/
			chara[i].x = 40.0;
			chara[i].y = 1200.0;
			break;
		case STAGE_3:
		/*	chara[i].x = 80.0;
			chara[i].y = 17440;*/
			/*chara[i].x = 640.0;
			chara[i].y = 11000.0;*/
			chara[i].x = 40.0;
			chara[i].y = 23880.0;
			/*chara[i].x = 840.0;
			chara[i].y = 4200.0;*/
			break;
		case STAGE_4:
			chara[i].x = 80.0;
			chara[i].y = 3600 + 800;
			/*chara[i].x = 5760.0;
			chara[i].y = 2000 + 880;*/
			break;
		}
		//�ix�Ay�j����`��J�n����ʒu����
		chara[i].dx = -50.0;
		chara[i].dy = -80.0;
		chara[i].jamp_frame = 0;
		chara[i].jamp_count = -1;
		chara[i].state = PLAYER_STATE_IDLE;
		chara[i].frame = 0;
		chara[i].direction = 1;
		chara[i].gr = 0.0;
		chara[i].spd_x = 2;
		chara[i].jamp_spd_x = 4;
		chara[i].w = 100;
		chara[i].h = 80;
		chara[i].hit_x = PLAYER_HIT_X_V;
		chara[i].hit_y = PLAYER_HIT_Y_V;
		chara[i].hit_w = PLAYER_HIT_W_V;
		chara[i].hit_h = PLAYER_HIT_H_V;
		chara[i].use = 1;
		chara[i].stand = false;
		chara[i].floor_under = false;
		chara[i].hit_count = 0;
		chara[i].hp = 90.0;
		chara[i].hit = NOHIT;
		chara[i].save = false;
		chara[i].kind = 2;
		chara[i].no = 1;
	}
}
void InitJamp(int i)
{
	chara[i].frame = 0;
	chara[i].stand = false;
	/*PlayMemBack(se_jump_b);*/
	for (int k = 0; k < CHARACTER_MAX; k++)
	{
		chara[k].floor_under = false;
	}
	chara[i].jamp_count++;
	if(chara[i].jamp_count > 2)
	{
		StopInVoice();
		if (character == 1)
		{
			if (voice_button2 == false)
			PlayMemBack(in_voice[JUMP_HIGH_B].handle);
		}
		else
		{
			if (voice_button2 == false)
			PlayMemBack(in_voice[JUMP_HIGH_V].handle);
		}
		chara[i].jamp_count = 3;
	}
	else
	{

		if (character == 1)
		{
			if (se_button == false)
			PlayMemBack(in_se[JUMP_B].handle);
		}
		else
		{
			if (se_button == false)
			PlayMemBack(in_se[JUMP_V].handle);
		}
	}
	//else {
	//	PlayInSe(CHARGE_B);
	//}

	chara[i].gr = -10 - (chara[i].jamp_count * 1.6);
	chara[i].y += chara[i].gr;
}
void InitAccumulateJamp(int i)
{
	
	chara[i].frame = 0;
	chara[i].stand = false;
	/*PlayMemBack(se_jump_b);*/
	StopInSe();
	StopInVoice();
	for(int k = 0; k < CHARACTER_MAX; k++)
	{
		chara[k].floor_under = false;
	}
	chara[i].jamp_count++;
	if(chara[i].jamp_count > 3)
	{
		
		if (character == 1)
		{
			if(voice_button2 == false)
			PlayMemBack(in_voice[JUMP_RE_B].handle);
		}
		else
		{
			if (voice_button2 == false)
			PlayMemBack(in_voice[JUMP_RE_V].handle);
		}
		chara[i].jamp_count = 4;
	}

	chara[i].gr = -10 - (chara[i].jamp_count * 1.6);
	chara[i].y += chara[i].gr;
}
//�t���[������
void PlayerFrameStint(int i)
{
	/*int se = CheckPlayMem(se_splash_b);*/
	chara[i].frame++;					//�v���C���[�̃t���[���J�E���g
	switch (chara[i].state) {
	case PLAYER_STATE_IDLE:
		
		if (chara[i].frame > 29)			//�v���C���[��Idle�t���[����31���傫���ꍇ�W�����v�̉񐔂�0�ɂ���
		{
			chara[i].jamp_count = -1;
			
		}
		if (chara[i].frame == 30)
		{
			
			if (character == 1)
			{
				if (se_button == false)
				PlayInSe(in_se[SPLASH_B].handle);
			}
			else
			{
				if (se_button == false)
				PlayInSe(in_se[SPLASH_V].handle);
			}
		}
		if (chara[i].frame > 59)	//�v���C���[��Idle�t���[����60���傫���ꍇ�v���C���[��Idle�t���[����0�ɂ���
		{
			chara[i].frame = 0;
		}
		break;
	case PLAYER_STATE_RIGHT:
		if (chara[i].frame > 25/*39*/) 			
		{
			if (character == 1)
			{
				StopPlayMem(in_se[SPLASH_B].handle);
			}
			else
			{
				StopPlayMem(in_se[SPLASH_V].handle);
			}
			/*if (se != 0) { StopPlayMem(se_splash_b); }*/
			chara[i].frame = 0;
		}
		break;
	case PLAYER_STATE_LEFT:
		if (chara[i].frame > 25/*39)*/) {
			if (character == 1)
			{
				StopPlayMem(in_se[SPLASH_B].handle);
			}
			else
			{
				StopPlayMem(in_se[SPLASH_V].handle);
			}
			/*if (se != 0) { StopPlayMem(se_splash_b); }*/
			chara[i].frame = 0;
		}
		break;
	case PLAYER_STATE_PARALYSIS:
		if (chara[i].frame > 100)
		{
			chara[i].frame = 0;
			chara[i].state = PLAYER_STATE_IDLE;
		}
		break;
	}

}
void HitCharaChip()
{
		//�v���C���[�̍\���̂�T��
		int i = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);

		// �d�͏���
		chara[i].stand = false;
		if ((chara[i].stand == false) && (chara[i].floor_under == false))
		{
			if (character == 1) {
				chara[i].gr += 0.27;			// �L�����́A�d�͂ɂ������l��傫������
				chara[i].y += chara[i].gr;	// �d�͂ɂ������l�̕������ړ�����
			}
			else {
				chara[i].gr += 0.38;			// �L�����́A�d�͂ɂ������l��傫������
				chara[i].y += chara[i].gr;	// �d�͂ɂ������l�̕������ړ�����
			}
		}


		// �㉺�̓����蔻��
		if (IsHitMapChip(i, 0, chara[i].gr) != 0)
		{
			// ���������B���������̂͒n�ʂ��H�i�d�͒l�̓v���X���������H�j
			if (chara[i].gr > 0)
			{
				chara[i].stand = true;	// �n�ʂɓ��������̂Ńt���O�Z�b�g
				for (int k = 0; k < CHARACTER_MAX; k++)
				{
					chara[k].floor_under = false;
				}
				if (ling_out == 1)
				{
					chara[i].state = PLAYER_STATE_PARALYSIS;
					chara[i].frame = 0;
				}
				ling_out = 0;
			}
			chara[i].gr = 0;		// �d�͂ɂ������l�����Z�b�g
		}
	
}
//�v���C���[�ҋ@���
int PlayerIdle(int i)
{
	PlayerFrameStint(i);
	chara[i].spd_x = 2;
	chara[i].jamp_frame = 0;
	if ((chara[i].stand == true) || (chara[i].floor_under == true))
	{
		if ((gKey & KEYIN_RIGHT) &&
			(gKey &KEYIN_Z) /*&& (chara[i].frame < 30)*/)
		{
			if (
				(chara[i].frame == 30) ||
				(chara[i].frame == 20) ||
				(chara[i].frame == 10) ||
				(chara[i].frame == 0)
				) {
				chara[i].frame = 0;
				InitJamp(i);
				return PLAYER_STATE_JAMP_RIGHT;
			}
		}
	}
	if ((chara[i].stand == true) || (chara[i].floor_under == true))
	{
		if ((gKey & KEYIN_LEFT) &&
			(gKey &KEYIN_Z) /*&& (chara[i].frame < 30)*/)
		{
		
			if (
				(chara[i].frame == 30) ||
				(chara[i].frame == 20) ||
				(chara[i].frame == 10) ||
				(chara[i].frame == 0)
				) {
				chara[i].frame = 0;
				InitJamp(i);
				return PLAYER_STATE_JAMP_LEFT;
			}
		}
	}
	if ((chara[i].stand == true) || (chara[i].floor_under == true))
	{
		if ((gKey &KEYIN_Z)/* && (chara[i].frame < 30)*/)
		{
			if (
				(chara[i].frame == 30) ||
				(chara[i].frame == 20) ||
				(chara[i].frame == 10) ||
				(chara[i].frame == 0)
				) {
				chara[i].frame = 0;
				InitJamp(i);
				return PLAYER_STATE_JAMP;
			}
		}
	}
	if ((chara[i].stand == true) || (chara[i].floor_under == true)) {

		if ((gKey &KEYIN_X) && (chara[i].frame < 30)) {
			chara[i].frame = 0;
			StopInVoice();
			if (character == 1)
			{
				if (voice_button2 == false)
				PlayInSe(in_voice[JUMP_CHARGE_B].handle);
			}
			else
			{
				if (voice_button2 == false)
				PlayInSe(in_voice[JUMP_CHARGE_V].handle);
			}
			if (se_button == false)
			PlayMemBack(in_se[CHARGE_B].handle);
			return PLAYER_STATE_ACCUMULATE_JAMP;
		}
	}
	if ((chara[i].stand == true) || (chara[i].floor_under == true))
	{
		if ((gKey & KEYIN_RIGHT) /*&& (chara[i].frame < 30)*/)
		{
			if (
				(chara[i].frame == 30) ||
				(chara[i].frame == 20) ||
				(chara[i].frame == 10) ||
				(chara[i].frame == 0)
				)
			{
				chara[i].frame = 0;
				/*PlayMemBack(se_splash_b);*/
				
				if (character == 1)
				{
					if (se_button == false)
						PlayMemBack(in_se[SPLASH_B].handle);
				}
				else
				{
					if (se_button == false)
					PlayMemBack(in_se[SPLASH_V].handle);
				}
				return PLAYER_STATE_RIGHT;
			}
		}
	}
	if ((chara[i].stand == true) || (chara[i].floor_under == true))
	{
		if ((gKey & KEYIN_LEFT) /*&& (chara[i].frame < 30)*/)
		{
			if (
				(chara[i].frame == 30) ||
				(chara[i].frame == 20) ||
				(chara[i].frame == 10) ||
				(chara[i].frame == 0)
				) {
				chara[i].frame = 0;
				/*PlayMemBack(se_splash_b);*/
				if (character == 1)
				{
					if (se_button == false)
					PlayMemBack(in_se[SPLASH_B].handle);
				}
				else
				{
					if (se_button == false)
					PlayMemBack(in_se[SPLASH_V].handle);
				}
				return PLAYER_STATE_LEFT;
			}
		}
	}
	

	if (gKey& KEYIN_C)
	{
		tempcg = DrawPrePlayer(i);
		return PLAYER_STATE_PAUSE;
	}


	return PLAYER_STATE_IDLE;
}

int PlayerJamp(int i)
{
	//int se = CheckPlayMem(se_charge_b);					//se���Đ�����Ă��邩
	//if (se != 0) { StopPlayMem(se_charge_b); }
	
	PlayerFrameStint(i);
	if ((chara[i].stand == true) || (chara[i].floor_under == true))
	{
		chara[i].frame = 0;
		return PLAYER_STATE_IDLE;
	}
	if (gKey& KEYIN_C)
	{
		int cg = 0;
		tempcg = DrawPrePlayer(i);
		return PLAYER_STATE_PAUSE;
	}
	return PLAYER_STATE_JAMP;
}
int PlayerRight(int i)
{
	chara[i].jamp_count = -1;
	chara[i].direction = 1;
	PlayerFrameStint(i);
	if (chara[i].frame < 41) {
		chara[i].x += chara[i].spd_x;
	}
	IsHitMapChip(i, 1, 0);		// �E�ɓ������̂ŁAx�ړ��������v���X�w��
	for (int f = 0; f < CHARACTER_MAX; f++)
	{
		if (chara[f].type == CHARACTERTYPE_CRUMBLEFLOOR)
		{
			HitCrumbleFloorPlayer(f, 1,i);
		}
		if (chara[f].type == CHARACTERTYPE_SWITCH_FLOOR)
		{
			HitSwitchFloorPlayer(f, 1, i);
		}
	}
	
	
	if (gKey& KEYIN_C)
	{
		int cg = 0;
		tempcg = DrawPrePlayer(i);
		return PLAYER_STATE_PAUSE;
	}

	if(chara[i].frame == 0)
	{
		chara[i].frame = 0;
		return PLAYER_STATE_IDLE;
	}
		return PLAYER_STATE_RIGHT;
	
}
//�v���C���[���i�ݏ��
int PlayerLeft(int i)
{
	chara[i].jamp_count = -1;
	chara[i].direction = -1;
	PlayerFrameStint(i);
	if (chara[i].frame < 41) {
		chara[i].x -= chara[i].spd_x;
	}
	IsHitMapChip(i, -1, 0);		// ���ɓ������̂ŁAx�ړ��������}�C�i�X�w��
	for (int f = 0; f < CHARACTER_MAX; f++)
	{
		if (chara[f].type == CHARACTERTYPE_CRUMBLEFLOOR)
		{
			HitCrumbleFloorPlayer(f, -1,i);
		}
		if (chara[f].type == CHARACTERTYPE_SWITCH_FLOOR)
		{
			HitSwitchFloorPlayer(f, -1, i);
		}
	}
	
	if (gKey& KEYIN_C)
	{
		int cg = 0;
		tempcg = DrawPrePlayer(i);
		return PLAYER_STATE_PAUSE;
	}
	
		if(chara[i].frame == 0)
		{
			chara[i].frame = 0;
			return PLAYER_STATE_IDLE;
		}
		return PLAYER_STATE_LEFT;
}

int PlayerJampLeft(int i)
{
	chara[i].direction = -1;
	PlayerFrameStint(i);
	
	
	if (gKey&KEYIN_C)
	{
		int cg = 0;
		tempcg = DrawPrePlayer(i);
		return PLAYER_STATE_PAUSE;
	}
	
	if ((chara[i].stand == true) || (chara[i].floor_under == true))
	{
		chara[i].frame = 0;
		return PLAYER_STATE_IDLE;
	}
	chara[i].x -= chara[i].jamp_spd_x;
	IsHitMapChip(i, -1, 0);		// ���ɓ������̂ŁAx�ړ��������}�C�i�X�w��
	for (int f = 0; f < CHARACTER_MAX; f++)
	{
		if (chara[f].type == CHARACTERTYPE_CRUMBLEFLOOR)
		{
			HitCrumbleFloorPlayer(f, -1,i);
		}
		if (chara[f].type == CHARACTERTYPE_SWITCH_FLOOR)
		{
			HitSwitchFloorPlayer(f, -1, i);
		}
	}
	if (chara[i].direction == 1)
	{
		InitJamp(i);
		return PLAYER_STATE_JAMP_RIGHT;
	}
	return PLAYER_STATE_JAMP_LEFT;
}


int PlayerJampRight(int i)
{
	
	chara[i].direction = 1;
	PlayerFrameStint(i);
	
	if (gKey& KEYIN_C)
	{
		int cg = 0;
		tempcg = DrawPrePlayer(i);
		return PLAYER_STATE_PAUSE;
	}
	
	if ((chara[i].stand == true) || (chara[i].floor_under == true))
	{
		chara[i].frame = 0;
		return PLAYER_STATE_IDLE;
	}
	chara[i].x += chara[i].jamp_spd_x;
	IsHitMapChip(i, 1, 0);
	for (int f = 0; f < CHARACTER_MAX; f++)
	{
		
		if (chara[f].type == CHARACTERTYPE_CRUMBLEFLOOR) 
		{
			HitCrumbleFloorPlayer(f, 1,i);
		}
		if (chara[f].type == CHARACTERTYPE_SWITCH_FLOOR)
		{
			HitSwitchFloorPlayer(f, 1, i);
		}
	}
	if (chara[i].direction == -1)
	{
		InitJamp(i);
		return PLAYER_STATE_JAMP_LEFT;
	}
	return PLAYER_STATE_JAMP_RIGHT;
}

void JampPower(int i)
{
	if (chara[i].jamp_frame > 0)
	{
		chara[i].jamp_count = 0;
	}
	if (chara[i].jamp_frame > 74)
	{
		chara[i].jamp_count = 4;
	}
}
int PlayerAccumulateJamp(int i)
{
	//int se = CheckPlayMem(se_charge_b);					//se���Đ�����Ă��邩
	//if (se == 0){PlayMemBack(se_charge_b);}
	
	chara[i].jamp_frame++;
	JampPower(i);
	if (gKey& KEYIN_C)
	{
		//if (se != 0) { StopPlayMem(se_charge_b); }//se���Đ�����Ă������~
		int cg = 0;
		tempcg = DrawPrePlayer(i);
		return PLAYER_STATE_PAUSE;
	}
	if (gKey &KEYIN_X)
	{
		return PLAYER_STATE_ACCUMULATE_JAMP;
	}
	if (gKey &KEYIN_RIGHT)
	{
		//if (se != 0) { StopPlayMem(se_charge_b); }//se���Đ�����Ă������~
		chara[i].jamp_count--;
		InitAccumulateJamp(i);
		
		
		chara[i].frame = 0;
		return PLAYER_STATE_JAMP_RIGHT;
	}
	if (gKey &KEYIN_LEFT)
	{
		//if (se != 0) { StopPlayMem(se_charge_b); }//se���Đ�����Ă������~
		chara[i].jamp_count--;
		
		
		InitAccumulateJamp(i);
		chara[i].frame = 0;
		return PLAYER_STATE_JAMP_LEFT;
	}
	//if (se != 0){StopPlayMem(se_charge_b);}//se���Đ�����Ă������~
	chara[i].jamp_count--;
	
	
	InitAccumulateJamp(i);
	return PLAYER_STATE_JAMP;
}

int PlayerBumper(int i)
{	/*for(int b = 0;b < BUMPER_MAX_2;b++)
{ 
	int k = CheckCharaType(CHARACTERTYPE_BUMPER,b);*/
	PlayerFrameStint(i);
	chara[i].x += chara[i].spd_x;
	if (
		(gNowstage == STAGE_1) ||
		(gNowstage == STAGE_2) ||
		(gNowstage == STAGE_4)
		)
	{
		cv.view_x += chara[i].spd_x;
	}
	IsHitMapChip(i, chara[i].spd_x, 0);
		if(
			(chara[i].stand == true) ||
			(chara[i].floor_under == true)
			)
		{
			chara[i].frame = 0;
			chara[i].spd_x = 2;
			chara[i].gr = 0;
			return PLAYER_STATE_IDLE;
		}
		if (gKey& KEYIN_C) {
			int cg = 0;
			tempcg = DrawPrePlayer(i);
			return PLAYER_STATE_PAUSE;
		}
	return PLAYER_STATE_BUMPER;
}

void HitPlayerMoveFloor(int player,int floor,int direction,double gr)
{
	double x1 = chara[player].x + chara[player].hit_x;
	double y1 = chara[player].y + chara[player].hit_y;
	double w1 = chara[player].hit_w;
	double h1 = chara[player].hit_h;
	double x2 = chara[floor].x + chara[floor].hit_x;
	double y2 = chara[floor].y + chara[floor].hit_y;
	double w2 = chara[floor].hit_w;
	double h2 = chara[floor].hit_h;
	double spd_x;
	double spd_x2 = chara[floor].spd_x;
	double y1_gr = chara[player].y - chara[player].gr;		//�d�͏����O�v���C���[y���W
	double y2_gr = chara[player].y;							//�d�͏�����

	spd_x = 0;
	if (chara[player].state == PLAYER_STATE_LEFT) {
		spd_x = -chara[player].spd_x;
	}
	if (chara[player].state == PLAYER_STATE_RIGHT) {
		spd_x = chara[player].spd_x;
	}
	if (chara[player].state == PLAYER_STATE_JAMP_RIGHT) {
		spd_x = chara[player].jamp_spd_x;
	}
	if (chara[player].state == PLAYER_STATE_JAMP_LEFT) {
		spd_x = -chara[player].jamp_spd_x;
	}
	if (chara[player].state == PLAYER_STATE_BUMPER)
	{
		spd_x = -chara[player].spd_x;
	}
	for (int mf = 0; mf < CHARACTER_MAX; mf++) {
		if (chara[mf].type == CHARACTERTYPE_MOVEFLOOR) {
			if (HitChara(player, mf) == 1) {
				if (chara[mf].floor_under == true) {
					spd_x = chara[mf].spd_x;
					if (chara[player].state == PLAYER_STATE_LEFT) {
						spd_x = -chara[player].spd_x + chara[mf].spd_x;
					}
					if (chara[player].state == PLAYER_STATE_RIGHT) {
						spd_x = chara[player].spd_x + chara[mf].spd_x;
					}
				}
			}
		}
	}

	if (chara[floor].floor_under == true) {
		chara[player].y = y2;
		chara[player].x += chara[floor].spd_x;
		cv.view_x += chara[floor].spd_x;
		chara[player].floor_under = true;
		if (ling_out == 1)
		{
			chara[player].state = PLAYER_STATE_PARALYSIS;
			chara[player].frame = 0;
		}
		ling_out = 0;
		/*	chara[player].gr = 0;*/
		if (HitChara(player, floor) == 0) {

			chara[player].gr = 0;
			chara[floor].floor_under = false;
			chara[player].floor_under = false;
		}
	}
	////���̏��ɏ���Ă��Ȃ����
	if (
		(chara[floor].floor_under == false) &&
		(HitChara(player, floor) == 1)
		) {
		//�v���C���[�����������͒n�ʂɗ����Ă����ꍇ
		if (
			(chara[player].floor_under == true) ||
			(chara[player].stand == true)
			) {
			if (
				(x1 + w1 - spd_x <= x2 - spd_x2) &&
				(x1 + w1 > x2)
				) {
				//�v���C���[�������o��
				chara[player].x = x2 + chara[player].hit_x;
			}
			if (
				(x1 - spd_x >= x2 + w2 - spd_x2) &&
				(x1 < x2 + w2)
				) {
				//�v���C���[�������o��
				chara[player].x = x2 + w2 - chara[player].hit_x;
			}
		}
	}
	if (
		(chara[floor].floor_under == false) &&
		(HitChara(player, floor) == 1)
		) {
		//�ォ�瓖�����Ă�����
		if (
			(y1_gr < y2 - chara[floor].spd_y) &&
			(y2_gr > y2) &&
			(x1 + w1 > x2) &&
			(x1 < x2 + w2)
			) {
			chara[player].y = y2;
			if (ling_out == 1)
			{
				chara[player].state = PLAYER_STATE_PARALYSIS;
				chara[player].frame = 0;
			}
			ling_out = 0;
			chara[floor].floor_under = true;
			chara[player].floor_under = true;
			chara[player].gr = 1;
		}
	}
	if (
		(chara[floor].floor_under == false) &&
		(HitChara(player, floor) == 1)
		) {
		//�����瓖�����Ă�����
		if (
			(y1_gr - h1 > y2 + h2 - chara[floor].spd_y) &&
			(y2_gr - h1 < y2 + h2) &&
			(x1 + w1 > x2) &&
			(x1 < x2 + w2)
			) {
			if (
				(chara[player].floor_under == false) &&
				(chara[floor].floor_under == false)
				)

			{
				chara[player].gr = 5;
				chara[player].y += chara[player].gr;
				if (HitChara(player, floor) == 0) {

					chara[player].gr = 0;
					chara[floor].floor_under = false;
					chara[player].floor_under = false;
				}
			}
		}
	}
	//���̏��Ƀv���C���[�������Ă��Ȃ��ē������Ă�����
	if (
		(chara[floor].floor_under == false) &&
		(HitChara(player, floor) == 1)
		) {
		if (
			(x1 + w1 - spd_x <= x2 - spd_x2) &&
			(x1 + w1 > x2)
			) {
			//�v���C���[�������o��
			chara[player].x = x2 + chara[player].hit_x;
		}
		if (
			(x1 - spd_x >= x2 + w2 - spd_x2) &&
			(x1 < x2 + w2)
			) {
			//�v���C���[�������o��
			chara[player].x = x2 + w2 - chara[player].hit_x;
		}

	}



	
	
}

int PlayerPalalysis(int i)
{
	PlayerFrameStint(i);
	return chara[i].state;
}


//�v���C���[�̏���
int MovePlayer()
{
	
		int i = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);
		
		
		
		switch (chara[i].state)
		{
		case PLAYER_STATE_IDLE:
			temp = chara[i].state;
			chara[i].state = PlayerIdle(i);
			nowstate = STATE_GAME;
			break;
		case PLAYER_STATE_LEFT:
			temp = chara[i].state;
			chara[i].state = PlayerLeft(i);
			nowstate = STATE_GAME;
			break;
		case PLAYER_STATE_RIGHT:
			temp = chara[i].state;
			chara[i].state = PlayerRight(i);
			nowstate = STATE_GAME;
			break;
		case PLAYER_STATE_JAMP:
			temp = chara[i].state;
			chara[i].state = PlayerJamp(i);
			nowstate = STATE_GAME;
			break;
		case PLAYER_STATE_JAMP_LEFT:
			temp = chara[i].state;
			chara[i].state = PlayerJampLeft(i);
			nowstate = STATE_GAME;
			break;
		case PLAYER_STATE_JAMP_RIGHT:
			temp = chara[i].state;
			chara[i].state = PlayerJampRight(i);
			nowstate = STATE_GAME;
			break;
		case PLAYER_STATE_ACCUMULATE_JAMP:
			temp = chara[i].state;
			chara[i].state = PlayerAccumulateJamp(i);
			nowstate = STATE_GAME;
			break;
		case PLAYER_STATE_PAUSE:
			chara[i].state = PLAYER_STATE_PAUSE;
			nowstate = STATE_PAUSE;
			break;
		case PLAYER_STATE_GAMEOVER:
			GameOver();
			break;
		case PLAYER_STATE_GOAL:
			chara[i].state = PLAYER_STATE_GOAL;
			chara[i].frame = 0;
			nowstate = STATE_CLEAR;
			break;
		case PLAYER_STATE_BUMPER:
			chara[i].state = PlayerBumper(i);
			break;
		case PLAYER_STATE_PARALYSIS:
			chara[i].state = PlayerPalalysis(i);
			break;
		default:
			chara[i].state = PlayerIdle(i);
		}
		int size_w = WhereStageW();
		//��ʊO�ɏo���ꍇ�̏���
		switch (gNowstage) {
		case STAGE_1:
		case STAGE_2:
		case STAGE_4:
			if (chara[i].x + chara[i].dx < 0) { chara[i].x = 0 - chara[i].dx; }
			if (chara[i].x - chara[i].dx > size_w * CHIPSIZE_W_STAGE) { chara[i].x = (size_w * CHIPSIZE_W_STAGE) + chara[i].dx; }
			break;
		}
		if (chara[i].y < cv.view_y) { 
			ling_out = 1;
			/*chara[i].hp -= 0.17;*/
			if (lingout == 0)
			{
				
				if (character == 1)
				{

					StopInVoice();
					int no = rand() % 3;
					if (no == 0)
					{
						if (voice_button2 == false)
						PlayMemBack(in_voice[DAMAGE_B_1].handle);
					}
					else if (no == 1)
					{
						if (voice_button2 == false)
						PlayMemBack(in_voice[DAMAGE_B_2].handle);
					}
					else
					{
						if (voice_button2 == false)
						PlayMemBack(in_voice[DAMAGE_B_3].handle);
					}

				}
				else
				{

					StopInVoice();
					int no = rand() % 4;
					if (no == 0)
					{
						if (voice_button2 == false)
						PlayMemBack(in_voice[DAMAGE_V_1].handle);
					}
					else if (no == 1)
					{
						if (voice_button2 == false)
						PlayMemBack(in_voice[DAMAGE_V_2].handle);
					}
					else if (no == 2)
					{
						if (voice_button2 == false)
						PlayMemBack(in_voice[DAMAGE_V_3].handle);
					}
					else
					{
						if (voice_button2 == false)
						PlayMemBack(in_voice[DAMAGE_V_4].handle);
					}
				}
				
				lingout = 1;
			}
		}
		else 
		{
			lingout = 0;
		}
		
			
		
		if (chara[i].y > cv.view_y + DISP_H + chara[i].h) { chara[i].state = PLAYER_STATE_GAMEOVER; }

		//���G��ԏ���
		if (chara[i].hit == HIT)
		{
			chara[i].hit_count++;
			if (((chara[i].hit_count / 9) % 2) == 1)
			{
				chara[i].use = 0;
			}
			if (((chara[i].hit_count / 9) % 2) == 0)
			{
				chara[i].use = 1;
			}
			if (chara[i].hit_count > 89)
			{
				chara[i].hit = NOHIT;
				chara[i].hit_count = 0;
			}
		}
		
		for (int floor = 0; floor < CHARACTER_MAX; floor++)
		{
			if (chara[floor].type == CHARACTERTYPE_MOVEFLOOR)
			{
				//�������Ƃ̓����蔻��
				HitPlayerMoveFloor(i, floor, chara[i].direction, chara[i].gr);
				//�}�b�v�`�b�v�Ƃ̓����蔻��
				IsHitMapChip(i, chara[floor].spd_x, chara[floor].spd_y);
			}
		}

		
	return nowstate;
}
int DrawPrePlayer(int i)
{
	int cg = 0; 
	switch (chara[i].kind)
	{
	case 1:
		switch (chara[i].state)
		{
		case PLAYER_STATE_IDLE:
		case PLAYER_STATE_GOAL:
		case PLAYER_STATE_GAMEOVER:
			if (chara[i].direction == 1)
			{
				if (chara[i].frame < 30)
				{
					cg = cgPlayer[0];
					return cg;
				}
				if ((29 < chara[i].frame) && (chara[i].frame < 60))
				{
					int no = 0;
					no = ((chara[i].frame / PLAYER_PICTURE_MAX) % 5 + 1) * 2;
					cg = cgPlayer[no];
					return cg;
				}
			}
			if (chara[i].direction == -1)
			{
				if (chara[i].frame < 30)
				{
					cg = cgPlayer[1];
					return cg;
				}
				if ((29 < chara[i].frame) && (chara[i].frame < 60))
				{
					int no = 0;
					no = (((chara[i].frame / PLAYER_PICTURE_MAX) % 5 + 1) * 2 + 1);
					cg = cgPlayer[no];
					return cg;
				}
			}
			break;
		case PLAYER_STATE_RIGHT:
		{
			int no = 0;
			no = ((chara[i].frame / 2 % PLAYER_PICTURE_JAMP_B_MAX) * 2);
			cg = cgjump_b[no];
			return cg;
		}
		break;
		case PLAYER_STATE_LEFT:
		{
			int no = 0;
			no = ((chara[i].frame / 2 % PLAYER_PICTURE_JAMP_B_MAX) * 2 + 1);
			cg = cgjump_b[no];
			return cg;
		}
		break;
		case PLAYER_STATE_JAMP:
		case PLAYER_STATE_JAMP_LEFT:
		case PLAYER_STATE_JAMP_RIGHT:
		case PLAYER_STATE_BUMPER:
		{
			int no = 0;
			if (chara[i].direction == 1)
			{
				no = ((chara[i].frame / 5 % PLAYER_PICTURE_JAMP_B_MAX) * 2);
				if (chara[i].frame > 64)
				{
					no = 12 * 2;
				}
			}
			if (chara[i].direction == -1)
			{
				no = ((chara[i].frame / 5 % PLAYER_PICTURE_JAMP_B_MAX) * 2 + 1);
				if (chara[i].frame > 64)
				{
					no = 12 * 2 + 1;
				}
			}

			cg = cgjump_b[no];
			no = 0;
			if (chara[i].jamp_count == 4)
			{
				if (chara[i].direction == 1)
				{
					no = ((chara[i].frame / 5 % PLAYER_PICTURE_HIGH_B_MAX) * 2);
					if (chara[i].frame > 99)
					{
						no = 38;
					}
				}
				if (chara[i].direction == -1)
				{
					no = ((chara[i].frame / 5 % PLAYER_PICTURE_HIGH_B_MAX) * 2 + 1);
					if (chara[i].frame > 99)
					{
						no = 39;
					}

				}
				cg = cgjump_high_b[no];
			}

			return cg;
			break;
		}
		case PLAYER_STATE_ACCUMULATE_JAMP:
		{
			int no = 0;
			if (chara[i].direction == 1)
			{

				no = 0;
				cg = cgPlayer[no];
			}
			if (chara[i].direction == -1)
			{
				no = 1;
				cg = cgPlayer[no];
			}

			return cg;
			break;
		}
		case PLAYER_STATE_PAUSE:
			cg = tempcg;
			return cg;
			break;
		}
		case PLAYER_STATE_PARALYSIS:
		{
			int no = 0;
			if (chara[i].direction == 1)
			{
				no = (((chara[i].frame / 5) % 2) * 2);
			}
			if (chara[i].direction == -1)
			{
				no = (((chara[i].frame / 5) % 2) * 2 + 1);
			}
			cg = cg_n_b[no];
			return cg;
			break;
		}
		break;

		case 2:
			switch (chara[i].state)
			{

			case PLAYER_STATE_IDLE:
			case PLAYER_STATE_GOAL:
			case PLAYER_STATE_GAMEOVER:
				if (chara[i].direction == 1)
				{
					if (chara[i].frame < 30)
					{
						cg = cgPlayer2[0];
						return cg;
					}
					if ((29 < chara[i].frame) && (chara[i].frame < 60))
					{
						int no = 0;
						no = ((chara[i].frame / PLAYER2_PICTURE_MAX) % 5 + 1) * 2;
						cg = cgPlayer2[no];
						return cg;
					}
				}
				if (chara[i].direction == -1)
				{
					if (chara[i].frame < 30)
					{
						cg = cgPlayer2[1];
						return cg;
					}
					if ((29 < chara[i].frame) && (chara[i].frame < 60))
					{
						int no = 0;
						no = (((chara[i].frame / PLAYER2_PICTURE_MAX) % 5 + 1) * 2 + 1);
						cg = cgPlayer2[no];
						return cg;
					}
				}
				break;
			case PLAYER_STATE_RIGHT:
			{
				int no = 0;
				no = ((chara[i].frame / 2 % PLAYER2_PICTURE_JAMP_B_MAX) * 2);
				cg = cgjump_b2[no];
				return cg;
			}
			break;
			case PLAYER_STATE_LEFT:
			{
				int no = 0;
				no = ((chara[i].frame / 2 % PLAYER2_PICTURE_JAMP_B_MAX) * 2 + 1);
				cg = cgjump_b2[no];
				return cg;
			}
			break;
			case PLAYER_STATE_JAMP:
			case PLAYER_STATE_JAMP_LEFT:
			case PLAYER_STATE_JAMP_RIGHT:
			case PLAYER_STATE_BUMPER:
			{
				int no = 0;
				if (chara[i].direction == 1)
				{
					no = ((chara[i].frame / 5 % PLAYER2_PICTURE_JAMP_B_MAX) * 2);
					if (chara[i].frame > 64)
					{
						no = 12 * 2;
					}
				}
				if (chara[i].direction == -1)
				{
					no = ((chara[i].frame / 5 % PLAYER2_PICTURE_JAMP_B_MAX) * 2 + 1);
					if (chara[i].frame > 64)
					{
						no = 12 * 2 + 1;
					}
				}

				cg = cgjump_b2[no];
				no = 0;
				if (chara[i].jamp_count == 4)
				{
					if (chara[i].direction == 1)
					{
						no = ((chara[i].frame / 5 % PLAYER2_PICTURE_HIGH_B_MAX) * 2);
						if (chara[i].frame > 99)
						{
							no = 38;
						}
					}
					if (chara[i].direction == -1)
					{
						no = ((chara[i].frame / 5 % PLAYER2_PICTURE_HIGH_B_MAX) * 2 + 1);
						if (chara[i].frame > 99)
						{
							no = 39;
						}

					}
					cg = cgjump_high_b2[no];
				}

				return cg;
				break;
			}
			case PLAYER_STATE_ACCUMULATE_JAMP:
			{
				int no = 0;
				if (chara[i].direction == 1)
				{

					no = 0;
					cg = cgPlayer2[no];
				}
				if (chara[i].direction == -1)
				{
					no = 1;
					cg = cgPlayer2[no];
				}

				return cg;
				break;
			}
			case PLAYER_STATE_PAUSE:
			{
				cg = tempcg;
				return cg;
				break;
			}
			case PLAYER_STATE_PARALYSIS:
			{
				int no = 0;
				if (chara[i].direction == 1)
				{
				no = (((chara[i].frame / 5) % 2)*2);
				}
				if (chara[i].direction == -1)
				{
				no = (((chara[i].frame / 5) % 2) * 2 + 1);
				}
				cg = cg_n_v[no];
				return cg;
				break;
			}
			break;
			}
			
	}
	return cg;
}
