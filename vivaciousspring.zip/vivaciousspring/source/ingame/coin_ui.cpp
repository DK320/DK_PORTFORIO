#include"coin_ui.h"
#include"../amgame.h"
#include	<Windows.h>
#include"../AmHelper.h"
#include"vivacious_spring.h"
#include"../outgame/charselect.h"
#include"../system/common.h"
int cg_coin_ui = 0;
int cg_coin_number[CG_COIN_NUMBER_W_NUM*CG_COIN_NUMBER_H_NUM] = { 0 };
bool hit_coin_b = false;
bool hit_coin_v = false;
COIN_UI co;
COIN_NUMBER co_num_b[COIN_NUMBER_MAX];
COIN_NUMBER co_num_v[COIN_NUMBER_MAX];

void LoadCoinUi()
{
	cg_coin_ui = LoadTexture("res/coin_collect.png");
	LoadBlkTexture(
	"res/number_coin_collect.png",
		(CG_COIN_NUMBER_W / CG_COIN_NUMBER_W_NUM),
		(CG_COIN_NUMBER_H / CG_COIN_NUMBER_H_NUM),
		CG_COIN_NUMBER_W_NUM, CG_COIN_NUMBER_H_NUM,
		(CG_COIN_NUMBER_W_NUM*CG_COIN_NUMBER_H_NUM),
		cg_coin_number
	);

}

void InitCoinUi()
{
	GetPictureSize(cg_coin_ui,&co.w, &co.h);
	/*co.x = DISP_W + co.w;*/
	co.x = 535;
	co.y = 40;
	for (int i = 0; i < COIN_NUMBER_MAX; i++)
	{
		if (i == 0)
		{
			co_num_b[i].x = 601;
			co_num_v[i].x = 601;
		}
		else
		{
			co_num_b[i].x = co_num_b[0].x + (30 * i);
			co_num_v[i].x = co_num_v[0].x + (30 * i);
		}

		co_num_b[i].y = 40;
		co_num_v[i].y = 40;
		co_num_b[i].no = 0;
		co_num_v[i].no = 0;
	}
	
}




void ProcessCoinUi()
{
	
	
	if (hit_coin_b == true)
	{
		co_num_b[2].no++;
		if (co_num_b[2].no > 9)
		{
			co_num_b[2].no = 0;
			co_num_b[1].no++;
		}
		if (co_num_b[1].no > 9)
		{
			co_num_b[1].no = 0;
			co_num_b[0].no++;
		}
		hit_coin_b = false;
	}
	if (hit_coin_v == true)
	{
		co_num_v[2].no++;
		if (co_num_v[2].no > 9)
		{
			co_num_v[2].no = 0;
			co_num_v[1].no++;
		}
		if (co_num_v[1].no > 9)
		{
			co_num_v[1].no = 0;
			co_num_v[0].no++;
		}
		hit_coin_v = false;
	}



}
void DrawCoinUi()
{
	SetDrawArea(0,0,DISP_W,DISP_H);
	DrawMemTh(co.x, co.y, cg_coin_ui);
	for (int i = 0; i < COIN_NUMBER_MAX; i++)
	{
		if (character == 1)
		{
			DrawMemTh(co_num_b[i].x, co_num_b[i].y, cg_coin_number[co_num_b[i].no]);
		}
		else 
		{
			DrawMemTh(co_num_v[i].x, co_num_v[i].y, cg_coin_number[co_num_v[i].no]);
		}
	}
}