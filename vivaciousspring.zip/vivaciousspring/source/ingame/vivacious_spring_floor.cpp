#include	"../amgame.h"
#include	"../system/common.h"
#include	"vivacious_spring_player.h"
#include	"vivacious_spring.h"
#include	"../utility.h"
#include	"vivacious_spring_floor.h"
#include	"vivacious_spring_camera.h"
#include	"vivacious_spring_game.h"
#include	"../system/vivacious_spring_se.h"
#include	"vivacious_spring_switch.h"
#include	"vivacious_spring_geyser.h"
#include	"vivacious_spring_mapdata1.h"
#include	"../outgame/game_setting.h"


int cg_switch_2_land_200_40 = 0;
int cg_switch_3_land_80_40 = 0;
int cg_switch_3_land_560_40 = 0;


int cg_gimmick_crumble_land_80_40 = 0;
int cg_gimmick_crumble_land_120_40 = 0;
int cg_gimmick_crumble_land_160_40 = 0;
int cg_gimmick_crumble_land_200_40 = 0;
int cg_gimmick_crumble_land_240_40 = 0;
int cg_gimmick_crumble_land_280_40 = 0;
int cg_gimmick_crumble_land_280_440 = 0;
int cg_gimmick_crumble_land_40_400 = 0;
int cg_gimmick_crumble_land_40_520 = 0;
int cg_gimmick_crumble_land_40_1200 = 0;

int cg_gimmick_move_land_280_520 = 0;
int cg_gimmick_move_land_280_240 = 0;
int cg_gimmick_move_land_200_40 = 0;
int cg_gimmick_move_land_160_40 = 0;
int cg_gimmick_move_land_120_40 = 0;
int cg_gimmick_move_land_40_40 = 0;
int cg_gimmick_move_land_40_280 = 0;
int cg_gimmick_move_land_80_40 = 0;
int cg_gimmick_move_land_40_200 = 0;
int cg_gimmick_move_land_40_160 = 0;
int cg_gimmick_move_land_40_80 = 0;
int cg_gimmick_move_land_1280_120 = 0;

//�S��D.K
//��������
void LoadFloor()
{

	cg_switch_2_land_200_40 = LoadTexture("res/switch_2_land_200_40.png");
	cg_switch_3_land_80_40 = LoadTexture("res/switch_3_land_80_40.png");
	cg_switch_3_land_560_40 = LoadTexture("res/switch_3_land_560_40.png");

	cg_gimmick_crumble_land_80_40 = LoadTexture("res/gimmick_crumble_land_80_40.png");
	cg_gimmick_crumble_land_120_40 = LoadTexture("res/gimmick_crumble_land_120_40.png");
	cg_gimmick_crumble_land_160_40 = LoadTexture("res/gimmick_crumble_land_160_40.png");
	cg_gimmick_crumble_land_200_40 = LoadTexture("res/gimmick_crumble_land_200_40.png");
	cg_gimmick_crumble_land_240_40 = LoadTexture("res/gimmick_crumble_land_240_40.png");
	cg_gimmick_crumble_land_280_40 = LoadTexture("res/gimmick_crumble_land_280_40.png");
	cg_gimmick_crumble_land_280_440 = LoadTexture("res/gimmick_crumble_land_280_440.png");
	cg_gimmick_crumble_land_40_400 = LoadTexture("res/gimmick_crumble_land_40_400.png");
	cg_gimmick_crumble_land_40_520 = LoadTexture("res/gimmick_crumble_land_40_520.png");
	cg_gimmick_crumble_land_40_1200 = LoadTexture("res/gimmick_crumble_land_40_1200.png");


	cg_gimmick_move_land_280_520 = LoadTexture("res/gimmick_move_land_280_520.png");
	cg_gimmick_move_land_280_240 = LoadTexture("res/gimmick_move_land_280_240.png");
	cg_gimmick_move_land_200_40 = LoadTexture("res/gimmick_move_land_200_40.png");	
	cg_gimmick_move_land_160_40 = LoadTexture("res/gimmick_move_land_160_40.png");	
	cg_gimmick_move_land_120_40 = LoadTexture("res/gimmick_move_land_120_40.png");	
	cg_gimmick_move_land_40_40 = LoadTexture("res/gimmick_move_land_40_40.png");	
	cg_gimmick_move_land_40_280 = LoadTexture("res/gimmick_move_land_40_280.png");	
	cg_gimmick_move_land_80_40 = LoadTexture("res/gimmick_move_land_80_40.png");
	cg_gimmick_move_land_40_200 = LoadTexture("res/gimmick_move_land_40_200.png");
	cg_gimmick_move_land_40_160 = LoadTexture("res/gimmick_move_land_40_160.png");
	cg_gimmick_move_land_40_80 = LoadTexture("res/gimmick_move_land_40_80.png");
	cg_gimmick_move_land_1280_120 = LoadTexture("res/gimmick_move_land_1280_120.png");
}


int MoveFloorCg(int kind)
{
	switch (kind)
	{
	case MOVEFLOOR_280_520:
		return cg_gimmick_move_land_280_520;
		break;
	case MOVEFLOOR_200_40:
		return cg_gimmick_move_land_200_40;
		break;
	case MOVEFLOOR_280_240:
		return cg_gimmick_move_land_280_240;
		break;
	case MOVEFLOOR_160_40:
		return cg_gimmick_move_land_160_40;
		break;
	case MOVEFLOOR_40_40:
		return cg_gimmick_move_land_40_40;
		break;
	case MOVEFLOOR_40_280:
		return cg_gimmick_move_land_40_280;
		break;
	case MOVEFLOOR_120_40:
		return cg_gimmick_move_land_120_40;
		break;
	case MOVEFLOOR_80_40:
		return cg_gimmick_move_land_80_40;
		break;
	case MOVEFLOOR_40_200:
		return cg_gimmick_move_land_40_200;
		break;
	case MOVEFLOOR_40_160:
		return cg_gimmick_move_land_40_160;
		break;
	case MOVEFLOOR_40_80:
		return cg_gimmick_move_land_40_80;
		break;
	case MOVEFLOOR_1280_120:
		return cg_gimmick_move_land_1280_120;
		break;
		
	}
	return -1;
}

int CgSwitchFloor(int kind)
{
	switch (kind)
	{
	case SF2_200_40:
		return cg_switch_2_land_200_40;
		break;
	case SF3_560_40:
		return cg_switch_3_land_560_40;
		break;
	case SF3_80_40:
		return cg_switch_3_land_80_40;
		break;
	
	}
	return - 1;
}


void InitSwitchFloor()
{
	int cg = 0;

	cg = CgSwitchFloor(SF2_200_40);
	InitChara(
		STAGE_2,CHARACTERTYPE_SWITCH_FLOOR, cg,
		14800,440 + 560,0,0,0,1,0,0,-100,-40 ,200,40,0,0,0
	);

	int kind3[SF3_MAX]=
	{
		SF3_560_40,SF3_80_40,SF3_80_40,
	};
	int x3[SF3_MAX]=
	{
		560,400,680
	};
	int y3[SF3_MAX]=
	{
		3960,22880,22960
	};
	for (int i = 0; i < SF3_MAX; i++)
	{
		cg = CgSwitchFloor(kind3[i]);
		InitChara(
			STAGE_3, CHARACTERTYPE_SWITCH_FLOOR,cg,
			x3[i],y3[i] + 40,0,0,0,0,0,0,0,0,0,0,i,0,kind3[i]
			);
	}
}
void ProcessSwitchGimmick()
{
	int floor;
	int sw;
	int mf;
	int geyser;
	int parts;
	
	
	
		int player = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);
		switch (gNowstage)
		{
		case STAGE_2:
		{
			floor = CheckCharaType(CHARACTERTYPE_SWITCH_FLOOR, 0);
			sw = CheckCharaType(CHARACTERTYPE_SWITCH, 0);
			if (chara[sw].hit == 1)
			{
				chara[floor].use = 0;
			}
			HitSwitchFloorPlayer(floor, 0, player);
		}
		break;
		case STAGE_3:
		{
			for (int i = 0; i < SWITCH_MAX_3; i++)
			{
				for (int k = 0; k < SF3_MAX; k++)
				{

					floor = CheckCharaType(CHARACTERTYPE_SWITCH_FLOOR, k);
					sw = CheckCharaType(CHARACTERTYPE_SWITCH, i);
					switch (chara[sw].kind)
					{
					case 1:
						switch (chara[sw].no)
						{
						case 0:
							if (chara[sw].hit == 1)
							{
								if (chara[floor].kind == SF3_560_40)
								{
									chara[floor].use = 1;
								}
							}
							break;
						case 1:
							for (int g_no = 0; g_no < GEYSER_MAX_3; g_no++)
							{
								geyser = CheckCharaType(CHARACTERTYPE_GEYSER, g_no);
								if (chara[sw].hit == 1)
								{
									if (chara[geyser].kind == G325_80)
									{
										chara[geyser].use = 0;
									}
								}
							}
							break;
						case 2:
							parts = CheckCharaType(CHARACTERTYPE_PARTS, 3);
							if (chara[sw].hit == 1)
							{
								chara[parts].use = 1;
							}
							break;
						case 3:
							mf = CheckCharaType(CHARACTERTYPE_MOVEFLOOR, 34);
							if (chara[sw].hit == 1)
							{
								chara[mf].spd_y = 2;
							}
							break;
						case 4:
							if (chara[sw].hit == 1)
							{
								if (chara[floor].kind == SF3_80_40)
								{
									chara[floor].use = 1;
								}
							}
							break;
						}
						break;
					}
					HitSwitchFloorPlayer(floor, 0, player);
				}
			}
		}
		break;


		}
		
}

void HitSwitchFloorPlayer(int floor,int mx,int player)
{
	
	if (
		(chara[floor].floor_under == false)&&
		(chara[player].stand == false)&&
		(chara[floor].use == 1)
		)
	{
			if (HitChara(player, floor) == 1)
			{
				//�v���C���[�����ɓ����Ă����ꍇ
				if (mx < 0)
				{
					chara[player].x = chara[floor].x - chara[floor].hit_x - chara[player].hit_x;
				}
				//�v���C���[���E�ɓ����Ă����ꍇ
				if (mx > 0)
				{
					chara[player].x = chara[floor].x + chara[floor].hit_x + chara[player].hit_x;
				}

			//�����瓖�������ꍇ
				if (
					(chara[player].y + chara[player].hit_y < chara[floor].y) &&
					(chara[player].y + chara[player].hit_y > chara[floor].y + chara[floor].hit_y) &&
					(chara[player].x + chara[player].hit_x < chara[floor].x - chara[floor].hit_x) &&
					(chara[player].x - chara[player].hit_x > chara[floor].x + chara[floor].hit_x)
					)
				{
					chara[player].y = chara[floor].y - chara[player].hit_y;
					chara[player].gr = 5;
				}

				//�ォ�瓖�������ꍇ
				if (
					(chara[player].y < chara[floor].y) &&
					(chara[player].y > chara[floor].y + chara[floor].hit_y - 1) &&
					(chara[player].x + chara[player].hit_x < chara[floor].x - chara[floor].hit_x) &&
					(chara[player].x - chara[player].hit_x > chara[floor].x + chara[floor].hit_x)
					)
				{

					chara[player].floor_under = true;
					chara[floor].floor_under = true;
					if (ling_out == 1)
					{
						chara[player].state = PLAYER_STATE_PARALYSIS;
						chara[player].frame = 0;
					}
					ling_out = 0;
				}

				
			}

		
	}
	//���̏��Ƀv���C���[�������Ă���Ƃ�
	if (
		(chara[floor].floor_under == true)
		/*(chara[player].floor_under == true)*/
		) {
		chara[player].floor_under = true;
		if (ling_out == 1)
		{
			chara[player].state = PLAYER_STATE_PARALYSIS;
			chara[player].frame = 0;
		}
		ling_out = 0;
		chara[player].y = chara[floor].y + chara[floor].hit_y;
		if (HitChara(player, floor) == 0) {
			chara[player].floor_under = false;
			chara[floor].floor_under = false;
			chara[player].gr = 0;
		}
	}
}


int HitSwitchFloorMovefloor(int id)
{
	int switch_floor = CheckCharaType(CHARACTERTYPE_SWITCH_FLOOR, 0);
	if (chara[switch_floor].use == 1)
	{
		if (HitChara(id, switch_floor) == 1)
		{
			return 0;
		}
	}
	else
	{
		if (chara[id].spd_x == 2)
		{
			return 2;
		}
		return -2;
	}
	return 0;
}


int MoveFloorSpeed(int i)
{
	int speed_x2[MOVEFLOOR_MAX_2] =
	{
		0,
		-3,
		3,
		2,
		2,
		0
	};
	return speed_x2[i];
}

int MoveFloorMax()
{
	switch (gNowstage)
	{
	case STAGE_1:
		return MOVEFLOOR_MAX_1;
		break;
	case STAGE_2:
		return MOVEFLOOR_MAX_2;
		break;
	case STAGE_3:
		return MOVEFLOOR_MAX_3;
		break;
	case STAGE_4:
		return MOVEFLOOR_MAX_4;
		break;

	}
	return -1;
}
//�e�X�e�[�W�̕���鏰�̐�
int CrumbleMax() {
	switch (gNowstage) {
	case STAGE_1:
		return CRUMBLE_MAX_1;
		break;
	case STAGE_2:
		return CRUMBLE_MAX_2;
		break;
	case STAGE_3:
		return CRUMBLE_MAX_3;
		break;
	case STAGE_4:
		return CRUMBLE_MAX_4;
		break;
	}
	return-1;
}

void InitMovefloor()
{
	int x1[MOVEFLOOR_MAX_1]=
	{
		2520,7440,7440,7440
	};
	int y1[MOVEFLOOR_MAX_1]=
	{
		200 + 560,-40 + 560,240 + 560,520 + 560
	};
	int kind[MOVEFLOOR_MAX_1]=
	{
		MOVEFLOOR_280_520,
		 MOVEFLOOR_200_40, MOVEFLOOR_200_40, MOVEFLOOR_200_40
	};
	int x2[MOVEFLOOR_MAX_2] =
	{
		9800,
		10120,
		10320,
		12080,
		12080,
		15000
	};
	int y2[MOVEFLOOR_MAX_2] =
	{
		1040,
		360,
		280,
		200,
		320,
		440
	};
	int kind2[MOVEFLOOR_MAX_2] =
	{
		MOVEFLOOR_280_240,
		MOVEFLOOR_160_40,
		MOVEFLOOR_200_40,
		MOVEFLOOR_40_40,
		MOVEFLOOR_40_280,
		MOVEFLOOR_120_40,
	};
	int speed_x2[MOVEFLOOR_MAX_2] =
	{
		0,
		0,
		0,
		2,
		2,
		0
	};
	int speed_y2[MOVEFLOOR_MAX_2] =
	{
		2,
		0,
		0,
		0,
		0,
		0
	};
	int x3[MOVEFLOOR_MAX_3]=
	{
		920,

		1000,0,

		920,920,

		920,0,1200,1120,800,
		960,1200,720,

		920,920,920,400,520,
		640,920,1120,40,440,
		400,600,880,400,760,
		840,120,120,120,360,
		80,160,

		80,240,120,0,640,
		0,1280-160,560,280,

		0
	};
	int y3[MOVEFLOOR_MAX_3] =
	{
		2920,
		1920,22440,
		2600,3360,
		
		2200,2640,4960,6840,7360,
		7480,8600,22120,
		
		1080,1320,1560,1680,1680,
		1680,1800,2120,4560,5520,
		7240,7680,9600,10080,11280,
		12640,13280,13440,13600,14760,
		15600,18600,

		2480,4640,8200,19160,19360,
		19560,19760,21640,22600,

		6080
	};
	int kind3[MOVEFLOOR_MAX_3]=
	{
		MOVEFLOOR_40_80,

		MOVEFLOOR_40_160,MOVEFLOOR_40_160,

		MOVEFLOOR_40_200,MOVEFLOOR_40_200,

		MOVEFLOOR_80_40,MOVEFLOOR_80_40,MOVEFLOOR_80_40,MOVEFLOOR_80_40,MOVEFLOOR_80_40,
		MOVEFLOOR_80_40,MOVEFLOOR_80_40,MOVEFLOOR_80_40,

		MOVEFLOOR_120_40,MOVEFLOOR_120_40,MOVEFLOOR_120_40,MOVEFLOOR_120_40,MOVEFLOOR_120_40,
		MOVEFLOOR_120_40,MOVEFLOOR_120_40,MOVEFLOOR_120_40,MOVEFLOOR_120_40,MOVEFLOOR_120_40,
		MOVEFLOOR_120_40,MOVEFLOOR_120_40,MOVEFLOOR_120_40,MOVEFLOOR_120_40,MOVEFLOOR_120_40,
		MOVEFLOOR_120_40,MOVEFLOOR_120_40,MOVEFLOOR_120_40,MOVEFLOOR_120_40,MOVEFLOOR_120_40,
		MOVEFLOOR_120_40,MOVEFLOOR_120_40,

		MOVEFLOOR_160_40,MOVEFLOOR_160_40,MOVEFLOOR_160_40,MOVEFLOOR_160_40,MOVEFLOOR_160_40,
		MOVEFLOOR_160_40,MOVEFLOOR_160_40,MOVEFLOOR_160_40,MOVEFLOOR_160_40,
		MOVEFLOOR_1280_120
	};
	int speed_x3[MOVEFLOOR_MAX_3]=
	{
		2,

		2,2,

		2,2,

		2,2,0,0,
		0,0,0,0,

		2,2,2,0,0,
		0,2,0,0,2,
		0,0,0,0,0,
		0,2,2,2,0,
		2,0,

		2,2,0,2,2,
		2,2,0,2,

		2
	};
	int speed_y3[MOVEFLOOR_MAX_3] =
	{
		0,

		0,0,

		0,0,

		0,0,2,2,
		2,2,2,2,

		0,0,0,2,2,
		2,0,2,2,0,
		2,2,2,2,2,
		2,0,0,0,2,
		0,0,

		0,0,2,0,0,
		0,0,2,0,

		0
	};
	int x4[MOVEFLOOR_MAX_4]=
	{
		760,800,800,1120,1240,

		600,880,3080,3080,

		560,2120,5200,
	};

	int y4[MOVEFLOOR_MAX_4]=
	{
		1360,160,360,1360,1520,

		1560,1280,2960,3560,

		1000,1400,1320
	};

	int kind4[MOVEFLOOR_MAX_4]=
	{
		MOVEFLOOR_80_40,MOVEFLOOR_80_40,MOVEFLOOR_80_40,MOVEFLOOR_80_40,MOVEFLOOR_80_40,

		MOVEFLOOR_120_40,MOVEFLOOR_120_40,MOVEFLOOR_120_40,MOVEFLOOR_120_40,

		MOVEFLOOR_160_40,MOVEFLOOR_160_40,MOVEFLOOR_160_40
	};

	int speed_x_4[MOVEFLOOR_MAX_4]=
	{
		0,2,2,0,0,

		0,0,0,2,

		2,0,0
	};
	int speed_y_4[MOVEFLOOR_MAX_4] =
	{
		2,0,0,2,2,

		2,2,2,0,

		0,2,2
	};


	int movefloor_max = MoveFloorMax();
	for (int i = 0; i < movefloor_max;i++)
	{
		int cg = MoveFloorCg(kind[i]);
		InitChara(
		STAGE_1, CHARACTERTYPE_MOVEFLOOR,cg,
		x1[i],y1[i],0,2,0,1,0,0,
			0,0,0,0,
		i,0,kind[i]
		);

		cg = MoveFloorCg(kind2[i]);
		InitChara(
			STAGE_2, CHARACTERTYPE_MOVEFLOOR, cg,
			x2[i], y2[i] + 560, speed_x2[i], speed_y2[i], 0, 1, 0, 0,
			0, 0, 0, 0,
			i, 0, kind2[i]
		);

		cg = MoveFloorCg(kind3[i]);
		InitChara(
			STAGE_3, CHARACTERTYPE_MOVEFLOOR, cg,
			x3[i], y3[i]+ 40, speed_x3[i], speed_y3[i],  0, 1, 0, 0,
			0, 0, 0, 0,
			i, 0, kind3[i]
		);
		cg = MoveFloorCg(kind4[i]);
		InitChara(
			STAGE_4, CHARACTERTYPE_MOVEFLOOR, cg,
			x4[i], y4[i] + 800, speed_x_4[i], speed_y_4[i], 0, 1, 0, 0,
			0, 0, 0, 0,
			i, 0, kind4[i]
		);
		/*int mf = CheckCharaType(CHARACTERTYPE_MOVEFLOOR, i);
		chara[mf].hit_y = chara[mf].hit_y - 1;*/
	}
}





int CrumbleFloorCg(int kind)
{
	switch (kind)
	{
	case CRUMBLEFLOOR_80_40:
		return cg_gimmick_crumble_land_80_40;
		break;
	case CRUMBLEFLOOR_120_40:
		return cg_gimmick_crumble_land_120_40;
		break;
	case CRUMBLEFLOOR_160_40:
		return cg_gimmick_crumble_land_160_40;
		break;
	case CRUMBLEFLOOR_200_40:
		return cg_gimmick_crumble_land_200_40;
		break;
	case CRUMBLEFLOOR_240_40:
		return cg_gimmick_crumble_land_240_40;
		break;
	case CRUMBLEFLOOR_280_40:
		return cg_gimmick_crumble_land_280_40;
		break;
	case CRUMBLEFLOOR_280_440:
		return cg_gimmick_crumble_land_280_440;
		break;
	case CRUMBLEFLOOR_40_1200:
		return cg_gimmick_crumble_land_40_1200;
		break;
	case CRUMBLEFLOOR_40_400:
		return cg_gimmick_crumble_land_40_400;
		break;
	case CRUMBLEFLOOR_40_520:
		return cg_gimmick_crumble_land_40_520;
		break;
	}
	return -1;
}



//�͈͂̍���		x,y
//�͈͂̕��ƍ���	w,h
//����ID			id
//���̓����X�s�[�h	speed
//�p�^�[��			pattern	
//1	����
//2	�[�ɂ����猳�̏ꏊ���畜��
//3	�[�ɂ����瓮���Ȃ�
int  FloorRangeMove(int x,int y,int w,int h,int id,int speed,int pattern)
{
	y = y + cv.view_y;
	int xw = x + w;
	int yh = y + h;
	if (pattern == 1)
	{
		if (
			(speed > 0) ||
			(speed < 0)
			) 
		{
			if (chara[id].x - chara[id].dx > xw) { chara[id].x = xw + chara[id].dx;	speed = -speed; }
			if (chara[id].x + chara[id].dx < x) { chara[id].x = x - chara[id].dx;	speed = -speed; }
			if (chara[id].y > yh) { chara[id].y = yh;				speed = -speed; }
			if (chara[id].y + chara[id].dy < y) { chara[id].y = y - chara[id].dy;	speed = -speed; }
		}
		else 
		{
			return 0;
		}
	}
	if (pattern == 2)
	{
		if (chara[id].x - chara[id].dx > xw)	{ chara[id].x = x - chara[id].dx;	}
		if (chara[id].x + chara[id].dx < x)		{ chara[id].x = xw + chara[id].dx;	}
		if (chara[id].y > yh)					{ chara[id].y = y - chara[id].dy;	}
		if (chara[id].y + chara[id].dy < y)		{ chara[id].y = yh + chara[id].dy;	}
	}
	if (pattern == 3)
	{
		if (chara[id].x - chara[id].dx > xw)	{ chara[id].x = xw + chara[id].dx;	}
		if (chara[id].x + chara[id].dx < x)		{ chara[id].x = x - chara[id].dx;	}
		if (chara[id].y > yh)					{ chara[id].y = yh;					}
		if (chara[id].y + chara[id].dy < y)		{ chara[id].y = y - chara[id].dy;	}
	}
	return speed;
}

void MoveFloorCalcu(int id)
{
	chara[id].x += chara[id].spd_x;
	chara[id].y += chara[id].spd_y;
}

void HitMoveFloorPlayery(int floor,int player)
{
	
	if (
		(chara[floor].floor_under == false)&&
		(chara[player].stand == false)
		)
	{
		if (HitChara(player, floor) == 1)
		{
			//�ォ�瓖�����Ă�����

			/*if (chara[player].y  < chara[floor].y )
			{
				
				chara[player].floor_under = true;
				chara[floor].floor_under = true;
				chara[player].gr = 1;
			}*/
			if (
				(chara[player].y < chara[floor].y) &&
				(chara[player].y > chara[floor].y + chara[floor].hit_y - 1) &&
				(chara[player].x + chara[player].hit_x < chara[floor].x - chara[floor].hit_x) &&
				(chara[player].x - chara[player].hit_x > chara[floor].x + chara[floor].hit_x)
				)
			{
				if (ling_out == 1)
				{
					chara[player].state = PLAYER_STATE_PARALYSIS;
					chara[player].frame = 0;
				}
				ling_out = 0;
				chara[player].floor_under = true;
				chara[floor].floor_under = true;
				chara[player].gr = 1;

			}
			if (
				(chara[player].state == PLAYER_STATE_JAMP) ||
				(chara[player].state == PLAYER_STATE_JAMP_RIGHT) ||
				(chara[player].state == PLAYER_STATE_JAMP_LEFT) ||
				(chara[player].state == PLAYER_STATE_ACCUMULATE_JAMP)
				)
			{
				//�����瓖�����Ă�����
				/*if (chara[player].y  > chara[floor].y)
				{
					chara[player].y = chara[floor].y - chara[player].hit_y;
					chara[player].gr = 5;
				}*/
				if (
					(chara[player].y + chara[player].hit_y < chara[floor].y) &&
					(chara[player].y + chara[player].hit_y > chara[floor].y + chara[floor].hit_y) &&
					(chara[player].x + chara[player].hit_x < chara[floor].x - chara[floor].hit_x) &&
					(chara[player].x - chara[player].hit_x > chara[floor].x + chara[floor].hit_x)
					)
				{
					chara[player].y = chara[floor].y - chara[player].hit_y;
					chara[player].gr = 5;
				}
			}
		}
	}
	if(
	/*(chara[player].floor_under == true) &&*/
		(chara[floor].floor_under == true)
	)
	{
		if (ling_out == 1)
		{
			chara[player].state = PLAYER_STATE_PARALYSIS;
			chara[player].frame = 0;
		}
		ling_out = 0;
		chara[floor].floor_under = true;
		chara[player].floor_under = true;
		chara[player].y = chara[floor].y + chara[floor].hit_y;
		/*if (
			(chara[player].state == PLAYER_STATE_IDLE)||
			(chara[player].state == PLAYER_STATE_ACCUMULATE_JAMP)
			)
		{
			chara[player].x += chara[floor].spd_x;
		}*/
		if (HitChara(player, floor) == 1)
		{
			
			if (
				(chara[player].state == PLAYER_STATE_IDLE) ||
				(chara[player].state == PLAYER_STATE_ACCUMULATE_JAMP)
				)
			{
				chara[player].x = chara[player].x + chara[floor].spd_x;
			}

		}
		if (HitChara(player, floor) == 0)
		{
			chara[player].floor_under = false;
			chara[floor].floor_under = false;
			chara[player].gr = 0;

		}
	}
}


void HitMoveFloorPlayerx(int floor,int player)
{
	
	//���̏��ɏ���Ă��Ȃ����
	
	if (
		(chara[floor].floor_under == false)/* &&
		(chara[player].stand == false) */
		)
	{
		//���̏��Ɠ������Ă��邩
		if (HitChara(player, floor) == 1)
		{
			if (chara[player].x - chara[player].hit_x > chara[floor].x - chara[floor].hit_x)
			{
				chara[player].x = chara[floor].x + chara[floor].hit_x + chara[player].hit_x;
			}
			if (chara[player].x + chara[player].hit_x < chara[floor].x + chara[floor].hit_x)
			{
				chara[player].x = chara[floor].x - chara[floor].hit_x - chara[player].hit_x ;
			}
			////�E���瓖�����Ă�����
			//if (mx < 0)
			//{
			//	chara[floor].floor_under = false;
			//	chara[player].x = chara[floor].x - chara[floor].hit_x - chara[player].hit_x;
			//}

			////�����瓖�����Ă�����
			//if (mx > 0)
			//{
			//	chara[floor].floor_under = false;
			//	chara[player].x = chara[floor].x + chara[floor].hit_x + chara[player].hit_x;
			//}
		}
	}
		

	
}


void HitCrumbleMovefloor(int floor,int stage_crumble,int mx)
{
	int no = chara[floor].no;
	for (int i = 0; i < stage_crumble; i++)
	{
		int crumble = CheckCharaType(CHARACTERTYPE_CRUMBLEFLOOR, i);
		//����鏰���g���Ă����
		if (chara[crumble].use == 1)
		{
			//����鏰�Ɠ��������������Ă����
			if (HitChara(floor, crumble) == 1)
			{
				//�����Ȃ�(�����ʒu�ɖ߂�)
				if (no == 1)
				{
					chara[floor].spd_x = 0;
					chara[floor].x = 10120+80;
				}
				else if (no == 2)
				{
					chara[floor].spd_x = 0;
					chara[floor].x = 10320+80+20;
				}

			}
		}
	}
}


void Movefloor1(int floor,int i,int player)
{
	//�������̔ԍ��i���ڂ��j
	switch (i)
	{
	case 0:
		chara[floor].spd_y = FloorRangeMove(2400, 200, 1000, 1000, floor, chara[floor].spd_y, 1);
		MoveFloorCalcu(floor);
		break;
	case 1:
	case 2:
	case 3:
		chara[floor].spd_y = FloorRangeMove(7400, -40, 1000, 880, floor, chara[floor].spd_y, 2);
		MoveFloorCalcu(floor);
		
		break;
	}
}
void Movefloor2(int floor,int i,int player,int stage_crumble)
{
	//�������̔ԍ��i���ڂ��j
	switch (i)
	{
	case 0:
		chara[floor].spd_y = FloorRangeMove(9800, 480, DISP_W, 440, floor, chara[floor].spd_y, 1);
		MoveFloorCalcu(floor);
		break;
	case 1:
		chara[floor].spd_x = FloorRangeMove(9920, 360, 880, DISP_H, floor, chara[floor].spd_x, 1);
		MoveFloorCalcu(floor);
		HitCrumbleMovefloor(floor, stage_crumble,chara[floor].spd_x);
		break;
	case 2:
		chara[floor].spd_x = FloorRangeMove(9920, 280, 1160, DISP_H, floor, chara[floor].spd_x, 1);
		MoveFloorCalcu(floor);
		HitCrumbleMovefloor(floor, stage_crumble, chara[floor].spd_x);
		break;
	case 3:
	case 4:
		chara[floor].spd_x = FloorRangeMove(12080, 0, 560, DISP_H, floor, chara[floor].spd_x, 1);
		MoveFloorCalcu(floor);
		break;
	case 5:
		chara[floor].spd_x = FloorRangeMove(14560, 0, 560, DISP_H, floor, chara[floor].spd_x, 1);
		MoveFloorCalcu(floor);
		chara[floor].spd_x = HitSwitchFloorMovefloor(floor);
		break;
	}
}


void Movefloor3(int floor,int i,int player)
{
	//��`�̍��゘
	int x3[MOVEFLOOR_MAX_3] =
	{
		920,

		1000,0,

		920,920,

		920,0,1200,1120,800,
		960,1200,720,

		920,920,920,400,520,
		640,920,1120,40,440,
		400,600,880,400,760,
		840,120,120,120,360,
		80,160,

		80,240,120,0,640,
		0,0,560,280,

		-1280

	};
	//��`�̍���y
	int y3[MOVEFLOOR_MAX_3] =
	{
		2920,

		1920,22440,

		2600,3360,

		2200,2640,4960,6840,7360,
		7480,8600,21640,

		1080,1320,1560,1680,1680,
		1680,1800,2120,4560,5520,
		7240,7680,9600,10080,11280,
		12640,13280,13440,13600,14760,
		15600,17840,

		2480,4640,8200,19160,19360,
		19560,19760,20720,22600,

		6080
	};

	//��`�̕�(w)
	int w3[MOVEFLOOR_MAX_3] =
	{
		360,

		280,1000 + 40,

		360,360,

		200,440,DISP_W,DISP_W,DISP_W,
		DISP_W,DISP_W,DISP_W,

		360,360,360,DISP_W,DISP_W,
		DISP_W,360,DISP_W,DISP_W,760,
		DISP_W,DISP_W,DISP_W,DISP_W,DISP_W,
		DISP_W,640,640,640,DISP_W,
		1120,DISP_W,

		400 + 160,880 + 160,DISP_W,280 + 160,280 + 160,
		1280 ,1280 ,DISP_W,440 + 160,

		2560
	};
	//��`�̕�(h)
	int h3[MOVEFLOOR_MAX_3] =
	{
		40 * 600,

		40 * 600,40 * 600,

		40 * 600,40 * 600,

		40 * 600,40 * 600,9000 - 8600,7920 - 6840,7920 - 7360,
		7920 - 7480,9000 - 8600,22120 - 21640,

		40 * 600,40 * 600,40 * 600,2120 - 1680,2160 - 1680,
		2040 - 1680,40 * 600,2400 - 2120,5160 - 4560,40 * 600,
		7920 - 7240,7920 - 7680,10080 - 9600,11280 - 10080,11760 - 11280,
		15560 - 12640,40 * 600,40 * 600,40 * 600,680,
		40 * 600,760,

		40 * 600,40 * 600,400,40 * 600,40 * 600,
		40 * 600,40 * 600,920,40 * 600,

		40 * 600
	};

	chara[floor].spd_y = FloorRangeMove(x3[i], y3[i] - cv.view_y + 40, w3[i], h3[i] + 40, floor, chara[floor].spd_y, 1);
	chara[floor].spd_x = FloorRangeMove(x3[i], y3[i] - cv.view_y + 40, w3[i], h3[i] + 40, floor, chara[floor].spd_x, 1);
	MoveFloorCalcu(floor);
	
}

void Movefloor4(int floor, int i, int player)
{
	int x4[MOVEFLOOR_MAX_4] =
	{
		760,800,800,1120,1240,

		600,880,3080,3080,

		560,2120,5200,
	};
	int y4[MOVEFLOOR_MAX_4] =
	{
		1360,160,360,1360,1520,

		1560,1280,2960,3560,

		1000,1400,1320
	};
	int w4[MOVEFLOOR_MAX_4] =
	{
		DISP_W,1320 - 800 + 40,1320 - 800 + 40,DISP_W,DISP_W,

		DISP_W,DISP_W,DISP_W,3400 - 3080 + 120,

		880 - 560 + 160,DISP_W,DISP_W
	};
	int h4[MOVEFLOOR_MAX_4] =
	{
		1840 - 1360,4400,4400,1840 - 1360,1840 - 1520,

		1840 - 1560,1840 - 1280,3320 - 2960,4400,

		4400,1720 - 1400,1960 - 1320
	};
	chara[floor].spd_y = FloorRangeMove(x4[i], y4[i] - cv.view_y + 800, w4[i], h4[i] + 40, floor, chara[floor].spd_y, 1);
	chara[floor].spd_x = FloorRangeMove(x4[i], y4[i] - cv.view_y + 800, w4[i], h4[i] + 40, floor, chara[floor].spd_x, 1);
	MoveFloorCalcu(floor);
}



void Movefloor()
{
		//�ϐ���`
		int stage_crumble = CrumbleMax();							/*����鏰�̍ő吔*/
		int player = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);	/*�v���C���[*/
		int movefloor_max = MoveFloorMax();							/*�������̍ő吔*/
		int floor;													/*������*/

		for (int i = 0; i < movefloor_max; i++)
		{
			floor = CheckCharaType(CHARACTERTYPE_MOVEFLOOR, i);
			switch (gNowstage)
			{
			case STAGE_1:
				Movefloor1(floor,i,player);
				break;
			case STAGE_2:
				Movefloor2(floor, i, player, stage_crumble);
				break;
			case STAGE_3:
				Movefloor3(floor, i, player);
				break;
			case STAGE_4:
				Movefloor4(floor, i, player);
				break;
			
			}
		}
	
	
	
}







void InitCrumbleFloor()
{
	int crumble_max = CrumbleMax();
	int floor;
	int kind[CRUMBLE_MAX_1] = { CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_280_40 };
	int x1[CRUMBLE_MAX_1] = { 1240,3520,8560 };
	int y1[CRUMBLE_MAX_1] = { 160,480,520 };
	int kind2[CRUMBLE_MAX_2] = {
		CRUMBLEFLOOR_80_40,
		CRUMBLEFLOOR_120_40,CRUMBLEFLOOR_120_40,CRUMBLEFLOOR_120_40,CRUMBLEFLOOR_120_40,CRUMBLEFLOOR_120_40,
		CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,
		CRUMBLEFLOOR_240_40,
		CRUMBLEFLOOR_280_440,
		CRUMBLEFLOOR_40_1200
	};
	int x2[CRUMBLE_MAX_2] = {
		9360,
		6880,15200,15440,16120,16320,
		15200,15480,15720,16000,
		14800,
		10280,
		10080
	};
	int y2[CRUMBLE_MAX_2] = {
		480,
		440,680,680,440,680,
		440,440,680,680,
		680,
		0,
		-480

	};
	int x3[CRUMBLE_MAX_3] = {
		0,
		40,
		320,160,160,440,0,200,400,280,440,600,800,960,
		0,240,480,1080,880,1120,520,
		1120,320,120,320,840,
		/*520*/
	};
	int y3[CRUMBLE_MAX_3] = {
		2840 ,
		1960 ,
		11920 ,12160 ,12400 ,12400 ,12560 ,12720 ,12840 ,15960 ,16080 ,16240 ,16280 ,16280 ,
		6200,14680,14680,16480,16760,16960,20920,
		320,2800,2960,3400,9000,
		/*20640*/
	};
	int kind3[CRUMBLE_MAX_3] = {
			CRUMBLEFLOOR_40_400,

			CRUMBLEFLOOR_40_520,

			CRUMBLEFLOOR_80_40,CRUMBLEFLOOR_80_40,CRUMBLEFLOOR_80_40,CRUMBLEFLOOR_80_40,CRUMBLEFLOOR_80_40,CRUMBLEFLOOR_80_40,CRUMBLEFLOOR_80_40,CRUMBLEFLOOR_80_40,CRUMBLEFLOOR_80_40,CRUMBLEFLOOR_80_40,CRUMBLEFLOOR_80_40,CRUMBLEFLOOR_80_40,
			CRUMBLEFLOOR_120_40,CRUMBLEFLOOR_120_40,CRUMBLEFLOOR_120_40,CRUMBLEFLOOR_120_40,CRUMBLEFLOOR_120_40,CRUMBLEFLOOR_120_40,CRUMBLEFLOOR_120_40,
			CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,
			/*CRUMBLEFLOOR_200_40,*/
	};

	int x4[CRUMBLE_MAX_4]=
	{
		5200,5280,5480,5760,5800,
		5960,

		200,360,2120,3280,3600,
		3600,3600,4040,4400,4560,
		4720,4880,5880,

		280
	};
	int y4[CRUMBLE_MAX_4] =
	{
		2760,2480,2720,2160,2760,
		2320,

		3000,1400,1920,2800,1200,
		2720,2960,2800,2800,1800,
		2800,1080,2600,

		1640
	};

	int kind4[CRUMBLE_MAX_4]=
	{
		CRUMBLEFLOOR_120_40,CRUMBLEFLOOR_120_40,CRUMBLEFLOOR_120_40,CRUMBLEFLOOR_120_40,CRUMBLEFLOOR_120_40,
		CRUMBLEFLOOR_120_40,

		CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,
		CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,
		CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,CRUMBLEFLOOR_160_40,

		CRUMBLEFLOOR_240_40
	}; 


	for (int i = 0; i < crumble_max; i++)
	{
		int cg = CrumbleFloorCg(kind[i]);
		InitChara(
			STAGE_1, CHARACTERTYPE_CRUMBLEFLOOR, cg,
			x1[i], y1[i] + 560, 0, 0, 0, 1, 0, 0,
			0,0,0,0,
			i, 0, kind[i]
		);
		cg = CrumbleFloorCg(kind2[i]);
		InitChara(
			STAGE_2, CHARACTERTYPE_CRUMBLEFLOOR, cg,
			x2[i], y2[i] + 560, 0, 0, 0, 1, 0, 0,
			0,0,0,0,
			i, 0, kind2[i]
		);
		cg = CrumbleFloorCg(kind3[i]);
		InitChara(
			STAGE_3, CHARACTERTYPE_CRUMBLEFLOOR, cg,
			x3[i], y3[i] + 40, 0, 0, 0, 1, 0, 0, 
			0,0,0,0,
			i, 0, kind3[i]
		);
		cg = CrumbleFloorCg(kind4[i]);
		InitChara(
			STAGE_4, CHARACTERTYPE_CRUMBLEFLOOR, cg,
			x4[i], y4[i] + 800, 0, 0, 0, 1, 0, 0,
			0, 0, 0, 0,
			i, 0, kind4[i]
		);
		floor = CheckCharaType(CHARACTERTYPE_CRUMBLEFLOOR, i);
		chara[floor].state = FLOOR_STATE_IDLE;
	}
}



void HitCrumbleFloorPlayer(int floor, int mx,int player)
{
	
			//����鏰���g���Ă��Ă��̏��ɗ����Ă��Ȃ������ꍇ
			if (
			/*	(chara[player].floor_under == false) &&*/
				(chara[floor].floor_under == false) &&
				(chara[player].stand == false) &&
				(chara[floor].use == 1)
				)
			{
				if (HitChara(player, floor) == 1)
				{
					if (chara[floor].state == FLOOR_STATE_IDLE) 
					{
						chara[floor].frame = 0;
						chara[floor].state = FLOOR_STATE_HIT;
					}
					//�v���C���[�����ɓ����Ă����ꍇ
					if (mx < 0)
					{
						
						//PlayMemBack(se_crumble_land);//���Ă�Ԃ�SE���Đ�
						if (se_button == false)
						PlayMemBack(in_se[CRUMBLE_LAND].handle);
						chara[player].x = chara[floor].x - chara[floor].hit_x - chara[player].hit_x;
					}
					//�v���C���[���E�ɓ����Ă����ꍇ
					if (mx > 0)
					{
						
						//PlayMemBack(se_crumble_land);//���Ă�Ԃ�SE���Đ�
						if (se_button == false)
						PlayMemBack(in_se[CRUMBLE_LAND].handle);
						chara[player].x = chara[floor].x + chara[floor].hit_x + chara[player].hit_x;
					}
					//�����瓖�������ꍇ
					if (
						(chara[player].y + chara[player].hit_y < chara[floor].y) &&
						(chara[player].y + chara[player].hit_y > chara[floor].y + chara[floor].hit_y) &&
						(chara[player].x + chara[player].hit_x < chara[floor].x - chara[floor].hit_x) &&
						(chara[player].x - chara[player].hit_x > chara[floor].x + chara[floor].hit_x)
						)
					{
						
						//PlayMemBack(se_crumble_land);//���Ă�Ԃ�SE���Đ�
						if (se_button == false)
						PlayMemBack(in_se[CRUMBLE_LAND].handle);
						chara[player].y = chara[floor].y - chara[player].hit_y;
						chara[player].gr = 5;
					}
					//�ォ�瓖�������ꍇ
					if (
						(chara[player].y < chara[floor].y) &&
						(chara[player].y > chara[floor].y + chara[floor].hit_y - 1) &&
						(chara[player].x + chara[player].hit_x < chara[floor].x - chara[floor].hit_x) &&
						(chara[player].x - chara[player].hit_x > chara[floor].x + chara[floor].hit_x)
						)
					{
						
						if (ling_out == 1)
						{
							chara[player].state = PLAYER_STATE_PARALYSIS;
							chara[player].frame = 0;
						}
						ling_out = 0;
						chara[player].floor_under = true;
						chara[floor].floor_under = true;
						//PlayMemBack(se_crumble_land);//���Ă�Ԃ�SE���Đ�
						if (se_button == false)
						PlayMemBack(in_se[CRUMBLE_LAND].handle);
						/*chara[player].gr = 0;*/

					}
				}
				
			}
			//���̏��Ƀv���C���[�������Ă���Ƃ�
			if (
				(chara[floor].floor_under == true)/*&&*/
				/*(chara[player].floor_under == true)*/
				)
			{
				chara[player].floor_under = true;
				chara[player].y = chara[floor].y + chara[floor].hit_y;
				if (HitChara(player, floor) == 0)
				{
					chara[player].floor_under = false;
					chara[floor].floor_under = false;
					chara[player].gr = 0;
				}
			}
	}





void Clumble(int floor,int player)
{
	int mf;
	
			//�������̏�Ԃ��q�b�g�Ȃ�
			if (chara[floor].state == FLOOR_STATE_HIT) 
			{
				//���̃t���[���𑫂�
				chara[floor].frame++;
				if(((chara[floor].frame / 5) % 2) == 1)
				{
					chara[floor].dx = -(chara[floor].w / 2) - 4;
				}
				if(((chara[floor].frame / 5) % 2) == 0)
				{
					chara[floor].dx = -(chara[floor].w / 2) + 4;
				}
				if (((chara[floor].frame / 2) % 2) == 1)
				{
					chara[floor].dy = -(chara[floor].h ) - 2;
				}
				if (((chara[floor].frame / 2) % 2) == 0)
				{
					chara[floor].dy = -(chara[floor].h) + 2;
				}

				//�������̏��̃t���[����99���傫���Ȃ����ꍇ
				if (chara[floor].frame > 99) {

					chara[player].floor_under = false;
					chara[floor].floor_under = false;
					chara[floor].frame = 0;
					chara[floor].use = 0;
					chara[floor].state = FLOOR_STATE_REVIVAL;
					//StopPlayMem(se_crumble_land);//�������Ă�Ԃ�SE���~�߂�
					//PlayMemBack(se_crumble_break);//����������SE�Đ�
					StopPlayMem(in_se[CRUMBLE_LAND].handle);//�������Ă�Ԃ�SE���~�߂�
					if (se_button == false)
					PlayMemBack(in_se[CRUMBLE_BREAK].handle);
					if (gNowstage == STAGE_2) {
						switch (chara[floor].no) {
						case 11:
							mf = CheckCharaType(CHARACTERTYPE_MOVEFLOOR, 1);
							chara[mf].spd_x = 3;
							mf = CheckCharaType(CHARACTERTYPE_MOVEFLOOR, 2);
							chara[mf].spd_x = 3;
							break;
						case 12:
							mf = CheckCharaType(CHARACTERTYPE_MOVEFLOOR, 1);
							chara[mf].spd_x = -3;
							break;
						}
					}
				}
			}
			
		
	
}




void RevivalCrumbleFloor(int floor)
{
	if (chara[floor].state == FLOOR_STATE_REVIVAL) {
		chara[floor].frame++;
		if (chara[floor].frame > 99) {
			if (gNowstage == STAGE_1) {
				chara[floor].frame = 0;
				chara[floor].use = 1;
				chara[floor].dx = -(chara[floor].w / 2);
				chara[floor].state = FLOOR_STATE_IDLE;


				StopPlayMem(in_se[CRUMBLE_BREAK].handle);//����������SE�~�߂�
				if (se_button == false)
				PlayMemBack(in_se[CRUMBLE_EMERGENCE].handle);// ���ďo��SE�Đ�
			}
			if (gNowstage == STAGE_2) {
				switch (chara[floor].no) {
				case 1:
				case 11:
				case 12:
					chara[floor].frame = 0;
					chara[floor].use = 0;
					chara[floor].dx = -(chara[floor].w / 2);
					chara[floor].state = FLOOR_STATE_IDLE;
					//StopPlayMem(se_crumble_break);//����������SE�~�߂�
					StopPlayMem(in_se[CRUMBLE_BREAK].handle);
					break;
				default:

					chara[floor].frame = 0;
					chara[floor].use = 1;
					chara[floor].dx = -(chara[floor].w / 2);
					chara[floor].state = FLOOR_STATE_IDLE;
					//StopPlayMem(se_crumble_break);//����������SE�~�߂�
					//PlayMemBack(se_crumble_emergence);//���ďo��SE�Đ�
					StopPlayMem(in_se[CRUMBLE_BREAK].handle);
					if (se_button == false)
					PlayMemBack(in_se[CRUMBLE_EMERGENCE].handle);
					break;
				}
			}
			if (gNowstage == STAGE_3) {
				chara[floor].frame = 0;
				chara[floor].use = 1;
				chara[floor].dx = -(chara[floor].w / 2);
				chara[floor].state = FLOOR_STATE_IDLE;
				//StopPlayMem(se_crumble_break);//����������SE�~�߂�
				//PlayMemBack(se_crumble_emergence);//���ďo��SE�Đ�
				StopPlayMem(in_se[CRUMBLE_BREAK].handle);
				if (se_button == false)
				PlayMemBack(in_se[CRUMBLE_EMERGENCE].handle);
			}

			if (gNowstage == STAGE_4) {
				chara[floor].frame = 0;
				chara[floor].use = 1;
				chara[floor].dx = -(chara[floor].w / 2);
				chara[floor].state = FLOOR_STATE_IDLE;
				//StopPlayMem(se_crumble_break);//����������SE�~�߂�
				//PlayMemBack(se_crumble_emergence);//���ďo��SE�Đ�
				StopPlayMem(in_se[CRUMBLE_BREAK].handle);
				if (se_button == false)
				PlayMemBack(in_se[CRUMBLE_EMERGENCE].handle);
			}

		}
	}
}




void CrumbleFloor()
{
		//�v���C���[�ϐ�
		int player = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);
		//����鏰�̍ő吔
		int crumble_max = CrumbleMax();
		//����鏰0�ڂ���ő吔�܂�
		for (int i = 0; i < crumble_max ; i++)
		{
			//����鏰�ϐ�
			int floor = CheckCharaType(CHARACTERTYPE_CRUMBLEFLOOR, i);
			//����鏰�ƃv���C���[���������Ă���Ώ���
			HitCrumbleFloorPlayer(floor, 0, player);
			//����鏈��
			Clumble(floor, player);
			//����鏰���������鏈��
			RevivalCrumbleFloor(floor);
		}
	
}
//�����܂�