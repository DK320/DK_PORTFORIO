#pragma once
#define PARTS_CG_TYPE_B "res/gimmick_parts_b.png"
#define PARTS_CG_TYPE_N "res/gimmick_parts_n.png"
#define PARTS_CG_TYPE_G "res/gimmick_parts_g.png"
#define PARTS_CG_MAX 6
#define PARTS_MAX 5
extern void LoadParts();
extern void InitParts();
extern void Parts();
extern int cgParts();
extern int cgParts_b[PARTS_CG_MAX];
extern int cgParts_g[PARTS_CG_MAX];
extern int cgParts_n[PARTS_CG_MAX];
