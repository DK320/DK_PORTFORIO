
#include	<Windows.h>
#include	"../amgame.h"
#include	"../AmHelper.h"
#include	"../utility.h"
#include	<math.h>
#include	"vivacious_spring.h"
#include	"vivacious_spring_player.h"
#include	"vivacious_spring_camera.h"
#include	"../system/common.h"
#include	"../system/vivacious_spring_se.h"
#include	"vivacious_spring_game.h"
#include	"vivacious_spring_parts.h"
#include	"frame.h"
#include	"../outgame/charselect.h"
#include"../outgame/game_setting.h"
int cgParts_b[PARTS_CG_MAX] = {0};
int cgParts_g[PARTS_CG_MAX] = {0};
int cgParts_n[PARTS_CG_MAX] = {0};
//�p�[�c�̉摜���[�h
void LoadParts()
{
	LoadBlkTexture(PARTS_CG_TYPE_B,80,80,6,1,6*1,cgParts_b);
	LoadBlkTexture(PARTS_CG_TYPE_G,80,80,6,1,6*1,cgParts_g);
	LoadBlkTexture(PARTS_CG_TYPE_N,80,80,6,1,6*1,cgParts_n);
}


int cgParts()
{
	int no, frame;
	switch (gNowstage)
	{
	case STAGE_1:
		no = 0;
		frame = f[GAMEFRAME].frame;
		no = ((frame / 10) % 6);
		return cgParts_n[no];
		break;
	case STAGE_2:
		no = 0;
		frame = f[GAMEFRAME].frame;
		no = ((frame / 10) % 6);
		return cgParts_b[no];
		break;
	case STAGE_3:
		no = 0;
		frame = f[GAMEFRAME].frame;
		no = ((frame / 10) % 6);
		return cgParts_g[no];
		break;
	case STAGE_4:
		no = 0;
		frame = f[GAMEFRAME].frame;
		no = ((frame / 10) % 6);
		return cgParts_b[no];
		break;
	}

	return -1;
}


void InitParts()
{
	

	int x1[PARTS_MAX] =
	{
		2360,3600,5720,6040,7680
	};
	int y1[PARTS_MAX] =
	{
		0,0,0,360,80
	};
	int x2[PARTS_MAX]=
	{
		3360,6760,9920,12240,13480
	};
	int y2[PARTS_MAX] =
	{
		240,560,0,520,0
	};
	int x3[PARTS_MAX]=
	{
		800,800,880,1000,960
	};
	int y3[PARTS_MAX]=
	{
		1960 ,7280 ,13160 ,17120 ,21880
	};
	int use3[PARTS_MAX]=
	{
		1,1,1,0,1
	};
	int x4[PARTS_MAX]=
	{
		200,400,2320,3760,5200
	};
	int y4[PARTS_MAX]=
	{
		320,2320,1680,2760,0
	};
	for (int i = 0; i < PARTS_MAX; i++)
	{
		InitChara(
			STAGE_1, CHARACTERTYPE_PARTS, cgParts_n[0],
			x1[i], y1[i] + 560, 0, 0, 0, 1, 0, 0, -40, -80, 80, 80, i, 0, 0
		);
		InitChara(
			STAGE_2, CHARACTERTYPE_PARTS, cgParts_b[0],
			x2[i], y2[i] + 560, 0, 0, 0, 1, 0, 0, -40, -80, 80, 80, i, 0, 0
		);
		InitChara(
			STAGE_3, CHARACTERTYPE_PARTS, cgParts_g[0],
			x3[i], y3[i] + 40, 0, 0, 0, use3[i], 0, 0, -40, -80, 80, 80, i, 0, 0
		);
		InitChara(
			STAGE_4, CHARACTERTYPE_PARTS, cgParts_b[0],
			x4[i],y4[i] + 800,0,0,0,1,0,0,0,0,0,0,i,0,0
		);
	}
	
}
void Parts()
{
	
		int player = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);
		for (int i = 0; i < PARTS_MAX; i++)
		{
			int parts = CheckCharaType(CHARACTERTYPE_PARTS, i);
			if (chara[parts].use == 1)
			{
				if (HitChara(parts, player) == 1)
				{
						if (gParts < 4)
						{
						/*	PlayMemBack(se_parts_get);*/
							StopInVoice();
							if (character == 1)
							{
								if (voice_button2 == false)
								PlayMemBack(in_voice[PARTS_COLLECT_B].handle);
							}
							else 
							{
								if (voice_button2 == false)
								PlayMemBack(in_voice[PARTS_COLLECT_V].handle);
							}
							if (se_button == false)
							PlayMemBack(in_se[PARTS_GET].handle);

						}
						if (gParts == 4)
						{
							StopInVoice();
							/*PlayMemBack(se_parts_complete);*/
							if (character == 1)
							{
								if (voice_button2 == false)
								PlayMemBack(in_voice[PARTS_COMPLETE_B].handle);
							}
							else {
								if (voice_button2 == false)
								PlayMemBack(in_voice[PARTS_COMPLETE_V].handle);
							}
							if (se_button == false)
							PlayMemBack(in_se[PARTS_COMPLETE].handle);
						}
						chara[parts].use = 0;
						chara[parts].type = CHARACTERTYPE_NONE;
						gParts++;
				}
			}
		}
	
}