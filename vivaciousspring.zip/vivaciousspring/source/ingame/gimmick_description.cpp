#include	"../amgame.h"
#include	"vivacious_spring_camera.h"
#include	"vivacious_spring_game.h"
int gimmick_description_1 = 0;
int gimmick_description_2 = 0;
int gimmick_description_3 = 0;

void LoadGimmickDescription(){

	gimmick_description_1 = LoadTexture("res/background_icon_crumble.png");
	gimmick_description_2 = LoadTexture("res/background_icon_action.png");
	gimmick_description_3 = LoadTexture("res/background_icon_death.png");
}
void DrawGimmickDescription()
{
	if (gNowstage == STAGE_1)
	{
		int x, y;
		x = 1000 - cv.view_x;
		y = 165 + 560 - cv.view_y;
		SetDrawArea(x, y, x + 160, y + 160);
		DrawMemTh(x, y, gimmick_description_1);
		x = 5300 - cv.view_x;
		y = 485 + 560 - cv.view_y;
		SetDrawArea(x, y, x + 160, y + 160);
		DrawMemTh(x, y, gimmick_description_2);
		x = 2100 - cv.view_x;
		y = 245 + 560 - cv.view_y;
		SetDrawArea(x, y, x + 160, y + 160);
		DrawMemTh(x, y, gimmick_description_3);
	}
}