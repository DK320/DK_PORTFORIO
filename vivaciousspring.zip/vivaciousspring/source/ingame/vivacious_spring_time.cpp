#include	"../amgame.h"
#include	"vivacious_spring_time.h"
#include	"vivacious_spring_camera.h"
#include	"../system/common.h"
#include	"vivacious_spring.h"
#include	"vivacious_spring_player.h"
#include	"frame.h"
#include	"vivacious_spring_game.h"
int cg_number_time[TIME_W_QUANTITY * TIME_H_QUANTITY];
int g_time_damage[TIME_CLOUD_H_QUANTITY * TIME_CLOUD_W_QUANTITY] = { 0 };
int g_time_recovery[TIME_CLOUD_H_QUANTITY * TIME_CLOUD_W_QUANTITY] = { 0 };

int time_no = 0;
bool time_action = false;
bool time_cloud_action = false;
int time_frame = 0;
int time_cloud_frame = 0;
struct TIME ti;
void LoadTime()
{
	LoadBlkTexture("res/number_time.png",
		(TIME_W / TIME_W_QUANTITY),
		(TIME_H / TIME_H_QUANTITY),
		TIME_W_QUANTITY,
		TIME_H_QUANTITY,
		(TIME_W_QUANTITY * TIME_H_QUANTITY),
		cg_number_time
	);

	LoadBlkTexture("res/time_damage.png",
		(TIME_CLOUD_W / TIME_CLOUD_W_QUANTITY),
		(TIME_CLOUD_H / TIME_CLOUD_H_QUANTITY),
		TIME_CLOUD_W_QUANTITY,
		TIME_CLOUD_H_QUANTITY,
		TIME_CLOUD_H_QUANTITY*TIME_CLOUD_W_QUANTITY,
		g_time_damage
		);

	LoadBlkTexture("res/time_heal.png",
		(TIME_CLOUD_W / TIME_CLOUD_W_QUANTITY),
		(TIME_CLOUD_H / TIME_CLOUD_H_QUANTITY),
		TIME_CLOUD_W_QUANTITY,
		TIME_CLOUD_H_QUANTITY,
		TIME_CLOUD_H_QUANTITY*TIME_CLOUD_W_QUANTITY,
		g_time_recovery
	);
}

void InitTime()
{
	ti.x = 0;
	ti.y = 0;
	ti.frame = 0;
	time_frame = 0;
	time_cloud_frame = 0;
	ti.frame_a = 0;
	ti.frame_b = 0;
	switch (gNowstage)
	{
	case STAGE_1:
		ti.frame_c = 5/*2*/;
		break;
	case STAGE_2:
		ti.frame_c = 5;
		break;
	case STAGE_3:
		ti.frame_c = 6;
		break;
	case STAGE_4:
		ti.frame_c = 5;
		break;

	}
	
	ti.a = 1.1;
	GetPictureSize(g_time_damage[0],&ti.width,&ti.height);
}

void ProcessTime()
{
	
		int player = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);
		ti.x = 0;
		ti.y = 0;
		if (time_action == true)
		{
			ti.frame += TIME_ACTION_PLUS_FRAME;
			time_frame++;
			if (time_frame > 59)
			{
				time_frame = 0;
				time_action = false;
			}
		}
		else
		{
			ti.frame++;
		}
		if (ti.frame > 59)
		{
			ti.frame -= 60;
			ti.frame_a--;
		}
		if (ti.frame_a < 0)
		{
			ti.frame_a = 9;
			ti.frame_b--;
		}
		if (ti.frame_b < 0)
		{
			ti.frame_b = 9;
			ti.frame_c--;
		}
		if (
			(ti.frame_c == 0)&&
			(ti.frame_b == 0)&&
			(ti.frame_a == 0)
			)
		{
			chara[player].state = PLAYER_STATE_GAMEOVER;
		}
		for (int player = 0; player < CHARACTER_MAX; player++)
		{
			if (chara[player].type == CHARACTERTYPE_PLAYER_MAN)
			{
				if (
					IsHitBox(
						ti.x, ti.y,
						ti.width, ti.height,
						chara[player].x + chara[player].hit_x - cv.view_x, chara[player].y + chara[player].hit_y - cv.view_y,
						chara[player].hit_w, chara[player].hit_h
					) == 1
					)
				{
					ti.a = 2;
				}
				else
				{
					ti.a = 1.1;
				}
			}

		}
		
		if (time_cloud_action == true)
		{
			
			time_no = ((time_cloud_frame / TIME_CLOUD_ANIMETION_INTERVAL) % (TIME_CLOUD_H_QUANTITY*TIME_CLOUD_W_QUANTITY));
			time_cloud_frame++;
			if (time_cloud_frame > (TIME_CLOUD_ANIMETION_INTERVAL * (TIME_CLOUD_H_QUANTITY*TIME_CLOUD_W_QUANTITY))*3)
			{
				time_cloud_frame = 0;
				time_cloud_action = false;
			}
		}
}
void DrawTime()
{
	

	SetDrawArea(ti.x, ti.y, ti.width, ti.height);
	SetDrawMode(AMDRAW_ALPHABLEND, 255/ti.a);
	DrawMemTh(ti.x,ti.y,g_time_damage[time_no]);
	DrawMemTh(20 + 4, 20 + 20 , cg_number_time[ti.frame_c]);
	DrawMemTh(20 + (TIME_W / TIME_W_QUANTITY), 20 + 20 , cg_number_time[ti.frame_b]);
	DrawMemTh(20 + (TIME_W / TIME_W_QUANTITY * 2) -4, 20 + 20 , cg_number_time[ti.frame_a]);

}