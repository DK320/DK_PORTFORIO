#pragma once
#define BG_MAX 5
typedef struct {
	int x,y,w,h;
}BG;
extern BG bg[BG_MAX];
extern void InitBg();
extern void LoadBg();
extern void MoveBg();
extern void DrawBg();