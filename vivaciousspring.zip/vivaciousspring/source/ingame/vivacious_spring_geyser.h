#pragma once
#define CGGEYSER_MAX 20
#define GEYSER_MAX_2 15
#define GEYSER_MAX_3 18
#define GEYSER_MAX_4 18

#define G80_165 1
#define G80_165_D 2
#define G165_80 3
#define G165_80_R 4
#define G80_325 5
#define G80_325_D 6
#define G325_80 7
#define G325_80_R 8
#define G80_645 9
#define G645_80 10

extern int cggimmick_geyser_80_165[CGGEYSER_MAX];
extern int cggimmick_geyser_80_165_d[CGGEYSER_MAX];
extern int cggimmick_geyser_165_80[CGGEYSER_MAX];
extern int cggimmick_geyser_165_80_r[CGGEYSER_MAX];
extern int cggimmick_geyser_80_325[CGGEYSER_MAX];
extern int cggimmick_geyser_80_325_d[CGGEYSER_MAX];
extern int cggimmick_geyser_325_80[CGGEYSER_MAX];
extern int cggimmick_geyser_325_80_r[CGGEYSER_MAX];
extern int cggimmick_geyser_80_645[CGGEYSER_MAX];
extern int cggimmick_geyser_645_80[CGGEYSER_MAX];
extern void LoadGeyser();
extern void InitGeyser();
extern void ProcessGeyser();
int CgGeyser(int i);
