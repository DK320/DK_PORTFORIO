#include	<Windows.h>
#include	"../amgame.h"
#include	"../AmHelper.h"
#include	"../utility.h"
#include	<math.h>
#include	"vivacious_spring.h"
#include	"vivacious_spring_camera.h"
#include	"vivacious_spring_mapdata1.h"
#include	"../system/common.h"
#include	"vivacious_spring_floor.h"
#include	"vivacious_spring_game.h"
#include	"vivacious_spring_player.h"
#include	"vivacious_spring_floor.h"
//
//�J�����̏�����
//
//�S��D.K
//��������
void InitCamera()
{
	
	
	switch (gNowstage) {
	case STAGE_1:
		//�J�����̂����W
		cv.view_x = 0;
		//�J����y���W
		cv.view_y = 560;
		break;
	case STAGE_2:
		//�J�����̂����W
		cv.view_x = 0;
		//�J����y���W
		cv.view_y = 560;
		break;
	case STAGE_3:
		//�J�����̂����W
		cv.view_x = 0;
		cv.view_y = /*17440;*//*4200;*/23880;/*9000;*/
	
		break;
	case STAGE_4:
		cv.view_x = 0;
		cv.view_y = 3000 +800;

		/*cv.view_x = 2000;
		cv.view_y = 0  + 800; */
		break;
	}
	

	cv.state = CAMERA_STATE_IDLE;
}
void MoveCamera()
{
	
		int i = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);
		switch (gNowstage)
		{
		case STAGE_1:
		case STAGE_2:
			switch (cv.state)
			{
			case CAMERA_STATE_IDLE:
				if (chara[i].direction == 1)
				{
					if (cv.view_x > chara[i].x - chara[i].dx - DISP_W / 2)
					{
						if (cv.view_x < chara[i].x - chara[i].dx - 440)
						{
							cv.view_x = chara[i].x - chara[i].dx - 440;
						}
					}

					if (cv.view_x < chara[i].x - chara[i].dx - 920)
					{
						cv.state = CAMERA_STATE_RIGHT;
					}
				}
				if (chara[i].direction == -1)
				{
					if (cv.view_x < chara[i].x - chara[i].dx - DISP_W / 2)
					{
						if (cv.view_x > chara[i].x - chara[i].dx - 920)
						{
							cv.view_x = chara[i].x - chara[i].dx - 920;
						}
					}
					if (cv.view_x > chara[i].x + chara[i].dx - 160)
					{
						cv.state = CAMERA_STATE_LEFT;
					}
				}
				break;
			case CAMERA_STATE_RIGHT:
				cv.view_x += 8;
				if (cv.view_x > chara[i].x - chara[i].dx - 440)
				{
					cv.view_x = chara[i].x - chara[i].dx - 440;
					cv.state = CAMERA_STATE_IDLE;
				}
				break;
			case CAMERA_STATE_LEFT:
				cv.view_x -= 8;
				if (cv.view_x < chara[i].x - chara[i].dx - 920)
				{
					cv.view_x = chara[i].x - chara[i].dx - 920;
					cv.state = CAMERA_STATE_IDLE;
				}
				break;

			}
			break;
		case STAGE_3:
			if (
				(chara[i].stand == true) ||
				(chara[i].floor_under == true)
				)
			{
				if (chara[i].y < cv.view_y + 560)
				{
					cv.view_y -= 8;
					if (chara[i].y > cv.view_y + 560)
					{
						cv.view_y = chara[i].y - 560;
					}
				}
			}
			break;
		case STAGE_4:
			cv.view_x = chara[i].x - (DISP_W / 2);
			cv.view_y = chara[i].y - (DISP_H / 2);
			break;
		}
	int mapsize_w = WhereStageW();
	int mapsize_h = WhereStageH();
	// �J�������}�b�v�f�[�^�𒴂��Ȃ��悤�ɂ���
	if (cv.view_x < 0) { cv.view_x = 0; }
	if (cv.view_x > mapsize_w* CHIPSIZE_W_STAGE - DISP_W) { cv.view_x = mapsize_w * CHIPSIZE_W_STAGE - DISP_W; }
	if (cv.view_y < 0) { cv.view_y = 0; }
	if (cv.view_y > mapsize_h * CHIPSIZE_H_STAGE - DISP_H) { cv.view_y = mapsize_h * CHIPSIZE_H_STAGE - DISP_H; }
}
//�����܂�