#include<Windows.h>
#include "../outgame/vivacious_spring_option.h"
#include "vivacious_spring.h"
#include "../amgame.h"
#include "../AmHelper.h"
#include "../system/common.h"
#include "vivacious_spring_gameover.h"
#include	"vivacious_spring_game.h"
#include	"../system/vivacious_spring_se.h"
#include	"../system/vivacious_spring_bgm.h"
#include	"vivacious_spring_player.h"

#include	"vivacious_spring_camera.h"
#include	"../outgame/vivacious_spring_title.h"
#include	"vivacious_spring_time.h"
#include	"frame.h"
#include	"vivacious_spring_parts.h"
#include	"../outgame/charselect.h"
#include	"../outgame/game_setting.h"

struct CURSOR cursor3;
struct CURSOR cursor4;
int cgGameOver = 0; //�Q�[���I�[�o�[���
int cgContinue_message = 0;
int cgContinue_yes_on = 0;
int cgContinue_yes_off = 0;
int cgContinue_no_on = 0;
int cgContinue_no_off = 0;

void DrawGameOver()
{
	f[GAMEOVERFRAME].frame++;
	/*g_alpha = 0;
	g_alpha2 += 20;*/

	/*double cur;
	cur = sin(f[GAMEOVERFRAME].frame * 2 * PAI / 80) * 10;*/
	SetDrawArea(0, 0, DISP_W, DISP_H);
	SetDrawMode(AMDRAW_NOBLEND, 0);
	//SetDrawBright(g_alpha2, g_alpha2, g_alpha2);//�t�F�[�h�C��
	SetDrawMode(AMDRAW_NOBLEND, 0);
	DrawMemTh(360, 80, cgGameOver);
	DrawMemTh((DISP_W - 440) / 2, 200, cgContinue_message);
	if (cursor == 0)
	{
		DrawMemTh(160, 440, cgContinue_yes_on);
		DrawMemTh(640, 480, cgContinue_no_off);
	}
	if (cursor == 1)
	{
		DrawMemTh(160, 440, cgContinue_yes_off);
		DrawMemTh(640, 480, cgContinue_no_on);
	}
}

void GameOver()//�Q�[���I�[�o�[��ʂֈڍs
{
	StopPlayMem(CheckBgm());
	if (bgm_button == false)
	{
		PlayMemLoop(bgmGameover);
	}
	nowstate = STATE_GAMEOVER;
}

int Continue()
{

	if (gTrg & KEYIN_RIGHT)
	{
		cursor++;
		if (cursor > 1)
		{
			cursor = 1;
		}
	}
	if (gTrg&KEYIN_LEFT)
	{
		cursor--;
		if (cursor < 0)
		{
			cursor = 0;
		}
	}

	if (gTrg&KEYIN_Z && cursor == 0)//�Q�[���R���e�B�j���[
	{
		/*InitTime();*/
		int player = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);
		int save = CheckCharaType(CHARACTERTYPE_SAVE, 1);
		StopPlayMem(bgmGameover);
		
		PlayMemBack(seDecide);
		if (character == 1 && voice_button == false)
		{

			PlayMemBack(voice_continue_b);
		}
		if (character == 2 && voice_button == false)
		{
			PlayMemBack(voice_continue_v);

		}

		count = 0;
		if (chara[player].save == true)
		{
			chara[player].spd_x = 2;
			chara[player].state = PLAYER_STATE_IDLE;
			chara[player].hp = 120.0;
			chara[player].x = chara[save].x;
			chara[player].y = chara[save].y;
			chara[player].direction = 1;
			cv.view_x = chara[player].x - chara[player].dx - 440;
			InitFlag();
			chara[player].hit = NOHIT;
		}
		else
		{
			InitStage();
		}
		return STATE_GAME;
	}
	if (gTrg&KEYIN_Z && cursor == 1)//�^�C�g���ֈڍs
	{
		int player = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);
		StopPlayMem(bgmGameover);
		if (se_button == false)
		PlayMemBack(seBack);
		cursor = 0;
		f[TITLEFRAME].frame = 0;
		Setumei();
		//voice_button = 0;
		g_alpha3 = 0;
		return STATE_TITLE;
	}
	return STATE_GAMEOVER;
}
