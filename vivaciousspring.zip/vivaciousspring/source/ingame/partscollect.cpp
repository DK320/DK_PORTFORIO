#include	"partscollect.h"
#include	"../amgame.h"
#include	"vivacious_spring.h"
#include	"vivacious_spring_parts.h"
#include	"../system/common.h"
int cgPartsRecovery[PARTS_ANIME_MAX] = { 0 };
PARTSCOLLECT pc;
void LoadPartscollect()
{
	LoadBlkTexture(PARTSCOLLECT_CG, 120, 120,
		6, 1, 6, cgPartsRecovery);
}
void InitPartscollect()
{
	pc.x = 1160;
	pc.y = 0;
	GetPictureSize(cgPartsRecovery[0],&pc.w,&pc.h);
}
void DrawPartscollect()
{
	SetDrawArea(0, 0, DISP_W, DISP_H);
	DrawMemTh(pc.x, pc.y, cgPartsRecovery[gParts]);
}