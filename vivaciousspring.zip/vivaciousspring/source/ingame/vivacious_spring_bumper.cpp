#include	"vivacious_spring_bumper.h"
#include	"../amgame.h"
#include	"../system/common.h"
#include	"vivacious_spring_game.h"
#include	"vivacious_spring_player.h"
#include	"vivacious_spring_camera.h"
#include	"../outgame/charselect.h"
#include	"../system/vivacious_spring_se.h"
#include	"../outgame/game_setting.h"
int cg_gimmick_bumper_s[BUMPER_CG_MAX] = {0};
int cg_gimmick_bumper_m[BUMPER_CG_MAX] = { 0 };
int cg_gimmick_bumper_l[BUMPER_CG_MAX] = {0};
//�S��D.K
//��������
void LoadBumper()
{
	 LoadBlkTexture("res/gimmick_bumper_s.png",BUMPER_S_W_H, BUMPER_S_W_H,3,1,3*1,cg_gimmick_bumper_s);
	 LoadBlkTexture("res/gimmick_bumper_m.png", BUMPER_M_W_H, BUMPER_M_W_H, 3, 1, 3 * 1, cg_gimmick_bumper_m);
	 LoadBlkTexture("res/gimmick_bumper_l.png", BUMPER_L_W_H, BUMPER_L_W_H, 3, 1, 3 * 1, cg_gimmick_bumper_l);
}

int BumperCg(int i)
{
	int no = 0;
	if (chara[i].hit == 1)
	{
		no = (chara[i].frame / B_CG_CUT_FRAME) % 2;
		no += 1;
	}
	switch (chara[i].kind)
	{
	case 1:
		return cg_gimmick_bumper_s[no];
		break;
	case 2:
		return cg_gimmick_bumper_m[no];
		break;
	case 3:
		return cg_gimmick_bumper_l[no];
		break;
	}
	return -1;
}


//�o���p�[�̕����������߂邽�߂ɃO���t�B�b�N��1���ڂ̑傫���𒲂ׂ�i��ނɂ�蔻�ʁj
int InitBumperwh(int kind)
{
	switch (kind)
	{
	case 1:
		return cg_gimmick_bumper_s[0];
		break;
	case 2:
		return cg_gimmick_bumper_m[0];
		break;
	case 3:
		return cg_gimmick_bumper_l[0];
		break;
	}
	return -1;
}


//�e�X�e�[�W�ɔz�u����Ă���o���p�[�̍ő吔��Ԃ�
int BumperMax()
{
	switch (gNowstage)
	{
	case STAGE_2:
		return BUMPER_MAX_2;
		break;
	case STAGE_3:
		return BUMPER_MAX_3;
		break;
	case STAGE_4:
		return BUMPER_MAX_4;
		break;
	}
	return -1;
}
void InitBumper()
{
	int x2[BUMPER_MAX_2]=
	{
		5560,6000,6760,6840,6920,
		7000,7840,8160,10440,10720,
		11200,13000,6760
	};
	int y2[BUMPER_MAX_2]=
	{
		280,280,120,80,40,
		0,360,0,200,200,
		200,360,440
	};
	int kind[BUMPER_MAX_2]=
	{
		BS,BS,BS,BS,BS,BS,BS,BS,BS,BS,BS,
		BS,
		BM
	};
	int x3[BUMPER_MAX_3]=
	{
		640,560,1040,600,1000,640,960,680,920,240,840,600,640,
		560,
		1120,560,760,960,600
	};
	int y3[BUMPER_MAX_3]=
	{
		200 ,4000 ,4000 ,4080 ,4080 ,4160 ,4160,4240 ,4240 ,12440 ,13240 ,18640 ,19040 ,
		16920 ,
		360 ,4680 ,4680 ,4680 ,17720 ,
	};
	int kind3[BUMPER_MAX_3]=
	{
		BS,BS,BS,BS,BS,BS,BS,BS,BS,BS,BS,BS,BM,
		BM,
		BL,BL,BL,BL,BL
	};
	int x4[BUMPER_MAX_4]=
	{
		5160,

		2840,4600,5920
	};

	int y4[BUMPER_MAX_4]=
	{
		3520,

		440,0,1880
	};

	int kind4[BUMPER_MAX_4]=
	{
		BS,

		BL,BL,BL
	};
	int stage_max = BumperMax();
	int bumper;
	for (int i = 0; i < stage_max; i++)
	{

		int cg = InitBumperwh(kind[i]);
		int hit_x = 0;
		int hit_y = 0;
		int hit_w = 0;
		int hit_h = 0;
		if (kind[i] == BS)
		{
			hit_x = -40;
			hit_y = -80;
			hit_w = 80;
			hit_h = 80;
		}
		if (kind[i] == BM)
		{
			hit_x = -60;
			hit_y = -120;
			hit_w = 120;
			hit_h = 120;
		}
		if (kind[i] == BL)
		{
			hit_x = -80;
			hit_y = -160;
			hit_w = 160;
			hit_h = 160;
		}
		InitChara(
		STAGE_2,CHARACTERTYPE_BUMPER,cg,
		x2[i],y2[i] + 560,0,0,0,1,0,0,hit_x,hit_y,hit_w,hit_h,i,0,kind[i]
		);
		
		if (gNowstage == STAGE_2)
		{
			bumper = CheckCharaType(CHARACTERTYPE_BUMPER, i);
			if (chara[bumper].kind == BS)
			{
				chara[bumper].dx -=8;
				chara[bumper].dy -=8;
				
			}
			else if (chara[bumper].kind == BM)
			{
				chara[bumper].dx -=10;
				chara[bumper].dy -=10;
				
			}
			else if (chara[bumper].kind == BL)
			{
				chara[bumper].dx -=15;
				chara[bumper].dy -=15;
			}
		}
		cg = InitBumperwh(kind3[i]);
		
		if (kind3[i] == BS)
		{
			hit_x = -40;
			hit_y = -80;
			hit_w = 80;
			hit_h = 80;
		}
		if (kind3[i] == BM)
		{
			hit_x = -60;
			hit_y = -120;
			hit_w = 120;
			hit_h = 120;
		}
		if (kind3[i] == BL)
		{
			hit_x = -80;
			hit_y = -160;
			hit_w = 160;
			hit_h = 160;
		}
		InitChara(
			STAGE_3, CHARACTERTYPE_BUMPER, cg,
			x3[i], y3[i] + 40, 0, 0, 0, 1, 0, 0, hit_x, hit_y, hit_w, hit_h, i, 0, kind3[i]
		);
		
		if (gNowstage == STAGE_3)
		{
			bumper = CheckCharaType(CHARACTERTYPE_BUMPER, i);
			if (chara[bumper].kind == BS)
			{
				chara[bumper].dx -=8;
				chara[bumper].dy -=8;
				
			}
			else if (chara[bumper].kind == BM)
			{
				chara[bumper].dx -=10;
				chara[bumper].dy -=10;
			}
			else if (chara[bumper].kind == BL)
			{
				chara[bumper].dx -= 15;
				chara[bumper].dy -= 15;
			}
		}
		if (kind4[i] == BS)
		{
			hit_x = -40;
			hit_y = -80;
			hit_w = 80;
			hit_h = 80;
		}
		if (kind4[i] == BM)
		{
			hit_x = -60;
			hit_y = -120;
			hit_w = 120;
			hit_h = 120;
		}
		if (kind4[i] == BL)
		{
			hit_x = -80;
			hit_y = -160;
			hit_w = 160;
			hit_h = 160;
		}
		cg = InitBumperwh(kind4[i]);
		InitChara(
			STAGE_4, CHARACTERTYPE_BUMPER, cg,
			x4[i], y4[i] + 800, 0, 0, 0, 1, 0, 0, hit_x, hit_y, hit_w, hit_h, i, 0, kind4[i]
		);
		
		if (gNowstage == STAGE_4)
		{
			bumper = CheckCharaType(CHARACTERTYPE_BUMPER, i);
			if (chara[bumper].kind == BS)
			{
				chara[bumper].dx -=8;
				chara[bumper].dy -=8;
			}
			else if (chara[bumper].kind == BM)
			{
				chara[bumper].dx = -10;
				chara[bumper].dy = -10;
			}
			else if (chara[bumper].kind == BL)
			{
				chara[bumper].dx -= 15;
				chara[bumper].dy -= 15;
			}
		}
	}
}
int BumperPlayerSpdx(int player,int bumper)
{
	if(
		(chara[player].x > (chara[bumper].x - (chara[bumper].hit_w / 4)))&&
		(chara[player].x < (chara[bumper].x + (chara[bumper].hit_w / 4)))
		)
	{
		chara[player].spd_x = 0;
		if (character == 1) {
			if (gKey&KEYIN_RIGHT) {

				if (chara[bumper].kind == 1) {
					chara[player].direction = 1;
					chara[player].spd_x = 6;
				}
				if (chara[bumper].kind == 2) {
					chara[player].direction = 1;
					chara[player].spd_x = 7;
				}
				if (chara[bumper].kind == 3) {
					chara[player].direction = 1;
					chara[player].spd_x = 8;
				}

			}
			if (gKey&KEYIN_LEFT) {
				if (chara[bumper].kind == 1) {
					chara[player].spd_x = -6;
					chara[player].direction = -1;
				}
				if (chara[bumper].kind == 2) {
					chara[player].direction = -1;
					chara[player].spd_x = -7;
				}
				if (chara[bumper].kind == 3) {
					chara[player].direction = -1;
					chara[player].spd_x = -8;
				}
			}
		}
		else {/*�o�l�b�T*/
			if (gKey&KEYIN_RIGHT) {

				if (chara[bumper].kind == 1) {
					chara[player].direction = 1;
					chara[player].spd_x = 6;
				}
				if (chara[bumper].kind == 2) {
					chara[player].direction = 1;
					chara[player].spd_x = 8;
				}
				if (chara[bumper].kind == 3) {
					chara[player].direction = 1;
					chara[player].spd_x = 9;
				}

			}
			if (gKey&KEYIN_LEFT) {
				if (chara[bumper].kind == 1) {
					chara[player].spd_x = -6;
					chara[player].direction = -1;
				}
				if (chara[bumper].kind == 2) {
					chara[player].direction = -1;
					chara[player].spd_x = -8;
				}
				if (chara[bumper].kind == 3) {
					chara[player].direction = -1;
					chara[player].spd_x = -9;
				}
			}
		}
		return chara[player].spd_x;
	}
	if (character == 1) {
		if (chara[player].x < (chara[bumper].x - (chara[bumper].hit_w / 4))) {
			if (chara[bumper].kind == 1) {
				chara[player].spd_x = -6;
			}
			if (chara[bumper].kind == 2) {
				chara[player].spd_x = -7;
			}
			if (chara[bumper].kind == 3) {
				chara[player].spd_x = -8;
			}
			return chara[player].spd_x;
		}

		if (chara[player].x > (chara[bumper].x + (chara[bumper].hit_w / 4))) {
			if (chara[bumper].kind == 1) {
				chara[player].spd_x = 6;
			}
			if (chara[bumper].kind == 2) {
				chara[player].spd_x = 7;
			}
			if (chara[bumper].kind == 3) {
				chara[player].spd_x = 8;
			}
			return chara[player].spd_x;
		}
	}
	else {/*�o�l�b�T*/
		if (chara[player].x < (chara[bumper].x - (chara[bumper].hit_w / 4))) {
			if (chara[bumper].kind == 1) {
				chara[player].spd_x = -6;
			}
			if (chara[bumper].kind == 2) {
				chara[player].spd_x = -8;
			}
			if (chara[bumper].kind == 3) {
				chara[player].spd_x = -9;
			}
			return chara[player].spd_x;
		}

		if (chara[player].x > (chara[bumper].x + (chara[bumper].hit_w / 4))) {
			if (chara[bumper].kind == 1) {
				chara[player].spd_x = 6;
			}
			if (chara[bumper].kind == 2) {
				chara[player].spd_x = 8;
			}
			if (chara[bumper].kind == 3) {
				chara[player].spd_x = 9;
			}
			return chara[player].spd_x;
		}
	}
	return chara[player].spd_x;
}
double BumperPlayerGr(int player, int bumper)
{

	if(
		(chara[player].y - (chara[player].hit_h / 2) > (chara[bumper].y - (chara[bumper].hit_h  * 3 / 4))) &&
		(chara[player].y - (chara[player].hit_h / 2) < (chara[bumper].y - (chara[bumper].hit_h / 4)))
		)
	{
		if (character == 1) {
			if (chara[bumper].kind == 1) {
				chara[player].gr = -8;
			}
			if (chara[bumper].kind == 2) {
				chara[player].gr = -10;
			}
			if (chara[bumper].kind == 3) {
				chara[player].gr = -12;
			}
		}
		else 			{/*�o�l�b�T*/
			if (chara[bumper].kind == 1) {
				chara[player].gr = -8;
			}
			if (chara[bumper].kind == 2) {
				chara[player].gr = -12;
			}
			if (chara[bumper].kind == 3) {
				chara[player].gr = -15;
			}
		}
		return chara[player].gr;
	}
	if(chara[player].y - (chara[player].hit_h / 2) < chara[bumper].y - (chara[bumper].hit_h  * 3 / 4))
	{
		if (character == 1) {
			if (chara[bumper].kind == 1) {
				chara[player].gr = -10;
			}
			if (chara[bumper].kind == 2) {
				chara[player].gr = -13;
			}
			if (chara[bumper].kind == 3) {
				chara[player].gr = -21;
			}
		}
		else {/*�o�l�b�T*/
			if (chara[bumper].kind == 1) {
				chara[player].gr = -10;
			}
			if (chara[bumper].kind == 2) {
				chara[player].gr = -16;
			}
			if (chara[bumper].kind == 3) {
				chara[player].gr = -25;
			}
		}
		return chara[player].gr;
	}
	if(
		(chara[player].y - (chara[player].hit_h / 2) > chara[bumper].y - (chara[bumper].hit_h  / 4))
		)
	{
		if (character == 1) {
			if (chara[bumper].kind == 1) {
				chara[player].gr = 5;
			}
			if (chara[bumper].kind == 2) {
				chara[player].gr = 10;
			}
			if (chara[bumper].kind == 3) {
				chara[player].gr = 15;
			}
		}
		else {/*�o�l�b�T*/
			if (chara[bumper].kind == 1) {
				chara[player].gr = 5;
			}
			if (chara[bumper].kind == 2) {
				chara[player].gr = 10;
			}
			if (chara[bumper].kind == 3) {
				chara[player].gr = 15;
			}
		}
		return chara[player].gr;
	}
	return chara[player].gr;
}

void ProcessBumper()
{
	
		int player = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);
		int stage_bumper_max = BumperMax();
		for (int i = 0; i < stage_bumper_max; i++)
		{
			int bumper = CheckCharaType(CHARACTERTYPE_BUMPER, i);
			if (chara[bumper].frame > B_CG_CUT_FRAME * (BUMPER_CG_MAX - 1))
			{
				chara[bumper].frame = 0;
				chara[bumper].hit = false;
			}
			if (
				HitChara(player, bumper) == 1
				)
			{
				chara[player].spd_x = BumperPlayerSpdx(player, bumper);
				chara[player].gr = BumperPlayerGr(player, bumper);
				StopInVoice();
				chara[bumper].hit = true;
				if (character == 1)
				{
					if (voice_button2 == false)
					PlayMemBack(in_voice[BUMPER_B].handle);
				}
				else
				{
					if (voice_button2 == false)
					PlayMemBack(in_voice[BUMPER_V].handle);
				}
				if (se_button == false)
				PlayMemBack(in_se[BUMPER].handle);
				chara[player].state = PLAYER_STATE_BUMPER;

			}
			if (chara[bumper].hit == 1)
			{
				chara[bumper].frame++;
			}
			
		}
}
//�����܂�