#pragma once
#define JAMPGAGEMAX 6
#define JAMPGAGECG "res/jump_gage.png"
#define JAMPGAGE_WIDTH 480
#define	JAMPGAGE_HEIGHT 240
typedef struct
{
	int x,y;
	int w,h;
	int cgno;
}JAMPGAGE;
extern JAMPGAGE jg;
extern int jump_gage[JAMPGAGEMAX];
extern void LoadJampGage();
extern void InitJampGage();
extern void ProcessJampGage();
extern void DrawJampGage();
