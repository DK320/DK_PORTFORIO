#pragma once

extern void LoadGimmickDescription();
extern void DrawGimmickDescription();
extern int gimmick_description_1;
extern int gimmick_description_2;
extern int gimmick_description_3;
