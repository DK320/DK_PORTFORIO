#pragma once
//
//�萔�E�\���̒�`
//

//�}�b�v�T�C�Y�i�`�b�v���j
//.tmx�̈ȉ����ݒ�
// <layer name="�^�C���E���C���[1"
//width="323" height="32" offsetx="298" offsety="18">
#define		MAPSIZE_W_STAGE1	323
#define		MAPSIZE_W_STAGE2	433
#define		MAPSIZE_W_STAGE3	32
#define		MAPSIZE_W_STAGE4	152

			//width
#define		MAPSIZE_H_STAGE1		32
#define		MAPSIZE_H_STAGE2		32
#define		MAPSIZE_H_STAGE3		600
#define		MAPSIZE_H_STAGE4		110

			//height

//���C���[��
#define		MAPSIZE_LAYER_STAGE1 2
#define		MAPSIZE_LAYER_STAGE2 2
#define		MAPSIZE_LAYER_STAGE3 2
#define		MAPSIZE_LAYER_STAGE4 3


//�`�b�v�摜�̌�
//.tmx�̈ȉ����ݒ�
// <tileset firstgid="1" name="mapchip_1_floor" 
//tilewidth="40" tileheight="40" tilecount="16" columns="4">

//�`�b�v�̌�
#define		CHIPCOUNT_STAGE1		16
#define		CHIPCOUNT_STAGE2		16		
#define		CHIPCOUNT_STAGE3		16
#define		CHIPCOUNT_STAGE4		20
		//tilecount
#define		CHIPCOUNT_W_STAGE		4
		//columns
#define		CHIPCOUNT_H_STAGE		(CHIPCOUNT_STAGE1 / CHIPCOUNT_W_STAGE)
		//�v�Z�ŏo��

//�`�b�v�̃T�C�Y�ipixel���j
#define		CHIPSIZE_W_STAGE		40
#define		CHIPSIZE_H_STAGE		40


extern int nMap[MAPSIZE_LAYER_STAGE1 * MAPSIZE_W_STAGE1 * MAPSIZE_H_STAGE1];
extern int nMap2[MAPSIZE_LAYER_STAGE2 * MAPSIZE_W_STAGE2 * MAPSIZE_H_STAGE2];
extern int nMap3[MAPSIZE_LAYER_STAGE3 * MAPSIZE_W_STAGE3 * MAPSIZE_H_STAGE3];
extern int nMap4[MAPSIZE_LAYER_STAGE4 * MAPSIZE_W_STAGE4 * MAPSIZE_H_STAGE4];

extern int cgChip1[CHIPCOUNT_STAGE1];
extern int cgChip2[CHIPCOUNT_STAGE2];
extern int cgChip3[CHIPCOUNT_STAGE3];
extern int cgChip4[CHIPCOUNT_STAGE4];


extern int Stagelayer();
extern void LoadMapdate();
extern void DrawMap();

extern int WhereMap(int layerstart, int index);
extern int Chip(int chip_no, int layer);