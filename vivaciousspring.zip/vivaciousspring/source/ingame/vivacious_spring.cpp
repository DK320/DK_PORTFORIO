/*
** �Q�[���{��
*/

//
// �g�������@�\�▽�߂ɂ��킹�� include ��ǉ�����
//
#include	<Windows.h>
#include	"../amgame.h"
#include	"../AmHelper.h"
#include	"../utility.h"
#include	<math.h>
#include	"vivacious_spring.h"
#include	"vivacious_spring_mapdata1.h"
#include	"vivacious_spring_player.h"
#include	"vivacious_spring_camera.h"
#include	"vivacious_spring_bg.h"
#include	"../system/common.h"
#include	"vivacious_spring_parts.h"
#include	"../outgame/vivacious_spring_option.h"
#include	"../outgame/vivacious_spring_title.h"
#include	"../outgame/vivacious_spring_pause.h"
#include	"vivacious_spring_floor.h"
#include	"../outgame/vivacious_spring_clear.h"
#include	"../system/vivacious_spring_se.h"
#include	"vivacious_spring_game.h"
#include	"vivacious_spring_gameover.h"
#include	"../outgame/vivacious_spring_selectstage.h"
#include	"../system/vivacious_spring_bgm.h"
#include	"vivacious_spring_time.h"

#include	"vivacious_spring_geyser.h"
#include	"vivacious_spring_save.h"
#include	"vivacious_spring_bumper.h"
#include	"vivacious_spring_jamp_gage.h"
#include	"vivacious_spring_switch.h"
#include	"../outgame/game_setting.h"
#include	"../outgame/record.h"
#include	"../outgame/story1.h"
#include	"../outgame/charselect.h"
#include	"frame.h"
#include	"partscollect.h"
#include	"../system/lightspot.h"
#include	"../outgame/story2.h"
#include	"../outgame/credit.h"
#include	"gimmick_description.h"

#include"coin_ui.h"
//
// �O���[�o���ϐ��錾
//
int nowstate = STATE_TITLE;
int gKey = 0;
int gTrg = 0;
int gFramecount = 0;
int gFramecount2 = 0;
int g_alpha = 0;
int g_alpha2 = 0;
int g_alpha3 = 0;
int g_alpha4 = 0;//�^�C�g����ʎ��̂̃t�F�C�h
int g_al = 20;
int temp = 0;



struct CAMERA cv;
struct CURSOR cu;
struct CURSOR cu2;
struct CHARACTER chara[CHARACTER_MAX];
void InitCursor()
{
	cursor1.x = 360;//�^�C�g���J�[�\��
	cursor1.y = 350;

	cursor2.x = 320;//�^�C�g���J�[�\��
	cursor2.y = 600;

	cursor3.x = 120;//�Q�[���I�[�o�[�J�[�\��
	cursor3.y = 620;

	cursor4.x = 700;//�Q�[���I�[�o�[�J�[�\��
	cursor4.y = 620;

	cursor5.x = 50;//�X�e�[�W�Z���N�g�J�[�\��
	cursor5.y = 180;

	cursor6.x = 250;
	cursor6.y = 560;

	cursor7.x = 450;
	cursor7.y = 180;

	cursor8.x = 650;
	cursor8.y = 560;

	cursor9.x = 850;
	cursor9.y = 180;

	cu.x = 400;//�|�[�Y�J�[�\��
	cu.y = 300;

	cu2.x = 390;//�|�[�Y�J�[�\��
	cu2.y = 500;

}


//
//�Q�[�����
//


// �A�v���̏�����
// �N������1�񂾂����s�����
void AppInit() {

	InitFrame();/*�t���[���̏�����*/
	LoadBgm();
	LoadBg();
	LoadMapdate();
	LoadPlayer();
	LoadPause();
	LoadPartscollect();

	cgCursor = LoadTexture("res/cursor.png");
	cgTitleback = LoadTexture("res/wallpaper_title.png");
	cgTitle_logo = LoadTexture("res/title_logo.png");
	cgStartOn = LoadTexture("res/start_on.png");
	cgStartOff = LoadTexture("res/start_off.png");
	cgOptionOn = LoadTexture("res/option_on.png");
	cgOptionOff = LoadTexture("res/option_off.png");

	cgSetting_wallpaper = LoadTexture("res/wallpaper_setting.png");
	cgSetting_record_On = LoadTexture("res/setting_record_on.png");
	cgSetting_record_Off = LoadTexture("res/setting_record_off.png");
	cgSetting_setting_On = LoadTexture("res/setting_setting_on.png");
	cgSetting_setting_Off = LoadTexture("res/setting_setting_off.png");
	cgOption_bgm = LoadTexture("res/option_bgm.png");;
	cgOption_se = LoadTexture("res/option_se.png");
	cgOption_voice = LoadTexture("res/option_voice.png");
	cgOption_dot = LoadTexture("res/option_dot.png");

	cgRecordScreen = LoadTexture("res/cloud_record.png");

	
	
	cgCloud_start = LoadTexture("res/cloud_start.png");
	cgCloud_option = LoadTexture("res/cloud_option.png");
	cgCloudM = LoadTexture("res/cloudm.png");
	cgCloudS = LoadTexture("res/clouds.png");
	cgWallPaper = LoadTexture("res/wallpaper_ss.png");
	cgRoad = LoadTexture("res/road_ss.png");
	cgCursorss_on = LoadTexture("res/cursol_ss_on.png");
	cgCursorss_off = LoadTexture("res/cursol_ss_off.png");
	cgCloud_stage1 = LoadTexture("res/cloud_stage_1.png");
	cgCloud_stage2 = LoadTexture("res/cloud_stage_2.png");
	cgCloud_stage3 = LoadTexture("res/cloud_stage_3.png");
	cgCloud_stage4 = LoadTexture("res/cloud_stage_4.png");
	cgCloud_stage5 = LoadTexture("res/cloud_stage_5.png");
	cgCloud_opening = LoadTexture("res/cloud_opening.png");
	cgCloud_ending = LoadTexture("res/cloud_ending.png");
	cgCoin_Collect = LoadTexture("res/coin_collect.png");

	cgGameOver = LoadTexture("res/gameover.png");
	cgContinue_message = LoadTexture("res/continue_message.png");
	cgContinue_yes_on = LoadTexture("res/continue_yes_on.png");
	cgContinue_yes_off = LoadTexture("res/continue_yes_off.png");
	cgContinue_no_on = LoadTexture("res/continue_no_on.png");
	cgContinue_no_off = LoadTexture("res/continue_no_off.png");
	cgClearBg = LoadTexture("res/background_clear.png");
	cgClear = LoadTexture("res/gameclear_message.png");
	cgClearRank = LoadTexture("res/clear_rank.png");
	cgSrank = LoadTexture("res/chara_s.png");
	cgArank = LoadTexture("res/chara_a.png");
	cgBrank = LoadTexture("res/chara_b.png");
	cgCrank = LoadTexture("res/chara_c.png");
	cgBlack = LoadTexture("res/Black.png");
	cgIcon_a = LoadTexture("res/icon_a.png");


	cgParts0 = LoadTexture("res/parts0.png");
	cgParts1 = LoadTexture("res/parts1.png");
	cgParts2 = LoadTexture("res/parts2.png");
	cgParts3 = LoadTexture("res/parts3.png");
	cgParts4 = LoadTexture("res/parts4.png");
	cgParts5 = LoadTexture("res/parts5.png");

	cgRankScreen = LoadTexture("res/clearrank.png");
	
	cgFrame_b_On = LoadTexture("res/frame_b_on.png");//�L�����I��
	cgFrame_b_Off = LoadTexture("res/frame_b_off.png");
	cgFrame_v_On = LoadTexture("res/frame_v_on.png");
	cgFrame_v_Off = LoadTexture("res/frame_v_off.png");


	cgMoji = LoadTexture("res/moji1.png");
	cgMoji2 = LoadTexture("res/moji2.png");

	cgStory1 = LoadTexture("res/story_1.png");
	cgStory2 = LoadTexture("res/story_2.png");
	cgStory3 = LoadTexture("res/story_3.png");
	
	cgStory5 = LoadTexture("res/story_5.png");
	cgStory6 = LoadTexture("res/story_6.png");
	cgStory7 = LoadTexture("res/story_7.png");
	cgStory8 = LoadTexture("res/story_8.png");
	cgStory9 = LoadTexture("res/story_9.png");
	cgStory10 = LoadTexture("res/story_10.png");
	cgStory11 = LoadTexture("res/story_11.png");
	cgStory12 = LoadTexture("res/story_12.png");
	cgStoryBg = LoadTexture("res/story_bg.png");
	cgStory_t1 = LoadTexture("res/story_t1.png");
	cgStory_t2 = LoadTexture("res/story_t2.png");
	cgStory_t3 = LoadTexture("res/story_t3.png");
	cgStory_t4 = LoadTexture("res/story_t4.png");
	cgStory_t5 = LoadTexture("res/story_t5.png");
	cgStory_t6 = LoadTexture("res/story_t6.png");
	cgStory_t7 = LoadTexture("res/story_t7.png");
	cgStory_t8 = LoadTexture("res/story_t8.png");
	cgStory_t9 = LoadTexture("res/story_t9.png");
	cgStory_t10 = LoadTexture("res/story_t10.png");
	cgStory_t11 = LoadTexture("res/story_t11.png");
	cgStory_t12 = LoadTexture("res/story_t12.png");
	cgStory_t13 = LoadTexture("res/story_t13.png");
	cgStory_t14 = LoadTexture("res/story_t14.png");
	cgStory_t15 = LoadTexture("res/story_t15.png");
	cgStory_t16 = LoadTexture("res/story_t16.png");
	cgStory_t17 = LoadTexture("res/story_t17.png");
	cgStory_t18 = LoadTexture("res/story_t18.png");
	cgStory_t19 = LoadTexture("res/story_t19.png");
	cgStory_t20 = LoadTexture("res/story_t20.png");
	cgStory_t21 = LoadTexture("res/story_t21.png");
	cgStory_t22 = LoadTexture("res/story_t22.png");
	cgStory_t23 = LoadTexture("res/story_t23.png");
	cgStory_t24 = LoadTexture("res/story_t24.png");
	cgStory_t25 = LoadTexture("res/story_t25.png");
	cgStory_t26 = LoadTexture("res/story_t26.png");
	cgStory_t27 = LoadTexture("res/story_t27.png");
	cgStory_t28 = LoadTexture("res/story_t28.png");
	cgStory_t29 = LoadTexture("res/story_t29.png");
	cgStory_t30 = LoadTexture("res/story_t30.png");
	cgStory_t31 = LoadTexture("res/story_t31.png");
	cgStory_t32 = LoadTexture("res/story_t32.png");
	cgStory_t33 = LoadTexture("res/story_t33.png");
	cgStory_t34 = LoadTexture("res/story_t34.png");
	cgStage_name1 = LoadTexture("res/stage_name_1.png");
	cgStage_name2 = LoadTexture("res/stage_name_2.png");
	cgStage_name3 = LoadTexture("res/stage_name_3.png");
	cgStage_name4 = LoadTexture("res/stage_name_4.png");

	cgCredit = LoadTexture("res/credit.png");

	/*cgCredit = LoadTexture("res/bg.png");*/
	LoadBlkTexture("res/number_other.png",
		(TIME_W / TIME_W_QUANTITY),
		(TIME_H / TIME_H_QUANTITY),
		TIME_W_QUANTITY,
		TIME_H_QUANTITY,
		(TIME_W_QUANTITY * TIME_H_QUANTITY), cgSuuji);
	LoadBlkTexture("res/number_coin_collect.png",
		(150 / TIME_W_QUANTITY),
		(126 / TIME_H_QUANTITY),
		TIME_W_QUANTITY,
		TIME_H_QUANTITY,
		(TIME_W_QUANTITY * TIME_H_QUANTITY), cgSuuji2);
	LoadGimmickDescription();
	LoadFloor();
	LoadSe();
	LoadGoal();
	
	LoadTime();
	LoadGeyser();
	LoadSave();
	LoadBumper();
	LoadJampGage();
	LoadSwitch();
	LoadParts();

	LoadCoinUi();
	Setumei();
	Koma();
	Koma2();
	InitCursor();
	InitCharCur();
	Credit();
	StageMap();
	InitCoinUi();
	InitFlag();
	/*Credit();*/
}


// �t���[�������F����
void FrameInput() {
	int keyold = gKey;
	gKey = CheckKey(AMINPUT_MULT);
	// �L�[�̃g���K��񐶐��i�������u�Ԃ����������Ȃ��L�[���j
	gTrg = (gKey ^ keyold) & gKey;
}


// �t���[�������F�v�Z
void FrameProcess() {
	
	/*��Ԃɂ��P�t���[���̏���*/
	switch (nowstate)
	{
	case STATE_TITLE:
		nowstate = ProcessTitle();
		break;
	case STATE_OPTION:
		nowstate = Option();
		break;
	case STATE_RECORD:
		nowstate = Record();
		break;
	case STATE_GAMESETTING:
		nowstate = GameSetting();
		break;
	case STATE_STORY1:
		nowstate = Story1();
		break;
	case STATE_STAGESELECT:
		nowstate = StartStage();
		
		break;
	case STATE_CHARSELECT:
		nowstate = CharSelect();
		break;
	case STATE_GAME:
		nowstate = Game();
		break;
	case STATE_PAUSE:
		nowstate = Pause();
		break;
	case STATE_GAMEOVER:
		nowstate = Continue();
		gFramecount = 0;
		break;
	case STATE_CLEAR:
		nowstate = Clear();
		break;
	case STATE_CLEARRANK:
		nowstate = ClearRank();
		break;
	case STATE_STORY2:
		nowstate = Story2();
		break;
	case STATE_CREDIT:
		nowstate = MoveCredit();
		break;
	}
	

	f[ALLGAMEFRAME].frame++;
}

void DrawBlack() 	
{
	
	memset(mapLight, 0, sizeof(mapLight));
	int sw;
	int hit = 0;
	
		int player = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);
		if (
			(chara[player].y < 10960) &&
			(chara[player].y > 4000)
			)
		{
			int px = chara[player].x;
			int py = chara[player].y + (chara[player].dy / 2) - cv.view_y;
			int pr = 200;
			// �w��ʒu�Ɍ���������
			LightmapSpot(px, py, pr);
			if (pr < 200) { pr = 200; }
			int x, y;
			for (int i = 0; i < SWITCH_MAX_3; i++)
			{
				sw = CheckCharaType(CHARACTERTYPE_SWITCH, i);
				switch (chara[sw].kind)
				{
				case 2:
					if (chara[sw].hit == 0)
					{
						continue;
					}
					else
					{
						hit = 1;
					}

					break;
				}
			}
			if (hit == 0)
			{
				for (y = 0; y < LIGHTMAP_Y; y++)
				{
					for (x = 0; x < LIGHTMAP_X; x++)
					{
						// �������B�`��񐔂����炷�B
						// ���ɂǂꂾ�����������Ă��邩���m�F����
						int w = 0;
						while (mapLight[y*LIGHTMAP_X + x + w] == 0) { w++; }
						if (w != 0)
						{
							// w��0�ȊO�Ȃ�A���̕��������ɍ���`��
							SetDrawArea(0, 0, DISP_W, DISP_H);
							SetDrawMode(AMDRAW_NOBLEND, 0);
							DrawFBox(x*LIGHTMAP_W, y*LIGHTMAP_H, (x + w)*LIGHTMAP_W, (y + 1)*LIGHTMAP_H, GetColor(0, 0, 0));
							// w�̕�����x��i�߂�
							x += w - 1;
						}
						else
						{
							// w��0�Ȃ̂ŁA������Ȃ�
							int a = mapLight[y*LIGHTMAP_X + x];
							SetDrawArea(0, 0, DISP_W, DISP_H);
							SetDrawMode(AMDRAW_ALPHABLEND, 255 - a);
							DrawFBox(x*LIGHTMAP_W, y*LIGHTMAP_H, (x + 1)*LIGHTMAP_W, (y + 1)*LIGHTMAP_H, GetColor(0, 0, 0));
						}

					}
				}

				SetDrawMode(AMDRAW_NOBLEND, 0);
			}
		}
}
// �t���[�������F�`��
void FrameDraw() {
	
	
	// ��ʂ�����
	HCls();
	// �摜�\��
	// �摜�\���i�`�������ɏ�ɏd�Ȃ�j
	switch (nowstate)
	{
	case STATE_TITLE:			//�^�C�g���`��
		DrawTitle();
		break;
	case STATE_OPTION:			//��������
		DrawSettingBg();
		DrawOption();
		break;
	case STATE_RECORD:			/*���R�[�h���*/
		DrawSettingBg();
		DrawRecord();
		break;
	case STATE_GAMESETTING:	
		DrawSettingBg();
		DrawGameSetting();		/*�I�v�V�������*/
		break;
	case STATE_STORY1:			/*�X�g�[���[���*/
		if (gStep == STORY_STEP1) {
			DrawStory1();
		}
		if (gStep == STORY_STEP2) {
			DrawStoryBg();
			DrawStory2();


		}
		if (gStep == STORY_STEP3) {
			DrawStoryBg2();
			DrawStory3();
		}
		if (gStep == STORY_STEP4)
		{
			DrawStoryBg();
			DrawStory4();
		}
		if (gStep == STORY_STEP5)
		{
			DrawStoryBg2();
			DrawStory5();

		}
		
		break;
	case STATE_STAGESELECT:		/*�X�e�[�W�Z���N�g���*/
		DrawSelect();
		break;
	case STATE_CHARSELECT:		/*�L�����Z���N�g���*/
		DrawCharSelect();
		break;
	case STATE_GAME:			/*�Q�[�����*/
	case STATE_PAUSE:			/*�|�[�Y���*/
	case STATE_GAMEOVER:		/*�Q�[���I�[�o�[���*/
	case STATE_CLEAR:			/*�N���A���*/
		switch (gNowstage)
		{
		case STAGE_1:
		case STAGE_2:
		case STAGE_3:
		case STAGE_4:
			DrawBg();						/*�w�i*/
			DrawMap();						/*�}�b�v�`�b�v*/
			DrawGimmickDescription();
			DrawChara();					/*�L�����N�^�[�i�I�u�W�F�N�g�܂݁j*/
			if (gNowstage == STAGE_3)
			{
				DrawBlack();				/*�X�|�b�g���C�g*/
			}
			DrawTime();						/*�^�C��*/
			DrawCoinUi();
			DrawJampGage();					/*�W�����v�Q�[�W*/
			DrawPartscollect();				/*�p�[�c���W��*/
			/*DrawDamageEffect();*/
			if (nowstate == STATE_PAUSE)
			{
				DrawPause();				/*�|�[�Y���*/
			}
			if (nowstate == STATE_GAMEOVER)
			{
				DrawGameOver();
			}
			if (nowstate == STATE_CLEAR)
			{
				DrawClear();
			}
		
			break;

		}
		break;
	case STATE_CLEARRANK:		/*�N���A�����N���*/
		
		DrawClearRank();
		break;
	case STATE_STORY2:
		if (gStep == STORY_STEP6)
		{
			
			DrawStory6();
		}
		if (gStep == STORY_STEP7)
		{
			DrawStoryBg();
			DrawStory7();
		}
		if (gStep == STORY_STEP8)
		{
			DrawStoryBg();
			DrawStory8();
		}
		if (gStep == STORY_STEP9)
		{
			DrawStoryBg();
			DrawStory9();
		}
		if (gStep == STORY_STEP10)
		{
			DrawStoryBg2();
			DrawStory10();
		}
		if (gStep == STORY_STEP11)
		{
			DrawStoryBg();
			DrawStory11();
		}
		if (gStep == STORY_STEP12)
		{
			DrawStoryBg2();
			DrawStory12();
		}
		break;
	case STATE_CREDIT:
		DrawCredit();
		break;
	}
	SetAMDebugMode(AMDEBUG_ALL_OFF);
	// �X�V
	Flip();
}

// �A�v���̉��
// �I������1�񂾂����s�����
void AppRelease() {
}
