#pragma once
#define BS 1
#define BM 2
#define BL 3
#define B_CG_CUT_FRAME 5
#define BUMPER_S_W_H 96  
#define BUMPER_M_W_H 140 
#define BUMPER_L_W_H 190
#define BUMPER_MAX_2 13
#define BUMPER_MAX_3 19
#define BUMPER_MAX_4 4

#define	BUMPER_CG_MAX 3
extern int cg_gimmick_bumper_m[BUMPER_CG_MAX];
extern int cg_gimmick_bumper_s[BUMPER_CG_MAX];
extern int cg_gimmick_bumper_l[BUMPER_CG_MAX];
extern int g_frame_switch_interval;
extern void LoadBumper();
extern void ProcessBumper();
extern void InitBumper();
extern int BumperCg(int i);