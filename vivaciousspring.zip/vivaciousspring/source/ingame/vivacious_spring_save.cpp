#include	"vivacious_spring_save.h"
#include	"../system/common.h"
#include	"../amgame.h"
#include	"vivacious_spring_game.h"
#include	"vivacious_spring_camera.h"
#include	"../system/vivacious_spring_se.h"
#include	"../outgame/game_setting.h"
int cg_gimmick_savepoint[SAVEPOINTCG_MAX] = {0};
void LoadSave()
{
	 LoadBlkTexture("res/gimmick_savepoint.png",120,100,2,3,2*3, cg_gimmick_savepoint);
}
void InitSave()
{
	InitChara(
		STAGE_2,CHARACTERTYPE_SAVE, cg_gimmick_savepoint[0],
		7460,220 + 560,0,0,0,1,0,0,-50,-120,100,120,1,0,0
		);
	InitChara(
		STAGE_3, CHARACTERTYPE_SAVE, cg_gimmick_savepoint[0],
		630, 11160+20 + 40, 0, 0, 0, 1, 0, 0, -50, -120, 100, 120, 1, 0, 0
	);
	int save = CheckCharaType(CHARACTERTYPE_SAVE,1);
	chara[save].save = false;
}

int CgSave(int i)
{
	int no = 0;
	if (chara[i].hit == 1)
	{
		no = (chara[i].frame / S_CG_CUT_FRAME) % (SAVEPOINTCG_MAX-1);
		no += 1;
	}
	return cg_gimmick_savepoint[no];
}
void ProcessSave()
{
	int save, player;
	switch (gNowstage)
	{
	case STAGE_2:
	case STAGE_3:
		save = CheckCharaType(CHARACTERTYPE_SAVE, 1);
			player = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);
			
			if (HitChara(save, player) == 1)
			{
				if (chara[save].hit == false)
				{
					chara[save].hit = true;
				}
				if (chara[player].save == false)
				{
					if (se_button == false)
					PlayMemBack(in_se[SAVEPOINT].handle);
				}
				chara[player].save = true;
			}
			if (chara[save].hit == 1)
			{
				chara[save].frame++;
			}
			if (chara[save].frame > 23)
			{
				chara[save].frame = 24;
			}
		break;
	}
	
	
}