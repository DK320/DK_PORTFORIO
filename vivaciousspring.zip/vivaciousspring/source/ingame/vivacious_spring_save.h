#pragma once
#define SAVEPOINTCG_MAX 6
#define S_CG_CUT_FRAME 5
extern int cg_gimmick_savepoint[SAVEPOINTCG_MAX];
extern void InitSave();
extern void LoadSave();
extern void ProcessSave();
extern int CgSave(int i);