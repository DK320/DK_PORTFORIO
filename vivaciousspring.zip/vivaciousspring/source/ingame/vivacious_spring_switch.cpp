#include	"../amgame.h"
#include	"../system/common.h"
#include	"vivacious_spring_switch.h"
#include	"vivacious_spring_game.h"
#include	"vivacious_spring_camera.h"
#include	"../system/vivacious_spring_se.h"
#include	"../outgame/game_setting.h"
#include	"vivacious_spring_mapdata1.h"
int cg_gimmick_switch_1[SWITCH_1_W_MAX * SWITCH_1_H_MAX] = {0};
int cg_gimmick_switch_2[SWITCH_2_W_MAX * SWITCH_2_H_MAX] = {0};
int g_frame_switch_interval =0;
int g_HitSwitchKind = 2;
void SwitchMap()/*�X�e�[�W4�̃X�C�b�`�ƏՓ˂����ꍇ�̏���*/
{
	int x,y,layer;
	for(int i=0; i<SWITCH_MAX_4; i++)
	{
		int sw=CheckCharaType(CHARACTERTYPE_SWITCH,i);
		if(chara[sw].hit==1)
		{
			switch(chara[sw].kind)
			{
			case 1:
				for(layer=0; layer<MAPSIZE_LAYER_STAGE4; layer++)
				{
					for(y=0; y<MAPSIZE_H_STAGE4; y++)
					{
						for(x=0; x<MAPSIZE_W_STAGE4; x++)
						{
							int index=y*MAPSIZE_W_STAGE4+x;
							int layerstart=MAPSIZE_W_STAGE4*MAPSIZE_H_STAGE4  * layer;
							int chip_no=nMap4[layerstart+index];
							int no[]={5,20,-1};
							int i=0;
							while(no[i]!=-1)
							{
								if(no[i]==chip_no)
								{
									if(no[i]==5)
									{
										nMap4[layerstart+index]=15;
									}
									if(no[i]==20)
									{
										nMap4[layerstart+index]=10;
									}
								}
								i++;
							}

						}
					}
				}
				break;
			case 2:
				for(layer=0; layer<MAPSIZE_LAYER_STAGE4; layer++)
				{
					for(y=0; y<MAPSIZE_H_STAGE4; y++)
					{
						for(x=0; x<MAPSIZE_W_STAGE4; x++)
						{
							int index=y*MAPSIZE_W_STAGE4+x;
							int layerstart=MAPSIZE_W_STAGE4*MAPSIZE_H_STAGE4  * layer;
							int chip_no=nMap4[layerstart+index];
							int no[]={15,10,-1};
							int i=0;
							while(no[i]!=-1)
							{
								if(no[i]==chip_no)
								{
									if(no[i]==10)
									{
										nMap4[layerstart+index]=20;
									}
									if(no[i]==15)
									{
										nMap4[layerstart+index]=5;
									}
								}
								i++;
							}

						}
					}
				}
				break;
			}
		}
	}
}
void LoadSwitch()
{

	LoadBlkTexture(
		SWITCHCG_1,
		SWITCH_1_W / SWITCH_1_W_MAX,
		SWITCH_1_H / SWITCH_1_H_MAX,
		SWITCH_1_W_MAX,
		SWITCH_1_H_MAX,
		SWITCH_1_W_MAX * SWITCH_1_H_MAX,
		cg_gimmick_switch_1
	);
	LoadBlkTexture(
		SWITCHCG_2,
		SWITCH_2_W / SWITCH_2_W_MAX,
		SWITCH_2_H / SWITCH_2_H_MAX,
		SWITCH_2_W_MAX,
		SWITCH_2_H_MAX,
		SWITCH_2_W_MAX * SWITCH_2_H_MAX,
		cg_gimmick_switch_2
	);
}

//�e�X�e�[�W�̃X�C�b�`�̍ő��
int SwitchMax()
{
	switch (gNowstage)
	{
	case STAGE_2:
		return 1;
		break;
	case STAGE_3:
		return SWITCH_MAX_3;
		break;
	case STAGE_4:
		return SWITCH_MAX_4;
		break;
	}
	return -1;
}
void InitSwitch()
{
	InitChara(
		STAGE_2, CHARACTERTYPE_SWITCH, cg_gimmick_switch_1[0],
		15360, 380, 0, 0, 0, 1, 0, 0, -50, -60, 100, 60, 0, 0, 1
	);
	
	int switch_max = SwitchMax();
	int x3[SWITCH_MAX_3] =
	{
		780,60,0,0,840,
		40,1080,320,60,820,
		840,1140,1140,0,140,
		940,620,620,620,400,620
	};
	int y3[SWITCH_MAX_3]=
	{
		3840  +40,14500 + 60,17520  + 60 ,18520  + 60,23000  + 20 ,
		4480  + 40,4880 + 60,4960  + 60,5640  + 60,6120  + 60 ,
		6440  + 60,6640 + 60,6760  + 40,7680  + 60,8120  + 60 ,
		8520  + 60,9080  + 60,9480  + 60,10000  + 60,10000  + 60,10760  + 60
	};
	int kind3[SWITCH_MAX_3]=
	{
		1,1,1,1,1,
		2,2,2,2,2,
		2,2,2,2,2,
		2,2,2,2,2,2
	};
	

	int x4[SWITCH_MAX_4]=
	{
		2200,2960,3000,5040,5520,
		5960,

		2320,4080,5960
	};
	 int y4[SWITCH_MAX_4]=
	 {
		 2240,1760,2240,800,1920,
		 0,

		 800,2040,840
	 };

	int kind4[SWITCH_MAX_4]=
	{
		1,1,1,1,1,1,

		2,2,2
	};
	int hit4[SWITCH_MAX_4] =
	{
		0,0,0,0,0,0,

		1,1,1
	};
	for (int i = 0; i < switch_max; i++)
	{
		
		InitChara(
			STAGE_3, CHARACTERTYPE_SWITCH, cg_gimmick_switch_1[0],
			x3[i], y3[i], 0, 0, 0, 1, 0, 0, -50, -60, 100, 60, i, 0, kind3[i]
		);
		if (gNowstage == STAGE_3) 
		{
			if (chara[CHARACTERTYPE_SWITCH].no == 12) 
			{
				chara[CHARACTERTYPE_SWITCH].hit_x = -30;
				chara[CHARACTERTYPE_SWITCH].hit_y = -100;
				chara[CHARACTERTYPE_SWITCH].hit_w = 60;
				chara[CHARACTERTYPE_SWITCH].hit_h = 100;
			}
		}
		InitChara(
			STAGE_4, CHARACTERTYPE_SWITCH, cg_gimmick_switch_1[0],
			x4[i], y4[i] + 820, 0, 0, hit4[i], 1, 0, 0, 0,0,0,0, i, 0, kind4[i]
		);
	}
}

//�X�C�b�`�̃A�j���[�V�����؂�ւ�
int ProcessSwitchCgNo(int i)
{
	int no = 0;
	switch (chara[i].kind)
	{
	case 1:
		if (chara[i].hit == 1)
		{
			no = 1;
		}
		return cg_gimmick_switch_1[no];
		break;
	case 2:
		if (chara[i].hit == 1)
		{
			no = 1;
		}
		return cg_gimmick_switch_2[no];
		break;
	}
	return -1;
}

////�ǂꂩ�X�C�b�`���������Ă����ꍇ���̎�ނ�Ԃ�
//int HitSwitchKind()
//{
//	int kind = 0;
//	int sw;
//	for (int i = 0; i < SWITCH_MAX_4; i++)
//	{
//		sw = CheckCharaType(CHARACTERTYPE_SWITCH, i);
//		if (chara[sw].hit == 1)
//		{
//			return chara[sw].kind;
//		}
//	}
//	return 0;
//}
////�������Ă��Ȃ��X�C�b�`�̏ꍇ���̎�ނ�Ԃ�
//int NoHitSwitchkind(int kind)
//{
//
//}

int HitSwitch4(int sw,int player,int k)
{
	
	if (chara[sw].hit == 0)
	{
		if (k == chara[sw].kind)
		{
			chara[sw].hit = 1;
		}
	}
	if (chara[sw].hit == 1)
	{
		if (k != chara[sw].kind)
		{
			
			chara[sw].hit = 0;
		}
	}

	if (HitChara(sw, player) == 1)
	{
		if (chara[sw].hit == 0)
		{
			chara[sw].hit = 1;
			if (se_button == false)
			PlayMemBack(in_se[SWITCH_4].handle);
			k = chara[sw].kind;
			return k;
		}
		if (chara[sw].hit == 1)
		{
			if (chara[sw].kind != k)
			{
				chara[sw].hit = 0;
			}
		}
	}
	
	return k;
}

void ProcessSwitch4()
{

		int player = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);

		for (int i = 0; i < SWITCH_MAX_4; i++)
		{
			int sw = CheckCharaType(CHARACTERTYPE_SWITCH, i);

			g_HitSwitchKind = HitSwitch4(sw, player, g_HitSwitchKind);
		}
	
}

void ProcessSwitch()
{
	
	
		int player = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);
		int switch_max = SwitchMax();
		int mf;
		for (int i = 0; i < switch_max; i++)
		{

			int sw = CheckCharaType(CHARACTERTYPE_SWITCH, i);
			//�X�C�b�`�ƃv���C���[������������

			if (HitChara(sw, player) == 1)
			{
				if (chara[sw].hit == 0)
				{
					if (se_button == false)
					PlayInSe(in_se[SWITCH_23].handle);
				}
				chara[sw].hit = 1;
				
			}
			if (gNowstage == STAGE_3)
			{
				switch (chara[sw].no)
				{

				case 14:
					mf = CheckCharaType(CHARACTERTYPE_MOVEFLOOR, 37);
					chara[sw].y = chara[mf].y + chara[mf].hit_y;
					break;
				case 19:
					mf = CheckCharaType(CHARACTERTYPE_MOVEFLOOR, 26);
					chara[sw].y = chara[mf].y + chara[mf].hit_y;
					break;
				}
				if (chara[sw].kind == 2)
				{
					if (HitChara(sw, player) == 0)
					{
						if (chara[sw].hit == 1)
						{
							g_frame_switch_interval++;
						}
					}
					if (g_frame_switch_interval > 89)
					{
						g_frame_switch_interval = 0;
						chara[sw].hit = 0;
					}
				}
			}
		}
	
	
}