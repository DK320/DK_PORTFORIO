#pragma once
#define	SWITCHCG_1 "res/gimmick_switch_r.png"
#define	SWITCHCG_2 "res/gimmick_switch_g.png"

#define	SWITCH_1_W 200 
#define	SWITCH_1_H 60
#define	SWITCH_2_W 200
#define	SWITCH_2_H 60

#define SWITCH_1_W_MAX 2
#define SWITCH_2_W_MAX 2
#define SWITCH_1_H_MAX 1
#define SWITCH_2_H_MAX 1

#define SWITCH_MAX_3 21
#define SWITCH_MAX_4 9
extern void LoadSwitch();
extern void InitSwitch();
extern int ProcessSwitchCgNo(int);
extern void ProcessSwitch();
extern void ProcessSwitch4();
extern void SwitchMap();
extern int cg_gimmick_switch_1[SWITCH_1_W_MAX * SWITCH_1_H_MAX];
extern int cg_gimmick_switch_2[SWITCH_2_W_MAX * SWITCH_2_H_MAX];
