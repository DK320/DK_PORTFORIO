#include	"vivacious_spring_jamp_gage.h"
#include	"../amgame.h"
#include	"../system/common.h"
#include	"vivacious_spring_player.h"
int jump_gage[JAMPGAGEMAX] ={0};
JAMPGAGE gj;

void LoadJampGage()
{
	LoadBlkTexture(
		JAMPGAGECG,
		JAMPGAGE_WIDTH/ JAMPGAGEMAX,JAMPGAGE_HEIGHT,
		JAMPGAGEMAX,1,
		JAMPGAGEMAX,
		&jump_gage[0]
	);
}
void InitJampGage()
{
	gj.x = 0;
	gj.y = 200;
	gj.w = JAMPGAGE_WIDTH / JAMPGAGEMAX;
	gj.h = JAMPGAGE_HEIGHT;
	gj.cgno = 0;
}
void ProcessJampGage()
{
	
		int player = CheckCharaType(CHARACTERTYPE_PLAYER_MAN, 1);

		gj.cgno = chara[player].jamp_count;
		gj.cgno++;
	
}
void DrawJampGage()
{
	SetDrawMode(AMDRAW_NOBLEND,0);
	SetDrawArea(gj.x, gj.y, gj.x + gj.w, gj.y + gj.h);
	DrawMemTh(gj.x, gj.y,jump_gage[gj.cgno ]);
}