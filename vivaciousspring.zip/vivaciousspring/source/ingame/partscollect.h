#pragma once
#define PARTS_ANIME_MAX 6
#define PARTSCOLLECT_CG "res/parts_collect.png"
typedef struct {
	double x, y;
	int w,h;
}PARTSCOLLECT;
extern PARTSCOLLECT pc;
extern int cgPartsRecovery[PARTS_ANIME_MAX];
extern void LoadPartscollect();
extern void InitPartscollect();
extern void ProcessPartscollect();
extern void DrawPartscollect();