#include	<Windows.h>
#include	"../amgame.h"
#include	"../ingame/vivacious_spring_game.h"
int bgmStage_1 = 0;
int bgmStage_2 = 0;
int bgmStage_3 = 0;
int bgmStage_4 = 0;
int bgmTitle = 0;
int bgmGameover = 0;
int bgmStageselect = 0;
//�S��D.K
//��������
int CheckBgm() 
{
	switch (gNowstage) 
	{
	case STAGE_1:
		return bgmStage_1;
		break;
	case STAGE_2:
		return bgmStage_2;
		break;
	case STAGE_3:
		return bgmStage_3;
		break;
	case STAGE_4:
		return bgmStage_4;
		break;
	}
	return -1;
}
void LoadBgm()
{
	bgmStage_1 = LoadWavMem("bgm/bgm_stage_1.wav");
	bgmStage_2 = LoadWavMem("bgm/bgm_stage_2.wav");
	bgmStage_3 = LoadWavMem("bgm/bgm_stage_3.wav");
	bgmStage_4 = LoadWavMem("bgm/bgm_stage_4.wav");
	bgmTitle = LoadWavMem("bgm/bgm_title.wav");
	bgmStageselect = LoadWavMem("bgm/bgm_after_title.wav");
	bgmGameover = LoadWavMem("bgm/bgm_gameover.wav");
}
//�����܂�