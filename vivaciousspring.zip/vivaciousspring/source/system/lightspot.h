#pragma once
#define	LIGHTMAP_W	8
#define	LIGHTMAP_H	8
#define	LIGHTMAP_X	(1280/LIGHTMAP_W)
#define	LIGHTMAP_Y	(720/LIGHTMAP_H)

extern int mapLight[LIGHTMAP_X * LIGHTMAP_Y];
extern void LightmapSpot(int cx, int cy, int r);